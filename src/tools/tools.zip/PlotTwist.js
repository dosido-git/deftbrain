import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useClaudeAPI } from '../hooks/useClaudeAPI';
import { useTheme } from '../hooks/useTheme';
import { usePersistentState } from '../hooks/usePersistentState';
import { CopyBtn } from '../components/ActionButtons';

// ════════════════════════════════════════════════════════════
// THEME — Navy & Gold
// ════════════════════════════════════════════════════════════
const useColors = () => {
  const { theme } = useTheme();
  const d = theme === 'dark';
  return {
    d,
    card:        d ? 'bg-[#2a2623] border-[#3d3630]'  : 'bg-white border-[#e8e1d5]',
    cardAlt:     d ? 'bg-[#332e2a] border-[#3d3630]'  : 'bg-[#faf8f5] border-[#e8e1d5]',
    inset:       d ? 'bg-[#1a1816]'                    : 'bg-[#faf8f5]',
    inputBg:     d ? 'bg-[#1a1816] border-[#3d3630] text-[#f0eeea] placeholder-[#8a8275] focus:border-[#4a6a8a] focus:ring-[#4a6a8a]/20'
                    : 'bg-[#faf8f5] border-[#d5cab8] text-[#3d3935] placeholder-[#8a8275] focus:border-[#4a6a8a] focus:ring-[#4a6a8a]/20',
    text:        d ? 'text-[#f0eeea]'  : 'text-[#3d3935]',
    heading:     d ? 'text-[#f3efe8]'  : 'text-[#1e2a3a]',
    textSec:     d ? 'text-[#c8c3b9]'  : 'text-[#5a544a]',
    textMut:     d ? 'text-[#8a8275]'  : 'text-[#8a8275]',
    label:       d ? 'text-[#c8c3b9]'  : 'text-[#5a544a]',
    border:      d ? 'border-[#3d3630]' : 'border-[#e8e1d5]',
    divider:     d ? 'border-[#3d3630]' : 'border-[#e8e1d5]',
    btn:         d ? 'bg-[#2c4a6e] hover:bg-[#4a6a8a] text-white' : 'bg-[#2c4a6e] hover:bg-[#1e3a58] text-white',
    btnGold:     d ? 'bg-[#b06d22] hover:bg-[#c8872e] text-white' : 'bg-[#c8872e] hover:bg-[#b06d22] text-white',
    btnSec:      d ? 'bg-[#332e2a] hover:bg-[#3d3630] text-[#c8c3b9] border border-[#3d3630]'
                    : 'bg-[#f3efe8] hover:bg-[#e8e1d5] text-[#5e5042] border border-[#d5cab8]',
    btnGhost:    d ? 'text-[#8a8275] hover:text-[#f0eeea]' : 'text-[#8a8275] hover:text-[#3d3935]',
    btnDis:      d ? 'bg-[#332e2a] text-[#5a544a] cursor-not-allowed' : 'bg-[#e8e1d5] text-[#8a8275] cursor-not-allowed',
    pillActive:  d ? 'border-[#4a6a8a] bg-[#2c4a6e]/30 text-[#a8b9ce]' : 'border-[#2c4a6e] bg-[#d4dde8] text-[#1e3a58]',
    pillInactive: d ? 'border-[#3d3630] text-[#8a8275] hover:border-[#5a544a]' : 'border-[#d5cab8] text-[#5a544a] hover:border-[#8a8275]',
    badge:       d ? 'bg-[#2c4a6e]/30 text-[#a8b9ce]' : 'bg-[#d4dde8] text-[#1e3a58]',
    // Special
    insightBg:   d ? 'bg-[#c8872e]/15 border-[#c8872e]/40' : 'bg-[#f9edd8] border-[#c8872e]/40',
    insightText: d ? 'text-[#d9a04e]' : 'text-[#93541f]',
    gutBg:       d ? 'bg-[#2c4a6e]/15 border-[#4a6a8a]/40' : 'bg-[#d4dde8]/40 border-[#2c4a6e]/30',
    gutText:     d ? 'text-[#a8b9ce]' : 'text-[#1e3a58]',
    stuckBg:     d ? 'bg-[#b54a3f]/10 border-[#b54a3f]/30' : 'bg-[#fceae8] border-[#e8a8a0]',
    stuckText:   d ? 'text-[#e88880]' : 'text-[#b54a3f]',
    successBg:   d ? 'bg-[#5a8a5c]/10 border-[#5a8a5c]/30' : 'bg-[#e8f0e8] border-[#5a8a5c]/30',
    successText: d ? 'text-[#7aba7c]' : 'text-[#3a6a3c]',
    barBg:       d ? 'bg-[#332e2a]' : 'bg-[#e8e1d5]',
    barNavy:     'bg-[#2c4a6e]',
    barGold:     'bg-[#c8872e]',
    errBg:       d ? 'bg-[#b54a3f]/15 border-[#b54a3f]/40' : 'bg-[#fceae8] border-[#e8a8a0]',
    errText:     d ? 'text-[#e88880]' : 'text-[#b54a3f]',
    histBg:      d ? 'bg-[#2c4a6e]/10 border-[#4a6a8a]/30' : 'bg-[#d4dde8]/30 border-[#2c4a6e]/15',
    histCard:    d ? 'bg-[#2a2623] border-[#3d3630]' : 'bg-white border-[#e8e1d5]',
    histAccent:  d ? 'text-[#a8b9ce]' : 'text-[#2c4a6e]',
    linkStyle:   d ? 'text-[#6e8aaa] hover:text-[#a8b9ce] underline' : 'text-[#2c4a6e] hover:text-[#1e3a58] underline',
    // Matrix
    matrixHead:  d ? 'bg-[#332e2a] text-[#c8c3b9]' : 'bg-[#f3efe8] text-[#5a544a]',
    matrixHigh:  d ? 'bg-[#5a8a5c]/20 text-[#7aba7c]' : 'bg-[#e8f0e8] text-[#3a6a3c]',
    matrixMid:   d ? 'bg-[#c8872e]/15 text-[#d9a04e]' : 'bg-[#f9edd8] text-[#93541f]',
    matrixLow:   d ? 'bg-[#b54a3f]/15 text-[#e88880]' : 'bg-[#fceae8] text-[#b54a3f]',
  };
};

// ════════════════════════════════════════════════════════════
// CONSTANTS
// ════════════════════════════════════════════════════════════
const VALUE_OPTIONS = [
  'Financial security', 'Freedom / autonomy', 'Family / relationships',
  'Career growth', 'Health / wellbeing', 'Creativity', 'Stability',
  'Adventure / novelty', 'Purpose / meaning', 'Work-life balance',
];

const STUCK_OPTIONS = [
  { value: 'fear_of_regret', label: "I'm afraid I'll regret it" },
  { value: 'too_many_options', label: 'Too many options' },
  { value: 'people_pleasing', label: "I don't want to disappoint anyone" },
  { value: 'sunk_cost', label: "I've already invested so much" },
  { value: 'fear_of_unknown', label: "The unknown scares me" },
  { value: 'analysis_paralysis', label: "I keep going back and forth" },
  { value: 'not_sure', label: "I don't know why I'm stuck" },
];

const EXAMPLE_DECISION = "I got a job offer that pays 40% more but requires relocating to a new city. My current job is comfortable and I have a great team, but I've been feeling stagnant for over a year. My partner is open to moving but not enthusiastic about it.";

// ════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ════════════════════════════════════════════════════════════
const PlotTwist = () => {
  const { callToolEndpoint, loading } = useClaudeAPI();
  const c = useColors();
  const resultsRef = useRef(null);

  // Persistent
  const [history, setHistory] = usePersistentState('plot-twist-history', []);
  const [showHistory, setShowHistory] = useState(false);

  // Input
  const [decision, setDecision] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [context, setContext] = useState('');
  const [values, setValues] = useState([]);
  const [deadline, setDeadline] = useState('');
  const [stuckReason, setStuckReason] = useState('');

  // Results
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [expandedOption, setExpandedOption] = useState(0);

  // Sections
  const [showMatrix, setShowMatrix] = useState(true);
  const [showStillStuck, setShowStillStuck] = useState(false);

  useEffect(() => {
    if (results && resultsRef.current) {
      setTimeout(() => resultsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200);
    }
  }, [results]);

  // ══════════════════════════════════════════
  // HANDLERS
  // ══════════════════════════════════════════
  const updateOption = useCallback((idx, val) => {
    setOptions(prev => prev.map((o, i) => i === idx ? val : o));
  }, []);

  const addOption = useCallback(() => {
    if (options.length < 5) setOptions(prev => [...prev, '']);
  }, [options.length]);

  const removeOption = useCallback((idx) => {
    if (options.length > 2) setOptions(prev => prev.filter((_, i) => i !== idx));
  }, [options.length]);

  const toggleValue = useCallback((val) => {
    setValues(prev => prev.includes(val) ? prev.filter(v => v !== val) : [...prev, val]);
  }, []);

  const analyze = useCallback(async () => {
    if (!decision.trim()) { setError('Describe the decision you\'re facing'); return; }
    setError(''); setResults(null);
    const filteredOptions = options.filter(o => o.trim());
    try {
      const data = await callToolEndpoint('plot-twist', {
        decision: decision.trim(),
        options: filteredOptions.length > 0 ? filteredOptions : null,
        context: context.trim() || null,
        values: values.length > 0 ? values : null,
        deadline: deadline.trim() || null,
        stuckReason: stuckReason || null,
      });
      setResults(data);
      setExpandedOption(0);
      saveToHistory(data);
    } catch (err) {
      setError(err.message || 'Failed to analyze decision.');
    }
  }, [decision, options, context, values, deadline, stuckReason, callToolEndpoint]);

  const handleReset = useCallback(() => {
    setDecision(''); setOptions(['', '']); setContext('');
    setValues([]); setDeadline(''); setStuckReason('');
    setResults(null); setError('');
  }, []);

  const loadExample = useCallback(() => {
    setDecision(EXAMPLE_DECISION);
    setOptions(['Take the new job and relocate', 'Stay at current job']);
    setValues(['Career growth', 'Financial security', 'Family / relationships']);
    setStuckReason('fear_of_regret');
  }, []);

  // ══════════════════════════════════════════
  // HISTORY
  // ══════════════════════════════════════════
  const saveToHistory = useCallback((data) => {
    const entry = {
      id: `pt_${Date.now()}`, date: new Date().toISOString(),
      preview: decision.trim().slice(0, 60),
      pattern: data.stuck_pattern?.pattern || '',
      results: data,
    };
    setHistory(prev => [entry, ...prev].slice(0, 20));
  }, [decision, setHistory]);

  // ══════════════════════════════════════════
  // COPY
  // ══════════════════════════════════════════
  const buildFullCopy = useCallback(() => {
    if (!results) return '';
    const lines = ['🔀 Plot Twist — Decision Analysis', ''];
    if (results.decision_summary) lines.push(results.decision_summary, '');
    if (results.the_real_question) lines.push('THE REAL QUESTION:', results.the_real_question, '');
    if (results.gut_check) lines.push('GUT CHECK:', results.gut_check, '');
    if (results.one_question) lines.push('THE ONE QUESTION:', results.one_question, '');
    lines.push('', '— Generated by DeftBrain · deftbrain.com');
    return lines.join('\n');
  }, [results]);

  // ══════════════════════════════════════════
  // RENDER HELPERS
  // ══════════════════════════════════════════
  const Pill = ({ active, onClick, children }) => (
    <button onClick={onClick}
      className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${active ? c.pillActive : c.pillInactive}`}>
      {active && <span className="mr-1">✓</span>}{children}
    </button>
  );

  const Collapsible = ({ title, emoji, open, onToggle, badge, children }) => (
    <div className={`${c.card} border rounded-xl overflow-hidden`}>
      <button onClick={onToggle} className="w-full flex items-center justify-between p-5 text-left hover:opacity-80">
        <div className="flex items-center gap-3">
          <span className="text-lg">{emoji}</span>
          <span className={`text-base font-semibold ${c.text}`}>{title}</span>
          {badge && <span className={`text-xs px-2 py-0.5 rounded-full ${c.badge}`}>{badge}</span>}
        </div>
        <span className={`text-xs ${c.textMut}`}>{open ? '▲' : '▼'}</span>
      </button>
      {open && <div className={`px-5 pb-5 border-t ${c.divider}`}>{children}</div>}
    </div>
  );

  const scoreColor = (score) => score >= 7 ? c.matrixHigh : score >= 4 ? c.matrixMid : c.matrixLow;

  // ══════════════════════════════════════════
  // RENDER: Input
  // ══════════════════════════════════════════
  const renderInput = () => (
    <div className="space-y-4">
      <div className={`${c.card} border rounded-xl p-5`}>
        <div className="flex items-center justify-between mb-1">
          <label className={`text-base font-bold ${c.text}`}>What's the decision?</label>
          <button onClick={loadExample} className={`text-xs ${c.linkStyle}`}>Try example</button>
        </div>
        <p className={`text-sm ${c.textMut} mb-4`}>Describe the situation and what you're choosing between. The more context, the sharper the analysis.</p>
        <textarea value={decision} onChange={e => setDecision(e.target.value)}
          placeholder="e.g., 'I got a job offer in another city that pays more, but I'd have to leave my partner behind...'"
          className={`w-full h-32 p-4 border-2 rounded-xl ${c.inputBg} outline-none focus:ring-2 resize-none text-base`} />
      </div>

      {/* Options */}
      <div className={`${c.card} border rounded-xl p-5`}>
        <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>🔀 Your options</label>
        <p className={`text-xs ${c.textMut} mb-3`}>Name the choices you're weighing (we'll add "do nothing" automatically)</p>
        <div className="space-y-2">
          {options.map((opt, idx) => (
            <div key={idx} className="flex gap-2">
              <input type="text" value={opt} onChange={e => updateOption(idx, e.target.value)}
                placeholder={`Option ${idx + 1}`}
                className={`flex-1 px-4 py-2.5 rounded-xl border text-sm ${c.inputBg} outline-none`} />
              {options.length > 2 && (
                <button onClick={() => removeOption(idx)}
                  className={`px-3 rounded-lg text-xs ${c.btnGhost} hover:text-red-500`}>✕</button>
              )}
            </div>
          ))}
        </div>
        {options.length < 5 && (
          <button onClick={addOption} className={`mt-2 text-xs font-semibold ${c.linkStyle}`}>➕ Add option</button>
        )}
      </div>

      {/* Values */}
      <div className={`${c.card} border rounded-xl p-5`}>
        <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-1 block`}>💎 What matters most?</label>
        <p className={`text-xs ${c.textMut} mb-2`}>Pick the values this decision touches</p>
        <div className="flex flex-wrap gap-1.5">
          {VALUE_OPTIONS.map(val => (
            <Pill key={val} active={values.includes(val)} onClick={() => toggleValue(val)}>{val}</Pill>
          ))}
        </div>
      </div>

      {/* Why stuck */}
      <div className={`${c.card} border rounded-xl p-5`}>
        <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>🧠 Why are you stuck?</label>
        <div className="flex flex-wrap gap-1.5">
          {STUCK_OPTIONS.map(opt => (
            <Pill key={opt.value} active={stuckReason === opt.value}
              onClick={() => setStuckReason(stuckReason === opt.value ? '' : opt.value)}>
              {opt.label}
            </Pill>
          ))}
        </div>
      </div>

      {/* Context + Deadline */}
      <div className={`${c.card} border rounded-xl p-5 space-y-3`}>
        <div>
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-1 block`}>💬 Extra context</label>
          <input type="text" value={context} onChange={e => setContext(e.target.value)}
            placeholder="Anything else that matters (financial situation, family, past experiences)"
            className={`w-full px-4 py-2.5 rounded-xl border text-sm ${c.inputBg} outline-none`} />
        </div>
        <div>
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-1 block`}>⏰ Deadline</label>
          <input type="text" value={deadline} onChange={e => setDeadline(e.target.value)}
            placeholder="When do you need to decide? (e.g., 'by Friday', 'no rush', 'ASAP')"
            className={`w-full px-4 py-2.5 rounded-xl border text-sm ${c.inputBg} outline-none`} />
        </div>
      </div>

      <button onClick={analyze}
        disabled={loading || !decision.trim()}
        className={`w-full py-4 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
          loading || !decision.trim() ? c.btnDis : c.btn
        }`}>
        {loading ? <><span className="animate-spin inline-block">⏳</span> Analyzing from every angle...</>
          : <><span>🔀</span> Untangle This Decision</>}
      </button>
    </div>
  );

  // ══════════════════════════════════════════
  // RENDER: Results
  // ══════════════════════════════════════════
  const renderResults = () => {
    if (!results) return null;
    const opts = results.options_analysis || [];

    return (
      <div ref={resultsRef} className="space-y-4 mt-4">
        {/* The Real Question */}
        {results.the_real_question && (
          <div className={`p-5 rounded-2xl border-2 ${c.insightBg}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">🔑</span>
              <span className={`text-sm font-bold ${c.insightText}`}>The real question you're asking</span>
            </div>
            <p className={`text-base leading-relaxed font-medium ${c.text}`}>{results.the_real_question}</p>
          </div>
        )}

        {/* Stuck Pattern */}
        {results.stuck_pattern && (
          <div className={`p-5 rounded-2xl border ${c.stuckBg}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">🧠</span>
              <span className={`text-sm font-bold ${c.stuckText}`}>Why you're stuck: {results.stuck_pattern.pattern}</span>
            </div>
            <p className={`text-sm ${c.stuckText} mb-2`}>{results.stuck_pattern.explanation}</p>
            <div className={`p-3 rounded-lg ${c.successBg}`}>
              <p className={`text-xs font-bold ${c.successText} mb-1`}>💡 Unlock</p>
              <p className={`text-sm ${c.successText}`}>{results.stuck_pattern.unlock}</p>
            </div>
          </div>
        )}

        {/* Options Analysis — Tab cards */}
        {opts.length > 0 && (
          <div className={`${c.card} border rounded-xl overflow-hidden`}>
            <div className={`flex border-b ${c.divider}`}>
              {opts.map((opt, idx) => (
                <button key={idx} onClick={() => setExpandedOption(idx)}
                  className={`flex-1 px-4 py-4 text-sm font-semibold transition-all ${
                    expandedOption === idx
                      ? (c.d ? 'bg-[#332e2a] text-[#d9a04e] border-b-2 border-[#c8872e]' : 'bg-[#faf8f5] text-[#1e3a58] border-b-2 border-[#2c4a6e]')
                      : (c.d ? 'text-[#8a8275] hover:text-[#c8c3b9]' : 'text-[#8a8275] hover:text-[#5a544a]')
                  }`}>
                  {opt.option?.slice(0, 30) || `Option ${idx + 1}`}{opt.option?.length > 30 ? '...' : ''}
                </button>
              ))}
            </div>

            {opts.map((opt, idx) => {
              if (idx !== expandedOption) return null;
              return (
                <div key={idx} className="p-5 space-y-4">
                  {/* Pre-mortem */}
                  <div>
                    <p className={`text-xs font-bold ${c.textMut} uppercase mb-1`}>☠️ Pre-mortem — How this could fail</p>
                    <p className={`text-sm ${c.text}`}>{opt.pre_mortem}</p>
                  </div>

                  {/* 10/10/10 */}
                  {opt.ten_ten_ten && (
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { label: '10 min', val: opt.ten_ten_ten.ten_minutes },
                        { label: '10 months', val: opt.ten_ten_ten.ten_months },
                        { label: '10 years', val: opt.ten_ten_ten.ten_years },
                      ].map((t, i) => (
                        <div key={i} className={`p-3 rounded-lg ${c.cardAlt} border`}>
                          <p className={`text-[10px] font-bold ${c.textMut} uppercase mb-1`}>⏱️ {t.label}</p>
                          <p className={`text-xs ${c.text}`}>{t.val}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Opportunity cost */}
                  <div>
                    <p className={`text-xs font-bold ${c.textMut} uppercase mb-1`}>💸 Opportunity cost</p>
                    <p className={`text-sm ${c.text}`}>{opt.opportunity_cost}</p>
                  </div>

                  {/* Reversibility + Values */}
                  <div className="grid grid-cols-2 gap-2">
                    {opt.reversibility && (
                      <div className={`p-3 rounded-lg ${c.inset}`}>
                        <p className={`text-[10px] font-bold ${c.textMut} uppercase mb-1`}>🚪 Reversibility: {opt.reversibility.score}/10</p>
                        <p className={`text-xs ${c.text}`}>{opt.reversibility.assessment}</p>
                      </div>
                    )}
                    {opt.values_alignment && (
                      <div className={`p-3 rounded-lg ${c.inset}`}>
                        <p className={`text-[10px] font-bold ${c.textMut} uppercase mb-1`}>💎 Values fit: {opt.values_alignment.score}/10</p>
                        <p className={`text-xs ${c.text}`}>{opt.values_alignment.assessment}</p>
                      </div>
                    )}
                  </div>

                  {/* Hidden upside/risk */}
                  <div className="grid grid-cols-2 gap-2">
                    {opt.hidden_upside && (
                      <div className={`p-3 rounded-lg border ${c.successBg}`}>
                        <p className={`text-xs font-bold ${c.successText} mb-1`}>🌟 Hidden upside</p>
                        <p className={`text-xs ${c.successText}`}>{opt.hidden_upside}</p>
                      </div>
                    )}
                    {opt.hidden_risk && (
                      <div className={`p-3 rounded-lg border ${c.stuckBg}`}>
                        <p className={`text-xs font-bold ${c.stuckText} mb-1`}>⚠️ Hidden risk</p>
                        <p className={`text-xs ${c.stuckText}`}>{opt.hidden_risk}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Comparison Matrix */}
        {results.comparison_matrix && (
          <Collapsible title="Comparison Matrix" emoji="📊" open={showMatrix}
            onToggle={() => setShowMatrix(!showMatrix)}>
            <div className="overflow-x-auto mt-4">
              <table className="w-full text-xs">
                <thead>
                  <tr>
                    <th className={`p-2 text-left rounded-tl-lg ${c.matrixHead}`}>Dimension</th>
                    {(results.comparison_matrix.scores || []).map((s, i) => (
                      <th key={i} className={`p-2 text-center ${c.matrixHead} ${i === results.comparison_matrix.scores.length - 1 ? 'rounded-tr-lg' : ''}`}>
                        {s.option?.slice(0, 20)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(results.comparison_matrix.dimensions || []).map((dim, dIdx) => (
                    <tr key={dIdx}>
                      <td className={`p-2 ${c.textSec} font-medium border-t ${c.divider}`}>{dim}</td>
                      {(results.comparison_matrix.scores || []).map((s, sIdx) => (
                        <td key={sIdx} className={`p-2 text-center font-bold border-t ${c.divider} ${scoreColor(s.scores?.[dIdx] || 0)}`}>
                          {s.scores?.[dIdx] || '—'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Collapsible>
        )}

        {/* Gut Check */}
        {results.gut_check && (
          <div className={`p-5 rounded-2xl border ${c.gutBg}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">🫀</span>
              <span className={`text-sm font-bold ${c.gutText}`}>Gut check — what you already know</span>
            </div>
            <p className={`text-sm leading-relaxed ${c.gutText}`}>{results.gut_check}</p>
          </div>
        )}

        {/* The One Question */}
        {results.one_question && (
          <div className={`p-5 rounded-2xl border-2 ${c.insightBg}`}>
            <p className={`text-xs font-bold ${c.insightText} uppercase mb-2`}>❓ The one question that will make this clear</p>
            <p className={`text-lg font-bold ${c.text}`}>{results.one_question}</p>
          </div>
        )}

        {/* If Still Stuck */}
        {results.if_still_stuck && (
          <Collapsible title="Still Stuck? Try These" emoji="🪄" open={showStillStuck}
            onToggle={() => setShowStillStuck(!showStillStuck)}>
            <div className="space-y-3 mt-4">
              {results.if_still_stuck.coin_flip_test && (
                <div className={`p-4 rounded-lg ${c.inset}`}>
                  <p className={`text-xs font-bold ${c.textMut} mb-1`}>🪙 Coin Flip Test</p>
                  <p className={`text-sm ${c.text}`}>{results.if_still_stuck.coin_flip_test}</p>
                </div>
              )}
              {results.if_still_stuck.two_year_letter && (
                <div className={`p-4 rounded-lg ${c.inset}`}>
                  <p className={`text-xs font-bold ${c.textMut} mb-1`}>✉️ Letter From Future You</p>
                  <p className={`text-sm ${c.text}`}>{results.if_still_stuck.two_year_letter}</p>
                </div>
              )}
              {results.if_still_stuck.smallest_step && (
                <div className={`p-4 rounded-lg border ${c.successBg}`}>
                  <p className={`text-xs font-bold ${c.successText} mb-1`}>👣 Smallest Step</p>
                  <p className={`text-sm ${c.successText}`}>{results.if_still_stuck.smallest_step}</p>
                </div>
              )}
            </div>
          </Collapsible>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <div className="flex-1"><CopyBtn content={buildFullCopy()} label="Copy Analysis" /></div>
          <button onClick={handleReset}
            className={`flex-1 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 ${c.btn}`}>
            <span>🔄</span> New Decision
          </button>
        </div>

        {/* Cross-references */}
        <div className={`p-4 rounded-2xl border ${c.card}`}>
          <p className={`text-xs font-bold ${c.textMut} uppercase tracking-wide mb-2`}>🔗 Related Tools</p>
          <div className={`space-y-1.5 text-xs ${c.textSec}`}>
            <p>Need to communicate your decision? <a href="/VelvetHammer" target="_blank" rel="noopener noreferrer" className={c.linkStyle}>Velvet Hammer</a> helps deliver tough messages with tact.</p>
            <p>Trying to decode someone's reaction? <a href="/DecoderRing" target="_blank" rel="noopener noreferrer" className={c.linkStyle}>Decoder Ring</a> reveals the subtext in any message.</p>
          </div>
        </div>
      </div>
    );
  };

  // History
  const renderHistory = () => {
    if (history.length === 0) return null;
    const formatDate = (iso) => {
      try { const d = new Date(iso); const diff = Math.floor((new Date() - d) / 86400000); return diff === 0 ? 'Today' : diff === 1 ? 'Yesterday' : diff < 7 ? `${diff}d ago` : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); } catch { return ''; }
    };
    return (
      <div className={`mt-6 p-4 rounded-2xl border ${c.histBg}`}>
        <button onClick={() => setShowHistory(!showHistory)} className="w-full flex items-center gap-2 text-left">
          <span className={`text-base ${c.histAccent}`}>🔀</span>
          <span className={`text-sm font-bold ${c.text} flex-1`}>Past Decisions</span>
          <span className={`text-xs ${c.textMut}`}>{history.length}</span>
          <span className={`text-xs ${c.textMut}`}>{showHistory ? '▲' : '▼'}</span>
        </button>
        {showHistory && (
          <div className="mt-3 space-y-2">
            {history.map(entry => (
              <div key={entry.id} className={`rounded-xl border ${c.histCard} p-3 flex items-center gap-3`}>
                <div className="flex-1 min-w-0">
                  <div className={`text-sm font-semibold ${c.text} truncate`}>{entry.preview}...</div>
                  <div className={`text-xs ${c.textMut} mt-0.5`}>{formatDate(entry.date)}{entry.pattern ? ` · ${entry.pattern}` : ''}</div>
                </div>
                <button onClick={() => { setResults(entry.results); setShowHistory(false); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold ${c.btnSec}`}>View</button>
                <button onClick={() => setHistory(prev => prev.filter(h => h.id !== entry.id))}
                  className={`px-2 py-1.5 rounded-lg text-xs ${c.btnGhost} hover:text-red-500`}>🗑️</button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-5">
        <div>
          <h2 className={`text-2xl font-bold ${c.heading}`}>Plot Twist <span className="text-xl">🔀</span></h2>
          <p className={`text-sm ${c.textMut}`}>See every angle of a tough decision — then decide with clarity</p>
        </div>
      </div>
      {!results && renderInput()}
      {results && renderResults()}
      {error && (
        <div className={`mt-4 p-4 ${c.errBg} border rounded-xl flex items-start gap-3`}>
          <span className={`text-base ${c.errText}`}>⚠️</span>
          <p className={`text-sm ${c.errText}`}>{error}</p>
        </div>
      )}
      {renderHistory()}
    </div>
  );
};

PlotTwist.displayName = 'PlotTwist';
export default PlotTwist;
