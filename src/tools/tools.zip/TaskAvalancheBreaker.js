import React, { useState, useEffect, useRef } from 'react';
import { CopyBtn } from '../components/ActionButtons';
import { useClaudeAPI } from '../hooks/useClaudeAPI';
import { useTheme } from '../hooks/useTheme';

const TaskAvalancheBreaker = () => {
  const { callToolEndpoint, loading } = useClaudeAPI();
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Load saved data from localStorage
  const loadSavedData = () => {
    try {
      const saved = localStorage.getItem('taskAvalancheData');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  };

  // Form state
  const [project, setProject] = useState('');
  const [overwhelmReasons, setOverwhelmReasons] = useState({
    too_many_steps: false, dont_know_start: false,
    emotionally_difficult: false, boring: false, unfamiliar: false
  });
  const [availableTime, setAvailableTime] = useState('5');
  const [energy, setEnergy] = useState(5);

  // Results state
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [completedTasks, setCompletedTasks] = useState([]);
  const [currentTaskIndex, setCurrentTaskIndex] = useState(0);
  const [expandedTask, setExpandedTask] = useState(null);

  // Timer state
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(300);
  const [timerTaskId, setTimerTaskId] = useState(null);

  // Gamification state
  const [points, setPoints] = useState(() => loadSavedData()?.points || 0);
  const [streak, setStreak] = useState(() => loadSavedData()?.streak || 0);
  const [lastCompletionDate, setLastCompletionDate] = useState(() => loadSavedData()?.lastCompletionDate || null);
  const [totalTasksEver, setTotalTasksEver] = useState(() => loadSavedData()?.totalTasksEver || 0);
  const [lastExportDate, setLastExportDate] = useState(() => loadSavedData()?.lastExportDate || null);
  const [showCelebration, setShowCelebration] = useState(false);

  // Accountability state
  const [accountabilityPartner, setAccountabilityPartner] = useState(() => loadSavedData()?.accountabilityPartner || '');
  const [showAccountability, setShowAccountability] = useState(false);

  // Habit stacking state
  const [existingHabit, setExistingHabit] = useState('');
  const [showHabitStacking, setShowHabitStacking] = useState(false);

  // Adaptive state
  const [adaptiveMode, setAdaptiveMode] = useState(null);
  const [showStuckHelp, setShowStuckHelp] = useState(false);
  const [showTimerComplete, setShowTimerComplete] = useState(false);
  const [timerCompleteTaskId, setTimerCompleteTaskId] = useState(null);

  // Sound preferences
  const [soundEnabled, setSoundEnabled] = useState(() => loadSavedData()?.soundEnabled ?? true);
  const [tickingSoundEnabled, setTickingSoundEnabled] = useState(() => loadSavedData()?.tickingSoundEnabled ?? false);

  // Inline toast state (replaces alert())
  const [toast, setToast] = useState(null);
  const showToast = (msg, duration = 4000) => {
    setToast(msg);
    setTimeout(() => setToast(null), duration);
  };

  // Skip confirm state (replaces window.confirm())
  const [skipConfirm, setSkipConfirm] = useState(null); // taskId or null

  // Cross-reference link style
  const linkStyle = isDark
    ? 'text-cyan-400 hover:text-cyan-300 underline underline-offset-2'
    : 'text-cyan-600 hover:text-cyan-700 underline underline-offset-2';

  const timeOptions = [
    { value: '5', label: '5 minutes' },
    { value: '10', label: '10 minutes' },
    { value: '15', label: '15 minutes' },
    { value: '30', label: '30 minutes' }
  ];

  // Save gamification data to localStorage
  useEffect(() => {
    const dataToSave = {
      points, streak, lastCompletionDate, totalTasksEver,
      accountabilityPartner, lastExportDate, soundEnabled, tickingSoundEnabled
    };
    localStorage.setItem('taskAvalancheData', JSON.stringify(dataToSave));
  }, [points, streak, lastCompletionDate, totalTasksEver, accountabilityPartner, lastExportDate, soundEnabled, tickingSoundEnabled]);

  // Theme-aware colors
  const c = {
    bg: isDark ? 'bg-zinc-900' : 'bg-gradient-to-br from-emerald-50 to-emerald-50',
    card: isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-emerald-200',
    cardAlt: isDark ? 'bg-zinc-700 border-zinc-600' : 'bg-emerald-50 border-emerald-200',
    input: isDark
      ? 'bg-zinc-900 border-zinc-700 text-zinc-50 placeholder:text-zinc-500 focus:border-emerald-500 focus:ring-emerald-500/20'
      : 'bg-white border-emerald-300 text-emerald-900 placeholder:text-emerald-400 focus:border-emerald-600 focus:ring-emerald-100',
    text: isDark ? 'text-zinc-50' : 'text-emerald-900',
    textSecondary: isDark ? 'text-zinc-300' : 'text-emerald-700',
    textMuted: isDark ? 'text-zinc-400' : 'text-emerald-600',
    label: isDark ? 'text-zinc-200' : 'text-emerald-800',
    accent: isDark ? 'text-emerald-400' : 'text-emerald-600',
    btnPrimary: isDark ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white',
    btnSecondary: isDark ? 'bg-zinc-700 hover:bg-zinc-600 text-zinc-50' : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900',
    btnOutline: isDark ? 'border-zinc-600 hover:border-zinc-500 text-zinc-300' : 'border-emerald-300 hover:border-emerald-400 text-emerald-700',
    success: isDark ? 'bg-emerald-900/20 border-emerald-700 text-emerald-200' : 'bg-emerald-50 border-emerald-300 text-emerald-800',
    warning: isDark ? 'bg-amber-900/20 border-amber-700 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-800',
    info: isDark ? 'bg-blue-900/20 border-blue-700 text-blue-200' : 'bg-blue-50 border-blue-200 text-blue-900',
  };

  // ── Audio (preserved exactly) ──
  const audioContextRef = useRef(null);
  const tickTockRef = useRef(false);

  const getAudioContext = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    return audioContextRef.current;
  };

  const playTickSound = () => {
    if (!tickingSoundEnabled) return;
    try {
      const audioContext = getAudioContext();
      const isTick = tickTockRef.current;
      tickTockRef.current = !tickTockRef.current;

      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.frequency.value = isTick ? 2400 : 1800;
      oscillator.type = 'square';
      gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.015);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.015);

      const overtone = audioContext.createOscillator();
      const overtoneGain = audioContext.createGain();
      overtone.connect(overtoneGain);
      overtoneGain.connect(audioContext.destination);
      overtone.frequency.value = isTick ? 4800 : 3600;
      overtone.type = 'sine';
      overtoneGain.gain.setValueAtTime(0.08, audioContext.currentTime);
      overtoneGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.01);
      overtone.start(audioContext.currentTime);
      overtone.stop(audioContext.currentTime + 0.01);
    } catch (err) {
      console.log('Audio not supported');
    }
  };

  const playCompletionSound = () => {
    if (!soundEnabled) return;
    try {
      const audioContext = getAudioContext();
      const oscillator1 = audioContext.createOscillator();
      const gainNode1 = audioContext.createGain();
      oscillator1.connect(gainNode1);
      gainNode1.connect(audioContext.destination);
      oscillator1.frequency.value = 523.25;
      oscillator1.type = 'sine';
      gainNode1.gain.setValueAtTime(0.5, audioContext.currentTime);
      gainNode1.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.6);
      oscillator1.start(audioContext.currentTime);
      oscillator1.stop(audioContext.currentTime + 0.6);

      const oscillator2 = audioContext.createOscillator();
      const gainNode2 = audioContext.createGain();
      oscillator2.connect(gainNode2);
      gainNode2.connect(audioContext.destination);
      oscillator2.frequency.value = 659.25;
      oscillator2.type = 'sine';
      gainNode2.gain.setValueAtTime(0.4, audioContext.currentTime + 0.15);
      gainNode2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.75);
      oscillator2.start(audioContext.currentTime + 0.15);
      oscillator2.stop(audioContext.currentTime + 0.75);
    } catch (err) {
      console.log('Audio not supported');
    }
  };

  // ── Timer effect ──
  useEffect(() => {
    let interval;
    if (timerActive && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(prev => {
          const newValue = prev - 1;
          if (newValue > 0) playTickSound();
          return newValue;
        });
      }, 1000);
    } else if (timerSeconds === 0 && timerActive) {
      setTimerActive(false);
      setTimerCompleteTaskId(timerTaskId);
      setShowTimerComplete(true);
      playCompletionSound();
    }
    return () => clearInterval(interval);
  }, [timerActive, timerSeconds, timerTaskId]);

  // ── Streak helpers ──
  const getDaysSinceLastCompletion = () => {
    if (!lastCompletionDate) return null;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const lastDate = new Date(lastCompletionDate); lastDate.setHours(0, 0, 0, 0);
    return Math.floor((today - lastDate) / (1000 * 60 * 60 * 24));
  };

  const getStreakStatus = () => {
    const daysSince = getDaysSinceLastCompletion();
    if (daysSince === null || daysSince === 0) return { status: 'active', icon: '🔥', message: 'Active streak!' };
    if (daysSince === 1) return { status: 'at-risk', icon: '⚠️', message: 'Streak at risk — complete a task today!' };
    if (daysSince === 2) return { status: 'critical', icon: '🚨', message: 'Streak critical — last chance!' };
    return { status: 'broken', icon: '💔', message: 'Streak broken — start fresh!' };
  };

  const updateStreak = () => {
    const today = new Date().toDateString();
    const lastDate = lastCompletionDate ? new Date(lastCompletionDate).toDateString() : null;
    if (lastDate === today) return;
    const daysSince = getDaysSinceLastCompletion();
    if (daysSince === null) setStreak(1);
    else if (daysSince <= 2) setStreak(prev => prev + 1);
    else setStreak(1);
    setLastCompletionDate(today);
  };

  const getLevel = () => Math.floor(points / 100) + 1;
  const getPointsToNextLevel = () => {
    const currentLevel = getLevel();
    return currentLevel * 100 - (points - (currentLevel - 1) * 100);
  };

  // ── Export/Import ──
  const handleExportData = () => {
    const exportData = {
      points, streak, lastCompletionDate, totalTasksEver,
      accountabilityPartner, soundEnabled, tickingSoundEnabled,
      exportDate: new Date().toISOString(), version: '2.0'
    };
    const dataBlob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `task-avalanche-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setLastExportDate(new Date().toISOString());
    showToast('✅ Progress exported! Save this file somewhere safe.');
  };

  const handleImportData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const d = JSON.parse(event.target.result);
          if (typeof d.points !== 'number' || typeof d.streak !== 'number' || typeof d.totalTasksEver !== 'number') {
            throw new Error('Invalid data format');
          }
          setPoints(d.points || 0);
          setStreak(d.streak || 0);
          setLastCompletionDate(d.lastCompletionDate || null);
          setTotalTasksEver(d.totalTasksEver || 0);
          setAccountabilityPartner(d.accountabilityPartner || '');
          setLastExportDate(d.exportDate || null);
          setSoundEnabled(d.soundEnabled ?? true);
          setTickingSoundEnabled(d.tickingSoundEnabled ?? false);
          showToast(`✅ Progress restored! Level ${Math.floor((d.points || 0) / 100) + 1} · ${d.points || 0} pts · ${d.streak || 0} day streak`, 5000);
        } catch (error) {
          showToast('❌ Failed to import data. Check that you selected a valid backup file.');
          console.error('Import error:', error);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const shouldWarnAboutExport = () => {
    if (!lastExportDate) return totalTasksEver > 0;
    return Math.floor((new Date() - new Date(lastExportDate)) / (1000 * 60 * 60 * 24)) >= 7;
  };

  // ── API call ──
  const handleBreakDown = async () => {
    if (!project.trim() || project.trim().length < 10) {
      setError('Please describe your overwhelming project (at least 10 characters)');
      return;
    }
    setError('');
    setResults(null);
    setCompletedTasks([]);
    setCurrentTaskIndex(0);

    try {
      const selectedReasons = Object.keys(overwhelmReasons).filter(key => overwhelmReasons[key]);
      const data = await callToolEndpoint('task-avalanche-breaker', {
        project: project.trim(),
        overwhelmReasons: selectedReasons,
        availableTime: parseInt(availableTime),
        energyLevel: energy,
        adaptiveMode,
        existingHabit: existingHabit.trim()
      });
      setResults(data);
    } catch (err) {
      setError(err.message || 'Failed to break down project. Please try again.');
    }
  };

  const handleOverwhelmToggle = (reason) => {
    setOverwhelmReasons(prev => ({ ...prev, [reason]: !prev[reason] }));
  };

  // ── Task actions ──
  const handleCompleteTask = (taskId) => {
    if (!completedTasks.includes(taskId)) {
      setCompletedTasks(prev => [...prev, taskId]);
      setPoints(prev => prev + 10);
      setTotalTasksEver(prev => prev + 1);
      updateStreak();
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 2000);
      if (currentTaskIndex < results.micro_tasks.length - 1) setCurrentTaskIndex(currentTaskIndex + 1);
      if (timerActive && timerTaskId === taskId) setTimerActive(false);
      if (accountabilityPartner) {
        const task = results?.micro_tasks?.find(t => t.task_id === taskId);
        if (task) showToast(`✅ Progress shared with ${accountabilityPartner}!`);
      }
      const checkpoint = results.momentum_checkpoints?.find(cp => cp.after_task === taskId);
      if (checkpoint) {
        setTimeout(() => showToast(`🎉 ${checkpoint.celebration}${checkpoint.choice ? ` ${checkpoint.choice}` : ''}`, 5000), 100);
      }
    }
  };

  const handleSkipTask = (taskId) => {
    setSkipConfirm(taskId);
  };

  const confirmSkip = () => {
    if (skipConfirm) {
      const nextIndex = results.micro_tasks.findIndex(t => t.task_id === skipConfirm) + 1;
      if (nextIndex < results.micro_tasks.length) setCurrentTaskIndex(nextIndex);
      setSkipConfirm(null);
    }
  };

  const handleTaskTooHard = () => setShowStuckHelp(true);

  // ── Timer ──
  const parseTimeToSeconds = (timeStr) => {
    if (!timeStr) return 300;
    const timeLower = timeStr.toLowerCase();
    const num = parseInt(timeStr) || 0;
    if (timeLower.includes('second')) return num;
    if (timeLower.includes('minute') || timeLower.includes('min')) return num * 60;
    if (timeLower.includes('hour')) return num * 3600;
    return num * 60 || 300;
  };

  const handleStartTimer = (task) => {
    setTimerSeconds(parseTimeToSeconds(task.estimated_time));
    setTimerTaskId(task.task_id);
    setTimerActive(true);
  };
  const handlePauseTimer = () => setTimerActive(false);
  const handleResetTimer = (task) => { setTimerSeconds(parseTimeToSeconds(task.estimated_time)); setTimerActive(false); };
  const formatTime = (seconds) => `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, '0')}`;

  const getEnergyColor = (energyRequired) => {
    switch (energyRequired?.toLowerCase()) {
      case 'low': return isDark ? 'text-emerald-400 bg-emerald-900/30' : 'text-emerald-700 bg-emerald-100';
      case 'medium': return isDark ? 'text-amber-400 bg-amber-900/30' : 'text-amber-700 bg-amber-100';
      case 'high': return isDark ? 'text-red-400 bg-red-900/30' : 'text-red-700 bg-red-100';
      default: return isDark ? 'text-gray-400 bg-gray-900/30' : 'text-gray-700 bg-gray-100';
    }
  };

  const getProgressPercentage = () => {
    if (!results?.micro_tasks) return 0;
    return Math.round((completedTasks.length / results.micro_tasks.length) * 100);
  };

  const getNextIncompleteTask = () => {
    if (!results?.micro_tasks) return null;
    return results.micro_tasks.find(task => !completedTasks.includes(task.task_id));
  };

  const handleReorderByEnergy = async () => {
    if (!results) return;
    try {
      const data = await callToolEndpoint('task-avalanche-breaker', {
        project: project.trim(),
        overwhelmReasons: Object.keys(overwhelmReasons).filter(key => overwhelmReasons[key]),
        availableTime: parseInt(availableTime),
        energyLevel: energy,
        adaptiveMode: 'reorder',
        completedTaskIds: completedTasks
      });
      setResults(data);
    } catch (err) {
      setError('Failed to reorder tasks');
    }
  };

  const handleReset = () => {
    setProject(''); setOverwhelmReasons({ too_many_steps: false, dont_know_start: false, emotionally_difficult: false, boring: false, unfamiliar: false });
    setAvailableTime('5'); setEnergy(5); setResults(null); setError(''); setCompletedTasks([]);
    setCurrentTaskIndex(0); setTimerActive(false); setAdaptiveMode(null); setExistingHabit('');
    setShowStuckHelp(false); setShowTimerComplete(false); setTimerCompleteTaskId(null);
  };

  // ── Build copyable text ──
  const buildFullText = () => {
    if (!results) return '';
    const lines = [];
    lines.push('⚡ TASK AVALANCHE BREAKER — PLAN');
    lines.push('═'.repeat(40));
    lines.push(`Project: ${project}`);
    lines.push(`Total tasks: ${results.micro_tasks?.length || 0}`);
    lines.push(`Estimated time: ${results.project_breakdown?.estimated_total_time || 'Unknown'}`);
    lines.push(`Completed: ${completedTasks.length} / ${results.micro_tasks?.length || 0}`);
    lines.push('');
    lines.push('MICRO-TASKS:');
    results.micro_tasks?.forEach(t => {
      const done = completedTasks.includes(t.task_id);
      lines.push(`  ${done ? '✅' : '⬜'} ${t.task_id}. ${t.task} (${t.estimated_time}, ${t.energy_required} energy)`);
      if (t.completion_criteria) lines.push(`     Done when: ${t.completion_criteria}`);
    });
    if (results.anti_paralysis_strategies) {
      lines.push('');
      lines.push('💚 ANTI-PARALYSIS');
      if (results.anti_paralysis_strategies.if_cant_start) lines.push(`  ${results.anti_paralysis_strategies.if_cant_start}`);
      if (results.anti_paralysis_strategies.permission_to_stop) lines.push(`  ${results.anti_paralysis_strategies.permission_to_stop}`);
    }
    lines.push('');
    lines.push('— Generated by DeftBrain · deftbrain.com');
    return lines.join('\n');
  };

  const handlePrint = () => {
    if (!results) return;
    const content = buildFullText();
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Task Avalanche Plan</title>
      <style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;padding:2rem;max-width:700px;margin:0 auto;line-height:1.6;font-size:14px;}pre{white-space:pre-wrap;word-wrap:break-word;}.branding{margin-top:2rem;padding-top:1rem;border-top:1px solid #ddd;font-size:12px;color:#999;text-align:center;}</style>
    </head><body><pre>${content.replace(/— Generated by DeftBrain · deftbrain\.com/, '')}</pre>
    <div class="branding">Generated by DeftBrain · deftbrain.com</div></body></html>`);
    w.document.close();
    w.print();
  };

  const exampleProject = "Clean out my garage - it's been years and I don't even know where to start. There's so much stuff and I get overwhelmed just thinking about it.";

  const overwhelmOptions = [
    { key: 'too_many_steps', label: 'Too many steps', icon: '📈' },
    { key: 'dont_know_start', label: "Don't know where to start", icon: '❓' },
    { key: 'emotionally_difficult', label: 'Emotionally difficult', icon: '☕' },
    { key: 'boring', label: 'Boring/tedious', icon: '🔋' },
    { key: 'unfamiliar', label: 'Unfamiliar/new to me', icon: '✨' }
  ];

  return (
    <div className="space-y-6">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-lg text-sm font-medium max-w-md text-center
          ${isDark ? 'bg-zinc-700 text-zinc-50 border border-zinc-600' : 'bg-white text-gray-900 border border-gray-200'}`}>
          {toast}
        </div>
      )}

      {/* Gamification Stats Bar */}
      <div className={`${c.card} border rounded-xl p-4 transition-colors duration-200`}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🏆</span>
            <div>
              <div className={`text-xs ${c.textMuted}`}>Level</div>
              <div className={`text-2xl font-bold ${c.accent}`}>{getLevel()}</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-3xl">⭐</span>
            <div>
              <div className={`text-xs ${c.textMuted}`}>Points</div>
              <div className={`text-2xl font-bold ${c.accent}`}>{points}</div>
              <div className={`text-xs ${c.textMuted}`}>{getPointsToNextLevel()} to next level</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {(() => {
              const ss = getStreakStatus();
              const colors = {
                active: 'text-orange-500',
                'at-risk': isDark ? 'text-yellow-400' : 'text-yellow-600',
                critical: isDark ? 'text-orange-400' : 'text-orange-600',
                broken: isDark ? 'text-gray-600' : 'text-gray-400'
              };
              return (
                <>
                  <div className="text-3xl">{ss.icon}</div>
                  <div className="flex-1">
                    <div className={`text-xs ${c.textMuted}`}>Streak</div>
                    <div className={`text-2xl font-bold ${colors[ss.status]}`}>
                      {streak} {streak === 1 ? 'day' : 'days'}
                    </div>
                    {ss.status !== 'active' && streak > 0 && (
                      <div className={`text-xs font-semibold ${colors[ss.status]}`}>{ss.message}</div>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-3xl">🎯</span>
            <div>
              <div className={`text-xs ${c.textMuted}`}>Total Tasks</div>
              <div className={`text-2xl font-bold ${c.accent}`}>{totalTasksEver}</div>
            </div>
          </div>
        </div>

        {/* Grace Period Warning */}
        {(() => {
          const ss = getStreakStatus();
          if (ss.status === 'at-risk' || ss.status === 'critical') {
            const warningColor = ss.status === 'at-risk'
              ? isDark ? 'bg-yellow-900/20 border-yellow-600 text-yellow-300' : 'bg-yellow-50 border-yellow-400 text-yellow-800'
              : isDark ? 'bg-orange-900/20 border-orange-600 text-orange-300' : 'bg-orange-50 border-orange-400 text-orange-800';
            return (
              <div className={`mt-3 p-3 rounded-lg border-2 ${warningColor}`}>
                <p className="text-sm font-semibold">{ss.icon} {ss.message}</p>
                <p className="text-xs mt-1">
                  Grace period: You have {3 - getDaysSinceLastCompletion()} {3 - getDaysSinceLastCompletion() === 1 ? 'day' : 'days'} to complete a task before your streak resets.
                </p>
              </div>
            );
          }
          return null;
        })()}

        {/* Export Warning */}
        {shouldWarnAboutExport() && (
          <div className={`mt-3 p-3 rounded-lg border-2 ${isDark ? 'bg-blue-900/20 border-blue-600' : 'bg-blue-50 border-blue-400'}`}>
            <p className={`text-sm font-semibold ${isDark ? 'text-blue-300' : 'text-blue-800'}`}>💾 Backup Reminder</p>
            <p className={`text-xs mt-1 ${isDark ? 'text-blue-400' : 'text-blue-700'}`}>
              {lastExportDate
                ? `Last exported ${Math.floor((new Date() - new Date(lastExportDate)) / (1000 * 60 * 60 * 24))} days ago. Export to protect your progress!`
                : 'You have progress but no backup. Export now to prevent data loss!'}
            </p>
          </div>
        )}

        {/* Export/Import */}
        <div className="mt-4 flex gap-2 flex-wrap items-center">
          <button onClick={handleExportData} className={`${c.btnSecondary} px-4 py-2 rounded text-sm flex items-center gap-2`}>
            <span>💾</span> Export Progress
          </button>
          <button onClick={handleImportData} className={`${c.btnSecondary} px-4 py-2 rounded text-sm flex items-center gap-2`}>
            <span>📥</span> Import Progress
          </button>
          {lastExportDate && (
            <span className={`text-xs ${c.textMuted} self-center`}>Last backup: {new Date(lastExportDate).toLocaleDateString()}</span>
          )}
        </div>
      </div>

      {/* Supportive Banner */}
      <div className={`${c.info} border-l-4 rounded-r-lg p-5 transition-colors duration-200`}>
        <div className="flex items-start gap-3">
          <span className="text-xl flex-shrink-0 mt-0.5">⛰️</span>
          <div>
            <h3 className={`font-bold mb-1 ${c.text}`}>Task Avalanche Breaker</h3>
            <p className={`text-sm ${c.textSecondary} mb-2`}>
              With gamification, accountability partners, and adaptive intelligence! Earn points,
              build streaks, and get support from friends. Built for executive dysfunction & ADHD.
            </p>
            <p className={`text-xs ${c.textMuted} mb-1`}>💚 Stop after ANY task. Progress is progress. There's no failure here.</p>
            <p className={`text-xs ${c.textMuted}`}>🔥 Streaks have a 48-hour grace period — life happens, and that's okay!</p>
          </div>
        </div>
      </div>

      {/* Celebration */}
      {showCelebration && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 animate-bounce">
          <div className={`${isDark ? 'bg-emerald-900 border-emerald-600' : 'bg-emerald-100 border-emerald-500'} border-4 rounded-2xl p-8 shadow-2xl`}>
            <div className="text-6xl mb-2">🎉</div>
            <div className="text-2xl font-bold">+10 points!</div>
          </div>
        </div>
      )}

      {/* Input Form */}
      <div className={`${c.card} border rounded-xl shadow-lg p-6 transition-colors duration-200`}>
        <div className="flex items-center gap-3 mb-6">
          <div className={`p-3 rounded-lg ${isDark ? 'bg-emerald-900/30' : 'bg-emerald-100'}`}>
            <span className="text-2xl">⚡</span>
          </div>
          <div>
            <h2 className={`text-xl font-bold ${c.text}`}>Break Down Your Overwhelming Project</h2>
            <p className={`text-sm ${c.textMuted}`}>Let's turn that mountain into micro-steps</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Quick Mode Buttons */}
          <div>
            <label className={`block text-sm font-medium ${c.label} mb-3`}>Quick modes (optional):</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {[
                { mode: 'exhausted', icon: '☕', label: "I'm Exhausted", action: () => { setAdaptiveMode('exhausted'); setEnergy(2); } },
                { mode: 'quick', icon: '⏱️', label: '10 Min Max', action: () => { setAdaptiveMode('quick'); setAvailableTime('10'); } },
                { mode: 'anxiety', icon: '😰', label: 'High Anxiety', action: () => { setAdaptiveMode('anxiety'); setOverwhelmReasons(prev => ({ ...prev, emotionally_difficult: true })); } }
              ].map(({ mode, icon, label, action }) => (
                <button
                  key={mode}
                  onClick={action}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    adaptiveMode === mode
                      ? isDark ? 'border-emerald-500 bg-emerald-900/30' : 'border-emerald-600 bg-emerald-100'
                      : `border-2 ${c.btnOutline}`
                  }`}
                >
                  <span className="block text-xl mb-1">{icon}</span>
                  <div className="text-xs">{label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Project Description */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="project" className={`block text-sm font-medium ${c.label}`}>What's overwhelming you right now?</label>
              <button onClick={() => setProject(exampleProject)} className={`text-xs ${c.accent} hover:underline`}>Try example</button>
            </div>
            <textarea
              id="project" value={project} onChange={(e) => setProject(e.target.value)}
              placeholder="e.g., Clean garage, Write thesis, Plan wedding, Organize finances..."
              className={`w-full p-4 border rounded-lg ${c.input} outline-none focus:ring-2 transition-colors duration-200`} rows={4}
            />
          </div>

          {/* Habit Stacking */}
          <div>
            <button onClick={() => setShowHabitStacking(!showHabitStacking)} className={`flex items-center gap-2 text-sm ${c.accent} hover:underline mb-2`}>
              <span>🔗</span> {showHabitStacking ? 'Hide' : 'Add'} habit stacking
            </button>
            {showHabitStacking && (
              <div className={`p-4 rounded-lg ${isDark ? 'bg-blue-900/20' : 'bg-blue-50'}`}>
                <p className={`text-sm mb-2 ${c.label}`}>Link micro-tasks to existing habits for better adherence:</p>
                <input type="text" value={existingHabit} onChange={(e) => setExistingHabit(e.target.value)}
                  placeholder="e.g., After I make morning coffee, I will..."
                  className={`w-full p-2 border rounded ${c.input}`} />
                <p className={`text-xs ${c.textMuted} mt-1`}>Example: "After I brush teeth, I will do first micro-task"</p>
              </div>
            )}
          </div>

          {/* Why Overwhelming */}
          <div>
            <label className={`block text-sm font-medium ${c.label} mb-3`}>Why does this feel overwhelming?</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {overwhelmOptions.map(({ key, label, icon }) => (
                <label key={key} className={`p-3 rounded-lg border-2 cursor-pointer transition-all duration-200 flex items-center gap-2 ${
                  overwhelmReasons[key]
                    ? isDark ? 'border-emerald-500 bg-emerald-900/30' : 'border-emerald-600 bg-emerald-100'
                    : isDark ? 'border-zinc-700 hover:border-zinc-600' : 'border-emerald-200 hover:border-emerald-300'
                }`}>
                  <input type="checkbox" checked={overwhelmReasons[key]} onChange={() => handleOverwhelmToggle(key)} className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500" />
                  <span>{icon}</span>
                  <span className={`text-sm ${overwhelmReasons[key] ? c.accent : c.textMuted}`}>{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Time and Energy */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="time" className={`block text-sm font-medium ${c.label} mb-2`}><span>⏱️</span> How much time do you have for this session?</label>
              <select id="time" value={availableTime} onChange={(e) => setAvailableTime(e.target.value)} className={`w-full p-3 border rounded-lg ${c.input} outline-none focus:ring-2`}>
                {timeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              <p className={`text-xs ${c.textMuted} mt-1`}>Determines how many tasks you'll get</p>
            </div>
            <div>
              <label htmlFor="energy" className={`block text-sm font-medium ${c.label} mb-2`}>
                <span>⚡</span> Energy level right now: <span className={`${c.accent} font-bold`}>{energy}/10</span>
              </label>
              <div className="flex items-center gap-3">
                <span className="text-xs">😴</span>
                <input id="energy" type="range" min="1" max="10" value={energy} onChange={(e) => setEnergy(parseInt(e.target.value))}
                  className="flex-1 h-2 rounded-lg appearance-none cursor-pointer"
                  style={{ background: isDark
                    ? `linear-gradient(to right, #10b981 0%, #10b981 ${energy * 10}%, #3f3f46 ${energy * 10}%, #3f3f46 100%)`
                    : `linear-gradient(to right, #10b981 0%, #10b981 ${energy * 10}%, #d1d5db ${energy * 10}%, #d1d5db 100%)`
                  }} />
                <span className="text-xs">⚡</span>
              </div>
              <p className={`text-xs ${c.textMuted} mt-1`}>Determines how hard/complex tasks will be</p>
            </div>
          </div>

          {/* Smart Planning Explainer */}
          <div className={`p-3 rounded-lg ${isDark ? 'bg-blue-900/20 border border-blue-700' : 'bg-blue-50 border border-blue-300'}`}>
            <p className={`text-sm ${isDark ? 'text-blue-200' : 'text-blue-900'}`}>
              <strong>💡 Smart Planning:</strong> More time = more tasks. Lower energy = simpler tasks.
              {energy <= 3 && ' Low energy means all tasks will be quick & physical.'}
              {energy > 6 && parseInt(availableTime) >= 15 && ' High energy + more time = you can tackle complex tasks!'}
              {parseInt(availableTime) <= 5 && ' Short session = just a few quick wins.'}
            </p>
          </div>

          {/* Accountability Partner */}
          <div>
            <button onClick={() => setShowAccountability(!showAccountability)} className={`flex items-center gap-2 text-sm ${c.accent} hover:underline mb-2`}>
              <span>👥</span> {showAccountability ? 'Hide' : 'Add'} accountability partner
            </button>
            {showAccountability && (
              <div className={`p-4 rounded-lg ${isDark ? 'bg-purple-900/20' : 'bg-purple-50'}`}>
                <p className={`text-sm mb-2 ${c.label}`}>Share your progress with a friend for extra motivation:</p>
                <input type="text" value={accountabilityPartner} onChange={(e) => setAccountabilityPartner(e.target.value)}
                  placeholder="Friend's name or email" className={`w-full p-2 border rounded ${c.input}`} />
                <p className={`text-xs ${c.textMuted} mt-1`}>We'll notify them when you complete tasks (virtual support!)</p>
              </div>
            )}
          </div>

          {/* Pre-result cross-reference */}
          <p className={`text-xs text-center ${c.textMuted}`}>
            Tasks still jumbled in your head? Dump them into{' '}
            <a href="/BrainDumpStructurer" target="_blank" rel="noopener noreferrer" className={linkStyle}>Brain Dump Structurer</a>{' '}
            first, then bring the list here.
          </p>

          {/* Break Down Button */}
          <div className="flex gap-3">
            <button onClick={handleBreakDown} disabled={loading}
              className={`flex-1 ${c.btnPrimary} disabled:opacity-50 font-medium py-3 px-6 rounded-lg flex items-center justify-center gap-2`}>
              {loading ? (<><span className="animate-spin inline-block">⏳</span> Breaking it down...</>)
                : (<><span>⛰️</span> Break This Down for Me</>)}
            </button>
            {results && (
              <button onClick={handleReset} className={`px-6 py-3 border-2 ${c.btnOutline} font-medium rounded-lg`}>New Project</button>
            )}
          </div>

          {error && (
            <div className={`p-4 ${c.warning} border rounded-lg flex items-start gap-3`} role="alert">
              <span className="flex-shrink-0 mt-0.5">⚠️</span>
              <p className="text-sm">{error}</p>
            </div>
          )}
        </div>
      </div>

      {/* ═══════════════ RESULTS ═══════════════ */}
      {results && (
        <div className="space-y-6">

          {/* Adaptive Controls + Copy/Print */}
          <div className={`${c.card} border rounded-xl p-4 flex gap-3 flex-wrap`}>
            <button onClick={handleReorderByEnergy} className={`${c.btnSecondary} px-4 py-2 rounded flex items-center gap-2`}>
              <span>🔄</span> Reorder by Current Energy
            </button>
            <button onClick={() => setShowStuckHelp(true)} className={`${c.btnSecondary} px-4 py-2 rounded flex items-center gap-2`}>
              <span>🆘</span> Still Can't Start?
            </button>
            <CopyBtn content={buildFullText()} label="Copy Task List" />
            <button onClick={handlePrint} className={`${c.btnSecondary} px-4 py-2 rounded text-sm font-medium flex items-center gap-2`}>
              <span>🖨️</span> Print
            </button>
          </div>

          {/* Project Overview */}
          <div className={`${c.success} border-l-4 rounded-r-lg p-6`}>
            <h3 className="text-xl font-bold mb-3">✨ Your Project, Broken Down</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-sm opacity-75">Total Micro-Tasks</div>
                <div className="text-2xl font-bold">{results.project_breakdown?.total_micro_tasks || 0}</div>
              </div>
              <div>
                <div className="text-sm opacity-75">Estimated Time</div>
                <div className="text-2xl font-bold">{results.project_breakdown?.estimated_total_time || 'Unknown'}</div>
              </div>
              <div>
                <div className="text-sm opacity-75">Potential Points</div>
                <div className="text-2xl font-bold">{(results.micro_tasks?.length || 0) * 10} pts</div>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className={`${c.card} border rounded-xl p-6`}>
            <div className="flex items-center justify-between mb-2">
              <h3 className={`text-lg font-bold ${c.text}`}>Your Progress</h3>
              <span className={`text-sm ${c.accent} font-semibold`}>{completedTasks.length} / {results.micro_tasks?.length || 0}</span>
            </div>
            <div className={`w-full h-4 rounded-full overflow-hidden ${isDark ? 'bg-zinc-700' : 'bg-gray-200'}`}>
              <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-500 transition-all duration-500" style={{ width: `${getProgressPercentage()}%` }} />
            </div>
            <p className={`text-xs ${c.textMuted} mt-2`}>🎉 {getProgressPercentage()}% complete! +{completedTasks.length * 10} points earned!</p>
          </div>

          {/* Current/Next Task */}
          {getNextIncompleteTask() && (
            <div className={`${isDark ? 'bg-emerald-900/30 border-emerald-700' : 'bg-emerald-100 border-emerald-400'} border-2 rounded-xl p-6 shadow-lg`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className={`text-2xl font-bold ${c.text} mb-1`}>👉 Next Task:</h3>
                  <p className={`text-sm ${c.textMuted}`}>Just this one thing. +10 points.</p>
                </div>
                <span className="text-3xl">🏅</span>
              </div>

              {(() => {
                const task = getNextIncompleteTask();
                const isTimerForThis = timerTaskId === task.task_id;
                return (
                  <>
                    <div className={`${isDark ? 'bg-zinc-800' : 'bg-white'} rounded-lg p-5 mb-4`}>
                      <div className="flex items-start justify-between mb-3">
                        <h4 className={`text-xl font-bold ${c.text}`}>{task.task}</h4>
                        <span className={`text-xs px-2 py-1 rounded font-semibold ${getEnergyColor(task.energy_required)}`}>{task.energy_required} energy</span>
                      </div>
                      {task.why_this_first && (
                        <div className={`mb-3 p-3 rounded ${isDark ? 'bg-blue-900/20' : 'bg-blue-50'}`}>
                          <p className={`text-sm ${isDark ? 'text-blue-200' : 'text-blue-800'}`}><strong>Why this first:</strong> {task.why_this_first}</p>
                        </div>
                      )}
                      {task.habit_stack && (
                        <div className={`mb-3 p-3 rounded ${isDark ? 'bg-purple-900/20' : 'bg-purple-50'}`}>
                          <p className={`text-sm ${isDark ? 'text-purple-200' : 'text-purple-800'}`}><span>🔗</span> <strong>Habit stack:</strong> {task.habit_stack}</p>
                        </div>
                      )}
                      {task.completion_criteria && (
                        <div className="mb-3"><p className={`text-sm ${c.label}`}><strong>You're done when:</strong> {task.completion_criteria}</p></div>
                      )}
                      <div className="flex items-center gap-2 text-sm"><span>⏱️</span><span>Estimated: {task.estimated_time}</span></div>
                    </div>

                    {/* Timer */}
                    <div className={`${isDark ? 'bg-zinc-800' : 'bg-white'} rounded-lg p-4 mb-4`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-3xl font-mono font-bold">
                          {isTimerForThis ? formatTime(timerSeconds) : formatTime(parseTimeToSeconds(task.estimated_time))}
                        </div>
                        <div className="flex gap-2">
                          {!timerActive || !isTimerForThis ? (
                            <button onClick={() => handleStartTimer(task)} className={`${c.btnPrimary} px-4 py-2 rounded flex items-center gap-2`}>
                              <span>▶️</span> Start
                            </button>
                          ) : (
                            <>
                              <button onClick={handlePauseTimer} className={`${c.btnSecondary} px-4 py-2 rounded flex items-center gap-2`}><span>⏸️</span></button>
                              <button onClick={() => handleResetTimer(task)} className={`${c.btnSecondary} px-4 py-2 rounded`}><span>🔄</span></button>
                            </>
                          )}
                        </div>
                      </div>
                      {/* Sound Controls */}
                      <div className="flex gap-2 justify-center flex-wrap">
                        <label className={`flex items-center gap-2 px-3 py-1.5 rounded border cursor-pointer transition-colors text-xs ${
                          soundEnabled ? isDark ? 'bg-emerald-900/30 border-emerald-600' : 'bg-emerald-100 border-emerald-500'
                            : isDark ? 'bg-zinc-700 border-zinc-600' : 'bg-gray-100 border-gray-300'
                        }`}>
                          <input type="checkbox" checked={soundEnabled} onChange={(e) => setSoundEnabled(e.target.checked)} className="w-3.5 h-3.5" />
                          <span>🔔 Completion Sound</span>
                        </label>
                        <label className={`flex items-center gap-2 px-3 py-1.5 rounded border cursor-pointer transition-colors text-xs ${
                          tickingSoundEnabled ? isDark ? 'bg-emerald-900/30 border-emerald-600' : 'bg-emerald-100 border-emerald-500'
                            : isDark ? 'bg-zinc-700 border-zinc-600' : 'bg-gray-100 border-gray-300'
                        }`}>
                          <input type="checkbox" checked={tickingSoundEnabled} onChange={(e) => setTickingSoundEnabled(e.target.checked)} className="w-3.5 h-3.5" />
                          <span>⏱️ Ticking Sound</span>
                        </label>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => handleCompleteTask(task.task_id)}
                        className={`${c.btnPrimary} py-3 px-6 rounded-lg font-semibold flex items-center justify-center gap-2`}>
                        <span>✅</span> I Did It! +10pts
                      </button>
                      <button onClick={() => handleTaskTooHard()} className={`px-6 py-3 border-2 ${c.btnOutline} rounded-lg font-medium`}>
                        Too Hard
                      </button>
                    </div>

                    <button onClick={() => handleSkipTask(task.task_id)}
                      className={`w-full mt-2 text-sm ${c.textMuted} hover:underline flex items-center justify-center gap-1`}>
                      <span>⏭️</span> Skip for now
                    </button>
                  </>
                );
              })()}
            </div>
          )}

          {/* Post-result cross-references */}
          <div className="text-center space-y-2">
            <p className={`text-xs ${c.textMuted}`}>
              Need a focus boost while working?{' '}
              <a href="/FocusPocus" target="_blank" rel="noopener noreferrer" className={linkStyle}>Focus Pocus</a>{' '}
              keeps you on track with timers and body check-ins.
            </p>
            {energy <= 3 && (
              <p className={`text-xs ${c.textMuted}`}>
                Feeling like everything is on fire?{' '}
                <a href="/CrisisPrioritizer" target="_blank" rel="noopener noreferrer" className={linkStyle}>Crisis Prioritizer</a>{' '}
                helps when it's truly urgent.
              </p>
            )}
          </div>
        </div>
      )}

      {/* ── Stuck Help Modal ── */}
      {showStuckHelp && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setShowStuckHelp(false)}>
          <div className={`${c.card} border rounded-xl p-6 max-w-md w-full`} onClick={(e) => e.stopPropagation()}>
            <h3 className={`text-lg font-bold ${c.text} mb-4`}>🆘 Still Can't Start? That's Okay!</h3>
            <div className={`space-y-3 text-sm ${c.text}`}>
              <p><strong>Try this:</strong> Do ONLY the absolute minimum version of task 1.</p>
              <p><strong>Example:</strong> If task 1 is "Stand in doorway" → Just LOOK at the door.</p>
              <p><strong>Permission:</strong> You can stop after literally anything. Opening a folder counts. Looking at your desk counts.</p>
              <p className={`p-3 rounded ${isDark ? 'bg-emerald-900/20 text-emerald-100' : 'bg-emerald-100 text-emerald-900'}`}>
                <strong>Remember:</strong> The goal isn't finishing. The goal is starting. Any movement is progress.
              </p>
            </div>
            <button onClick={() => setShowStuckHelp(false)} className={`w-full ${c.btnPrimary} mt-4 py-2 rounded`}>Okay, I'll Try</button>
          </div>
        </div>
      )}

      {/* ── Timer Complete Modal ── */}
      {showTimerComplete && timerCompleteTaskId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className={`${c.card} border-4 border-emerald-500 rounded-xl p-6 max-w-md w-full`} onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-4">
              <div className="text-6xl mb-3">⏰</div>
              <h3 className={`text-xl font-bold ${c.text} mb-2`}>Time's Up!</h3>
              <p className={`text-sm ${c.textSecondary}`}>Did you complete this task?</p>
            </div>
            <div className="space-y-3">
              <button onClick={() => { handleCompleteTask(timerCompleteTaskId); setShowTimerComplete(false); setTimerCompleteTaskId(null); }}
                className={`w-full ${c.btnPrimary} py-3 rounded-lg font-semibold flex items-center justify-center gap-2`}>
                <span>✅</span> Yes, I Did It! +10pts
              </button>
              <button onClick={() => {
                const task = results?.micro_tasks?.find(t => t.task_id === timerCompleteTaskId);
                if (task) handleStartTimer(task);
                setShowTimerComplete(false);
              }} className={`w-full ${c.btnSecondary} py-3 rounded-lg font-semibold flex items-center justify-center gap-2`}>
                <span>🔄</span> Need More Time
              </button>
              <button onClick={() => { setShowTimerComplete(false); setTimerCompleteTaskId(null); setShowStuckHelp(true); }}
                className={`w-full border-2 ${c.btnOutline} py-3 rounded-lg font-semibold flex items-center justify-center gap-2`}>
                <span>😰</span> This Is Too Hard
              </button>
            </div>
            <p className={`text-xs ${c.textMuted} mt-4 text-center`}>No pressure — any progress counts! 💚</p>
          </div>
        </div>
      )}

      {/* ── Skip Confirm Modal (replaces window.confirm) ── */}
      {skipConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setSkipConfirm(null)}>
          <div className={`${c.card} border rounded-xl p-6 max-w-sm w-full`} onClick={(e) => e.stopPropagation()}>
            <h3 className={`text-lg font-bold ${c.text} mb-3`}>Skip this task?</h3>
            <p className={`text-sm ${c.textSecondary} mb-4`}>You can come back to it later.</p>
            <div className="flex gap-3">
              <button onClick={confirmSkip} className={`flex-1 ${c.btnPrimary} py-2 rounded font-semibold`}>Yes, Skip</button>
              <button onClick={() => setSkipConfirm(null)} className={`flex-1 ${c.btnSecondary} py-2 rounded`}>Keep Trying</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskAvalancheBreaker;
