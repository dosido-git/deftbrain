import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useClaudeAPI } from '../hooks/useClaudeAPI';
import { useTheme } from '../hooks/useTheme';
import { usePersistentState } from '../hooks/usePersistentState';
import { usePremium, PremiumGate, PremiumBadge } from '../hooks/usePremium';
import { BookmarkButton } from '../hooks/useBookmarks';
import { getToolById } from '../data/tools';
import { CopyBtn } from '../components/ActionButtons';

const NameAudit = () => {
  const { callToolEndpoint, loading } = useClaudeAPI();
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const toolData = getToolById('NameAudit');
  const { isUnlocked } = usePremium();

  // ─── Theme ───
  const linkStyle = isDark
    ? 'text-cyan-400 hover:text-cyan-300 underline underline-offset-2'
    : 'text-cyan-600 hover:text-cyan-700 underline underline-offset-2';
  const c = {
    card: isDark ? 'bg-zinc-800' : 'bg-white',
    cardAlt: isDark ? 'bg-zinc-700/50' : 'bg-slate-50',
    text: isDark ? 'text-zinc-50' : 'text-gray-900',
    textSecondary: isDark ? 'text-zinc-300' : 'text-gray-600',
    textMuted: isDark ? 'text-zinc-500' : 'text-gray-400',
    input: isDark ? 'bg-zinc-700 border-zinc-600 text-zinc-100 placeholder-zinc-400' : 'bg-white border-gray-300 text-gray-900 placeholder-gray-400',
    btnPrimary: isDark ? 'bg-cyan-600 hover:bg-cyan-500 text-white' : 'bg-cyan-600 hover:bg-cyan-700 text-white',
    btnSecondary: isDark ? 'bg-zinc-700 hover:bg-zinc-600 text-zinc-100' : 'bg-gray-100 hover:bg-gray-200 text-gray-700',
    border: isDark ? 'border-zinc-700' : 'border-gray-200',
    chip: (active) => active
      ? (isDark ? 'bg-cyan-900/40 border-cyan-500 text-cyan-200' : 'bg-cyan-100 border-cyan-500 text-cyan-800')
      : (isDark ? 'border-zinc-600 text-zinc-400 hover:border-zinc-500' : 'border-gray-200 text-gray-500 hover:border-gray-300'),
    success: isDark ? 'bg-green-900/20 border-green-700 text-green-200' : 'bg-green-50 border-green-300 text-green-800',
    warning: isDark ? 'bg-amber-900/20 border-amber-700 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-800',
    danger: isDark ? 'bg-red-900/20 border-red-700 text-red-200' : 'bg-red-50 border-red-200 text-red-800',
    info: isDark ? 'bg-blue-900/20 border-blue-700 text-blue-200' : 'bg-blue-50 border-blue-200 text-blue-800',
    purple: isDark ? 'bg-purple-900/20 border-purple-700 text-purple-200' : 'bg-purple-50 border-purple-200 text-purple-800',
    cyan: isDark ? 'bg-cyan-900/20 border-cyan-700 text-cyan-200' : 'bg-cyan-50 border-cyan-200 text-cyan-800',
  };

  // ─── State ───
  const [mode, setMode] = useState('analyze'); // 'analyze' | 'compare'
  const [name, setName] = useState('');
  const [context, setContext] = useState('');
  const [industry, setIndustry] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [expandedSections, setExpandedSections] = useState({});

  // Compare mode state
  const [compareNames, setCompareNames] = useState(['', '']);
  const [compareResults, setCompareResults] = useState(null);
  const [compareLoading, setCompareLoading] = useState(false);

  // ─── Audit History (persistent) ───
  const [auditHistory, setAuditHistory] = usePersistentState('nameaudit-history', []);
  const [showHistory, setShowHistory] = useState(false);

  // ─── Analyze Another (quick input in results view) ───
  const [quickName, setQuickName] = useState('');

  // ─── Fix This Name State ───
  const [fixLoading, setFixLoading] = useState(false);
  const [fixResults, setFixResults] = useState(null);

  // ─── Section Explainers ───
  const [showExplainer, setShowExplainer] = useState({});

  // ─── Compare from Analyze ───
  const [analyzeToCompare, setAnalyzeToCompare] = useState(false);
  const [compareSecondName, setCompareSecondName] = useState('');

  // ─── Audience Reaction Simulator (#1) ───
  const [reactionsLoading, setReactionsLoading] = useState(false);
  const [reactionsResults, setReactionsResults] = useState(null);

  // ─── Context Deep Dive (#3) ───
  const [deepDiveLoading, setDeepDiveLoading] = useState(false);
  const [deepDiveResults, setDeepDiveResults] = useState(null);

  // ─── Name Evolution Timeline (#4) ───
  const [evolutionTimeline, setEvolutionTimeline] = usePersistentState('nameaudit-evolution', []);

  // ─── Name Psychology Profile (#6) ───
  // (rendered from existing results + computed frontend-side)

  // ─── Context Mockups (#9) ───
  const [showMockups, setShowMockups] = useState(false);

  // ─── Second Opinion (#10) ───
  const [secondOpinionLoading, setSecondOpinionLoading] = useState(false);
  const [secondOpinionResults, setSecondOpinionResults] = useState(null);

  // ─── Naming Journal (#11) ───
  const [journalEntries, setJournalEntries] = usePersistentState('nameaudit-journal', {});
  const [journalDraft, setJournalDraft] = useState('');

  // ─── URL param handoff (from NameStorm) ───
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const nameParam = params.get('name');
    if (nameParam) {
      setName(nameParam);
      // Clean up URL without reload
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  // ─── Options ───
  const contexts = [
    { value: 'Business', icon: '🏢' },
    { value: 'Product', icon: '📦' },
    { value: 'App', icon: '📱' },
    { value: 'Domain Name', icon: '🌐' },
    { value: 'Band / Music Project', icon: '🎸' },
    { value: 'Pet', icon: '🐾' },
    { value: 'Baby', icon: '👶' },
    { value: 'Character (D&D/Fiction)', icon: '⚔️' },
    { value: 'Creative Project', icon: '🎨' },
    { value: 'Event', icon: '🎪' },
    { value: 'Username / Handle', icon: '📱' },
    { value: 'Other', icon: '✨' },
  ];

  // ─── Handlers ───
  const toggleSection = (key) => setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }));
  const toggleExplainer = (key) => setShowExplainer(prev => ({ ...prev, [key]: !prev[key] }));

  // ─── Expand / Collapse All ───
  const allSectionIds = ['impression', 'phonetic', 'memorability', 'radio', 'visual', 'language', 'abbreviation', 'competitive', 'seo', 'longevity', 'tld', 'domain-tests', 'emotion', 'availability'];
  const allExpanded = allSectionIds.every(id => expandedSections[id]);
  const expandAll = () => setExpandedSections(Object.fromEntries(allSectionIds.map(id => [id, true])));
  const collapseAll = () => setExpandedSections({});

  // ─── Pronunciation Audio ───
  const speakName = (text) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.85;
    utterance.pitch = 1;
    window.speechSynthesis.speak(utterance);
  };

  // ─── Save to History ───
  const saveToHistory = useCallback((data) => {
    const entry = {
      id: Date.now(),
      name: data.name_analyzed,
      grade: data.overall_grade,
      score: data.overall_score,
      context,
      timestamp: new Date().toISOString(),
      strengths: data.strengths?.length || 0,
      weaknesses: data.weaknesses?.length || 0,
      dealBreakers: data.deal_breakers?.length || 0,
    };
    setAuditHistory(prev => [entry, ...prev.filter(e => e.name !== data.name_analyzed)].slice(0, 30));
  }, [context, setAuditHistory]);

  const loadFromHistory = (entry) => {
    setName(entry.name);
    setContext(entry.context || '');
    setShowHistory(false);
  };

  // ─── Analyze Another (quick re-analyze from results) ───
  const handleQuickAnalyze = async () => {
    if (!quickName.trim()) return;
    setName(quickName.trim());
    setError(''); setResults(null); setFixResults(null);
    setReactionsResults(null); setDeepDiveResults(null); setSecondOpinionResults(null);
    setShowMockups(false);
    try {
      const data = await callToolEndpoint('nameaudit', {
        name: quickName.trim(), context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
      });
      setResults(data);
      setExpandedSections({ phonetic: true, memorability: true, language: true });
      setQuickName('');
      saveToHistory(data);
      saveToEvolution(data);
    } catch (err) {
      setError(err.message || 'Failed to analyze name.');
    }
  };

  // ─── Compare from Analyze ───
  const handleCompareFromAnalyze = async () => {
    if (!compareSecondName.trim() || !results?.name_analyzed) return;
    const names = [results.name_analyzed, compareSecondName.trim()];
    setError(''); setCompareResults(null); setResults(null); setCompareLoading(true);
    setAnalyzeToCompare(false);
    setCompareNames(names);
    setMode('compare');
    try {
      const data = await callToolEndpoint('nameaudit/compare', {
        names, context,
        industry: industry.trim() || null,
      });
      setCompareResults(data);
    } catch (err) {
      setError(err.message || 'Failed to compare names.');
    }
    setCompareLoading(false);
  };

  // ─── Fix This Name Handler ───
  const handleFixThisName = async () => {
    if (!results || fixLoading) return;
    setFixLoading(true);
    try {
      const data = await callToolEndpoint('nameaudit/fix', {
        name: results.name_analyzed,
        context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
        grade: results.overall_grade,
        strengths: results.strengths,
        weaknesses: results.weaknesses,
        dealBreakers: results.deal_breakers,
        overallSummary: results.overall_summary,
      });
      setFixResults(data);
    } catch (err) {
      console.error('Fix this name failed:', err);
      setError('Failed to generate fixes. Please try again.');
    }
    setFixLoading(false);
  };

  // ─── PDF Export ───
  const handlePdfExport = () => {
    const content = buildFullText();
    const pw = window.open('', '_blank');
    if (!pw) return;
    const grade = results?.overall_grade || '';
    const score = results?.overall_score != null ? `${results.overall_score}/100` : '';
    pw.document.write(`<!DOCTYPE html><html><head><title>NameAudit Report — ${name}</title>
<style>
  body{font-family:Georgia,serif;max-width:750px;margin:40px auto;padding:0 30px;color:#1a1a1a;line-height:1.7;font-size:13px;}
  pre{white-space:pre-wrap;word-wrap:break-word;font-family:inherit;margin:0;}
  .header{text-align:center;border-bottom:2px solid #1a1a1a;padding-bottom:20px;margin-bottom:25px;}
  .header h1{font-size:22px;margin:0 0 6px 0;}
  .header .grade{font-size:16px;font-weight:bold;margin:8px 0;}
  .branding{text-align:center;margin-top:40px;padding-top:15px;border-top:1px solid #ccc;color:#888;font-size:11px;}
  @media print{body{margin:20px;} @page{margin:1.5cm;}}
</style></head><body>
<div class="header">
  <h1>NameAudit Report</h1>
  <p style="font-size:18px;font-weight:bold;">"${results?.name_analyzed || name}"</p>
  <p class="grade">Grade: ${grade} ${score ? `· Score: ${score}` : ''}</p>
  <p style="font-size:11px;color:#666;">${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
</div>
<pre>${content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre>
<div class="branding">Generated by DeftBrain · deftbrain.com</div>
</body></html>`);
    pw.document.close(); pw.focus(); setTimeout(() => pw.print(), 300);
  };

  // ─── Section Explainer Data ───
  const sectionExplainers = {
    impression: "First impressions form in milliseconds. This section captures the gut reaction, associations, and personality your name projects before anyone knows what you do.",
    phonetic: "How a name sounds affects how people feel about it. Hard consonants project power, soft vowels feel warm. Mouth feel determines whether the name is pleasant or awkward to say repeatedly.",
    memorability: "A name is only as good as people's ability to recall it. These 5 tests simulate real-world memory challenges — from casual mention to noisy environments.",
    radio: "If someone hears your name on a podcast, can they Google it? The radio test predicts how often people will misspell your name from hearing it alone.",
    visual: "Names live on screens, signs, and cards. This section checks how yours looks in different cases, as a URL, and whether it has visual ambiguity (like 'Iliad' where I and l look identical).",
    language: "A name that works in English might mean something unfortunate in Japanese or Spanish. This scan checks 15+ languages for unintended meanings, sounds, or cultural associations.",
    abbreviation: "People will shorten your name. This section checks whether the natural nicknames, initials, and hashtag form are clean — or accidentally spell something problematic.",
    competitive: "Is your name already taken by someone in your space? Similar-sounding competitors create confusion and dilute your brand equity.",
    seo: "Can people find you by searching your name? Generic or already-popular names make SEO an uphill battle from day one.",
    longevity: "Trendy names age fast. This checks whether your name is tied to a passing trend, a specific era, or a technology that might become obsolete.",
    emotion: "Beyond logic, names trigger emotional responses. This section maps the sensory and personality associations your name evokes.",
  };

  // ─── Radar Chart Component ───
  const RadarChart = ({ scores }) => {
    if (!scores || Object.keys(scores).length < 3) return null;
    const labels = {
      first_impression: 'Impression', phonetics: 'Phonetics', memorability: 'Memory',
      radio_test: 'Radio', visual: 'Visual', global_safety: 'Global',
      abbreviations: 'Abbrev.', competitive: 'Compet.', seo: 'SEO',
      longevity: 'Longevity', emotional_resonance: 'Emotion',
    };
    const entries = Object.entries(scores).filter(([k]) => labels[k]);
    if (entries.length < 3) return null;
    const n = entries.length;
    const cx = 120, cy = 120, maxR = 90;
    const angleStep = (2 * Math.PI) / n;
    const getPoint = (i, val) => {
      const angle = angleStep * i - Math.PI / 2;
      const r = (val / 10) * maxR;
      return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
    };
    const gridLevels = [2, 4, 6, 8, 10];
    const dataPoints = entries.map(([, v], i) => getPoint(i, v));
    const pathD = dataPoints.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ') + 'Z';

    return (
      <div className="flex justify-center">
        <svg width="240" height="240" viewBox="0 0 240 240">
          {/* Grid */}
          {gridLevels.map(level => {
            const pts = entries.map((_, i) => getPoint(i, level));
            return <polygon key={level} points={pts.map(p => `${p.x},${p.y}`).join(' ')}
              fill="none" stroke={isDark ? '#3f3f46' : '#e5e7eb'} strokeWidth="0.5" />;
          })}
          {/* Axes */}
          {entries.map((_, i) => {
            const p = getPoint(i, 10);
            return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y}
              stroke={isDark ? '#3f3f46' : '#e5e7eb'} strokeWidth="0.5" />;
          })}
          {/* Data polygon */}
          <polygon points={dataPoints.map(p => `${p.x},${p.y}`).join(' ')}
            fill={isDark ? 'rgba(34,211,238,0.15)' : 'rgba(8,145,178,0.12)'}
            stroke={isDark ? '#22d3ee' : '#0891b2'} strokeWidth="2" />
          {/* Data dots */}
          {dataPoints.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r="3"
              fill={isDark ? '#22d3ee' : '#0891b2'} />
          ))}
          {/* Labels */}
          {entries.map(([k], i) => {
            const p = getPoint(i, 12.2);
            return <text key={i} x={p.x} y={p.y} textAnchor="middle" dominantBaseline="middle"
              className={`text-[8px] font-medium ${isDark ? 'fill-zinc-400' : 'fill-gray-500'}`}>
              {labels[k]}
            </text>;
          })}
        </svg>
      </div>
    );
  };

  // ═══════════════════════════════════════════════════
  // NEW FEATURE HANDLERS
  // ═══════════════════════════════════════════════════

  // ─── #1: Audience Reaction Simulator ───
  const handleReactions = async () => {
    if (!results || reactionsLoading) return;
    setReactionsLoading(true);
    try {
      const data = await callToolEndpoint('nameaudit/reactions', {
        name: results.name_analyzed,
        context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
        overallSummary: results.overall_summary,
        personality: results.first_impression?.personality_projected,
      });
      setReactionsResults(data);
    } catch (err) {
      console.error('Reactions failed:', err);
    }
    setReactionsLoading(false);
  };

  // ─── #3: Context-Specific Deep Dive ───
  const handleDeepDive = async () => {
    if (!results || deepDiveLoading) return;
    setDeepDiveLoading(true);
    try {
      const data = await callToolEndpoint('nameaudit/deepdive', {
        name: results.name_analyzed,
        context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
        grade: results.overall_grade,
        score: results.overall_score,
      });
      setDeepDiveResults(data);
    } catch (err) {
      console.error('Deep dive failed:', err);
    }
    setDeepDiveLoading(false);
  };

  // ─── #4: Evolution Timeline — save on each audit ───
  const saveToEvolution = useCallback((data) => {
    setEvolutionTimeline(prev => {
      const entry = {
        name: data.name_analyzed,
        score: data.overall_score,
        grade: data.overall_grade,
        timestamp: new Date().toISOString(),
        weaknessCount: data.weaknesses?.length || 0,
        dealBreakerCount: data.deal_breakers?.length || 0,
      };
      return [...prev, entry].slice(-50); // keep last 50
    });
  }, [setEvolutionTimeline]);

  // ─── #6: Name Psychology (computed from existing phonetic data) ───
  const computePsychology = (nameStr) => {
    if (!nameStr) return null;
    const lower = nameStr.toLowerCase();
    const vowels = (lower.match(/[aeiou]/g) || []);
    const consonants = (lower.match(/[bcdfghjklmnpqrstvwxyz]/g) || []);
    const frontVowels = (lower.match(/[eiy]/g) || []).length;
    const backVowels = (lower.match(/[aou]/g) || []).length;
    const plosives = (lower.match(/[bpdtgk]/g) || []).length;
    const sibilants = (lower.match(/[szʃʒ]|sh|ch/g) || []).length;
    const nasals = (lower.match(/[mn]/g) || []).length;
    const liquids = (lower.match(/[lr]/g) || []).length;

    // Bouba/Kiki: round sounds (m,n,l,o,u,b) vs sharp sounds (k,t,i,e,z,x)
    const roundSounds = (lower.match(/[mnloub]/g) || []).length;
    const sharpSounds = (lower.match(/[ktiezxp]/g) || []).length;
    const boubaKiki = roundSounds > sharpSounds ? 'Bouba (soft/round)' : sharpSounds > roundSounds ? 'Kiki (sharp/angular)' : 'Balanced';

    // Size symbolism
    const sizeSymbol = frontVowels > backVowels ? 'Small / Light / Fast' : backVowels > frontVowels ? 'Large / Heavy / Grounded' : 'Neutral';

    // Consonant personality
    const traits = [];
    if (plosives >= 2) traits.push('Energetic & impactful');
    if (sibilants >= 2) traits.push('Sleek & swift');
    if (nasals >= 2) traits.push('Warm & approachable');
    if (liquids >= 2) traits.push('Flowing & elegant');
    if (vowels.length > consonants.length) traits.push('Open & inviting');
    if (consonants.length > vowels.length + 1) traits.push('Dense & technical');

    // Lexical neighborhood (very rough heuristic)
    const neighborDensity = lower.length <= 4 ? 'High (many similar words)' : lower.length <= 7 ? 'Medium' : 'Low (distinctive)';

    return { boubaKiki, sizeSymbol, traits, neighborDensity, vowelRatio: `${vowels.length}V : ${consonants.length}C` };
  };

  // ─── #7: Pronunciation Confidence Map regions ───
  const pronunciationRegions = (nameStr) => {
    if (!nameStr) return [];
    const lower = nameStr.toLowerCase();
    const hasR = /r/.test(lower);
    const hasTh = /th/.test(lower);
    const hasW = /w/.test(lower);
    const hasH = /h/.test(lower);
    const hasVowelClusters = /[aeiou]{2,}/.test(lower);
    const hasSh = /sh/.test(lower);
    const hasTz = /tz|ts/.test(lower);
    const len = lower.length;
    const isSimple = len <= 6 && !hasTh && !hasVowelClusters;

    const regions = [
      { name: 'English', confidence: 'high', emoji: '🇬🇧' },
      { name: 'Spanish', confidence: hasTh ? 'medium' : hasW ? 'medium' : 'high', emoji: '🇪🇸' },
      { name: 'French', confidence: hasH ? 'medium' : hasTh ? 'low' : 'high', emoji: '🇫🇷' },
      { name: 'German', confidence: hasW ? 'medium' : 'high', emoji: '🇩🇪' },
      { name: 'Mandarin', confidence: hasR && hasTh ? 'low' : hasR ? 'medium' : isSimple ? 'high' : 'medium', emoji: '🇨🇳' },
      { name: 'Japanese', confidence: /[lv]/.test(lower) ? 'medium' : hasTh ? 'low' : 'high', emoji: '🇯🇵' },
      { name: 'Korean', confidence: /[fvz]/.test(lower) ? 'medium' : 'high', emoji: '🇰🇷' },
      { name: 'Arabic', confidence: /[pv]/.test(lower) ? 'medium' : 'high', emoji: '🇸🇦' },
      { name: 'Hindi', confidence: 'high', emoji: '🇮🇳' },
      { name: 'Portuguese', confidence: hasTh ? 'medium' : 'high', emoji: '🇧🇷' },
      { name: 'Russian', confidence: hasTh ? 'low' : hasH ? 'medium' : 'high', emoji: '🇷🇺' },
      { name: 'Turkish', confidence: hasW || hasTh ? 'medium' : 'high', emoji: '🇹🇷' },
    ];
    return regions;
  };

  // ─── #10: Second Opinion ───
  const handleSecondOpinion = async () => {
    if (!results || secondOpinionLoading) return;
    setSecondOpinionLoading(true);
    try {
      const data = await callToolEndpoint('nameaudit/second-opinion', {
        name: results.name_analyzed,
        context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
        firstOpinion: {
          grade: results.overall_grade,
          score: results.overall_score,
          strengths: results.strengths,
          weaknesses: results.weaknesses,
          dealBreakers: results.deal_breakers,
        },
      });
      setSecondOpinionResults(data);
    } catch (err) {
      console.error('Second opinion failed:', err);
    }
    setSecondOpinionLoading(false);
  };

  // ─── #11: Journal — add note to a name ───
  const addJournalNote = (nameKey) => {
    if (!journalDraft.trim()) return;
    const note = {
      id: Date.now(),
      text: journalDraft.trim(),
      timestamp: new Date().toISOString(),
    };
    setJournalEntries(prev => ({
      ...prev,
      [nameKey]: [...(prev[nameKey] || []), note],
    }));
    setJournalDraft('');
  };

  const deleteJournalNote = (nameKey, noteId) => {
    setJournalEntries(prev => ({
      ...prev,
      [nameKey]: (prev[nameKey] || []).filter(n => n.id !== noteId),
    }));
  };

  // ─── #9: Context Mockup Data ───
  const mockupContexts = {
    'Business': ['app_store', 'business_card', 'email_sig', 'hero'],
    'Product': ['app_store', 'hero', 'email_sig', 'packaging'],
    'App': ['app_store', 'hero', 'notification', 'email_sig'],
    'Domain Name': ['browser_bar', 'email_sig', 'hero', 'business_card'],
    'Band / Music Project': ['spotify', 'poster', 'merch'],
    'Baby': ['birth_announcement', 'nametag'],
    'Pet': ['nametag', 'vet_record'],
  };

  const MockupCard = ({ type, displayName }) => {
    const n = displayName || results?.name_analyzed || 'Name';
    const slug = n.toLowerCase().replace(/[^a-z0-9]/g, '');
    const initial = n.charAt(0).toUpperCase();
    const mockups = {
      app_store: (
        <div className={`p-4 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>App Store Listing</p>
          <div className="flex items-center gap-3">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-bold ${isDark ? 'bg-cyan-600 text-white' : 'bg-cyan-500 text-white'}`}>{initial}</div>
            <div>
              <p className={`font-bold ${c.text}`}>{n}</p>
              <p className={`text-xs ${c.textMuted}`}>{industry || 'Productivity'} · ★★★★★ 4.8</p>
              <p className={`text-[10px] ${c.textMuted}`}>{slug}.com</p>
            </div>
          </div>
        </div>
      ),
      business_card: (
        <div className={`p-6 rounded-lg border-2 ${isDark ? 'border-zinc-600 bg-zinc-900' : 'border-gray-300 bg-white'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-3`}>Business Card</p>
          <p className={`text-xl font-bold tracking-wide ${c.text}`} style={{ fontFamily: 'Georgia, serif' }}>{n}</p>
          <p className={`text-[10px] ${c.textMuted} mt-1`}>{industry || 'Innovation for everyone'}</p>
          <div className={`mt-3 pt-2 border-t ${c.border}`}>
            <p className={`text-[10px] ${c.textMuted}`}>hello@{slug}.com · {slug}.com</p>
          </div>
        </div>
      ),
      email_sig: (
        <div className={`p-4 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Email Signature</p>
          <div className={`text-xs ${c.textSecondary} space-y-0.5`}>
            <p className="font-semibold">Alex Johnson</p>
            <p>Co-founder & CEO, <span className={`font-bold ${c.text}`}>{n}</span></p>
            <p className={`${c.textMuted}`}>alex@{slug}.com | {slug}.com</p>
          </div>
        </div>
      ),
      hero: (
        <div className={`p-6 rounded-lg border ${c.border} ${isDark ? 'bg-gradient-to-b from-zinc-800 to-zinc-900' : 'bg-gradient-to-b from-gray-50 to-white'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-3`}>Website Hero</p>
          <p className={`text-2xl font-bold ${c.text} mb-1`}>{n}</p>
          <p className={`text-sm ${c.textSecondary}`}>{industry ? `The future of ${industry.toLowerCase()}` : 'Built for what comes next'}</p>
          <div className={`inline-block mt-3 px-4 py-1.5 rounded-full text-xs font-semibold ${isDark ? 'bg-cyan-600 text-white' : 'bg-cyan-500 text-white'}`}>Get Started</div>
        </div>
      ),
      browser_bar: (
        <div className={`p-3 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Browser Bar</p>
          <div className={`flex items-center gap-2 p-2 rounded border ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-gray-300'}`}>
            <span className="text-xs">🔒</span>
            <span className={`text-sm font-mono ${c.text}`}>https://{slug}.com</span>
          </div>
        </div>
      ),
      notification: (
        <div className={`p-3 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Push Notification</p>
          <div className={`flex items-center gap-2.5 p-2.5 rounded-lg ${isDark ? 'bg-zinc-800' : 'bg-white'} shadow`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${isDark ? 'bg-cyan-600 text-white' : 'bg-cyan-500 text-white'}`}>{initial}</div>
            <div>
              <p className={`text-xs font-bold ${c.text}`}>{n}</p>
              <p className={`text-[10px] ${c.textMuted}`}>Your weekly report is ready</p>
            </div>
          </div>
        </div>
      ),
      spotify: (
        <div className={`p-4 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Spotify Artist Page</p>
          <div className="flex items-center gap-3">
            <div className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold ${isDark ? 'bg-green-700 text-white' : 'bg-green-600 text-white'}`}>{initial}</div>
            <div>
              <p className={`font-bold ${c.text}`}>{n}</p>
              <p className={`text-xs ${c.textMuted}`}>23,847 monthly listeners</p>
            </div>
          </div>
        </div>
      ),
      poster: (
        <div className={`p-6 rounded-lg border-2 ${isDark ? 'border-zinc-500 bg-zinc-900' : 'border-gray-400 bg-gray-50'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-3`}>Tour Poster</p>
          <p className={`text-3xl font-black tracking-wider uppercase ${c.text}`} style={{ fontFamily: 'Impact, sans-serif' }}>{n}</p>
          <p className={`text-xs ${c.textMuted} mt-2`}>LIVE AT THE FILLMORE · OCT 15</p>
        </div>
      ),
      merch: (
        <div className={`p-4 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Merch / T-Shirt</p>
          <div className={`py-6 rounded ${isDark ? 'bg-zinc-800' : 'bg-gray-800'}`}>
            <p className="text-white text-lg font-bold tracking-widest uppercase">{n}</p>
          </div>
        </div>
      ),
      packaging: (
        <div className={`p-4 rounded-lg border-2 ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-white'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Product Label</p>
          <p className={`text-lg font-bold tracking-wider ${c.text}`} style={{ fontFamily: 'Georgia, serif' }}>{n}</p>
          <div className={`h-px ${isDark ? 'bg-zinc-600' : 'bg-gray-300'} my-1.5 mx-8`}></div>
          <p className={`text-[10px] tracking-widest uppercase ${c.textMuted}`}>{industry || 'Premium Quality'}</p>
        </div>
      ),
      birth_announcement: (
        <div className={`p-6 rounded-lg border-2 ${isDark ? 'border-pink-700 bg-pink-950/20' : 'border-pink-300 bg-pink-50'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Birth Announcement</p>
          <p className={`text-xs tracking-widest uppercase ${c.textMuted}`}>welcome to the world</p>
          <p className={`text-3xl font-light mt-1 ${c.text}`} style={{ fontFamily: 'Georgia, serif' }}>{n}</p>
          <p className={`text-xs ${c.textMuted} mt-1`}>7 lbs 4 oz · January 15, 2026</p>
        </div>
      ),
      nametag: (
        <div className={`p-4 rounded-lg border-2 ${isDark ? 'border-amber-700 bg-amber-950/20' : 'border-amber-300 bg-amber-50'} text-center`}>
          <p className={`text-xs ${c.textMuted} mb-1`}>Name Tag</p>
          <p className={`text-2xl font-bold ${c.text}`}>{n}</p>
        </div>
      ),
      vet_record: (
        <div className={`p-4 rounded-lg border ${c.border} ${isDark ? 'bg-zinc-900' : 'bg-gray-50'}`}>
          <p className={`text-xs ${c.textMuted} mb-2`}>Vet Record</p>
          <div className={`text-xs ${c.textSecondary} space-y-0.5`}>
            <p><span className="font-bold">Patient:</span> <span className={`font-bold ${c.text}`}>{n}</span></p>
            <p><span className="font-bold">Species:</span> Canine · <span className="font-bold">Breed:</span> Golden Retriever</p>
            <p><span className="font-bold">Owner:</span> Johnson, A.</p>
          </div>
        </div>
      ),
    };
    return mockups[type] || null;
  };

  // ─── #7: Pronunciation Confidence Map Component ───
  const PronunciationMap = ({ nameStr }) => {
    const regions = pronunciationRegions(nameStr);
    if (!regions.length) return null;
    const confColor = (conf) => {
      if (conf === 'high') return isDark ? 'bg-green-900/40 border-green-700 text-green-300' : 'bg-green-50 border-green-300 text-green-700';
      if (conf === 'medium') return isDark ? 'bg-amber-900/40 border-amber-700 text-amber-300' : 'bg-amber-50 border-amber-300 text-amber-700';
      return isDark ? 'bg-red-900/40 border-red-700 text-red-300' : 'bg-red-50 border-red-300 text-red-700';
    };
    return (
      <div className="flex flex-wrap gap-2">
        {regions.map(r => (
          <div key={r.name} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium ${confColor(r.confidence)}`}>
            <span>{r.emoji}</span> {r.name}
            <span className="font-bold">{r.confidence === 'high' ? '✓' : r.confidence === 'medium' ? '~' : '✗'}</span>
          </div>
        ))}
      </div>
    );
  };

  // ─── #4: Evolution Timeline Component ───
  const EvolutionTimeline = () => {
    if (evolutionTimeline.length < 2) return null;
    const maxScore = Math.max(...evolutionTimeline.map(e => e.score || 0));
    return (
      <div className={`${c.card} rounded-xl shadow-lg p-6`}>
        <h3 className={`font-bold ${c.text} mb-3 flex items-center gap-2`}>
          <span>📈</span> Name Evolution Timeline
        </h3>
        <p className={`text-xs ${c.textMuted} mb-3`}>Track your naming journey — how scores changed across audits</p>
        <div className="flex items-end gap-1 h-24 mb-2">
          {evolutionTimeline.slice(-15).map((entry, i) => {
            const pct = entry.score ? (entry.score / 100) * 100 : 10;
            const barColor = entry.score >= 70 ? (isDark ? 'bg-green-500' : 'bg-green-500')
              : entry.score >= 50 ? (isDark ? 'bg-amber-500' : 'bg-amber-500')
              : (isDark ? 'bg-red-500' : 'bg-red-500');
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                <div className={`w-full rounded-t ${barColor} transition-all`} style={{ height: `${pct}%`, minHeight: '4px' }}></div>
                <p className={`text-[8px] ${c.textMuted} truncate max-w-full`}>{entry.name?.slice(0, 6)}</p>
                {/* Tooltip */}
                <div className={`absolute bottom-full mb-1 left-1/2 -translate-x-1/2 hidden group-hover:block z-10 px-2 py-1 rounded text-xs whitespace-nowrap ${isDark ? 'bg-zinc-700 text-zinc-100' : 'bg-gray-800 text-white'}`}>
                  {entry.name}: {entry.score}/100 ({entry.grade})
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex justify-between">
          <span className={`text-[9px] ${c.textMuted}`}>← Older</span>
          <span className={`text-[9px] ${c.textMuted}`}>Newer →</span>
        </div>
        <button onClick={() => { if (window.confirm('Clear evolution timeline?')) setEvolutionTimeline([]); }}
          className={`text-xs ${c.textMuted} hover:underline mt-2`}>Clear timeline</button>
      </div>
    );
  };

  const handleAnalyze = async () => {
    if (!name.trim()) { setError('Please enter a name to analyze'); return; }
    if (!context) { setError('Please select what this name is for'); return; }
    setError(''); setResults(null); setFixResults(null);
    setReactionsResults(null); setDeepDiveResults(null); setSecondOpinionResults(null);
    setShowMockups(false);
    try {
      const data = await callToolEndpoint('nameaudit', {
        name: name.trim(), context,
        industry: industry.trim() || null,
        targetAudience: targetAudience.trim() || null,
      });
      setResults(data);
      setExpandedSections({ phonetic: true, memorability: true, language: true });
      saveToHistory(data);
      saveToEvolution(data);
    } catch (err) {
      setError(err.message || 'Failed to analyze name.');
    }
  };

  const handleCompare = async () => {
    const filled = compareNames.filter(n => n.trim());
    if (filled.length < 2) { setError('Enter at least 2 names to compare'); return; }
    setError(''); setCompareResults(null); setCompareLoading(true);
    try {
      const data = await callToolEndpoint('nameaudit/compare', {
        names: filled.map(n => n.trim()), context,
        industry: industry.trim() || null,
      });
      setCompareResults(data);
    } catch (err) {
      setError(err.message || 'Failed to compare names.');
    }
    setCompareLoading(false);
  };

  const reset = () => {
    setName(''); setContext(''); setIndustry(''); setTargetAudience('');
    setResults(null); setError(''); setCompareResults(null);
    setCompareNames(['', '']); setFixResults(null); setFixLoading(false);
    setQuickName(''); setAnalyzeToCompare(false); setCompareSecondName('');
    setShowExplainer({}); setReactionsResults(null); setDeepDiveResults(null);
    setSecondOpinionResults(null); setShowMockups(false); setJournalDraft('');
  };

  const gradeColors = {
    STRONG: isDark ? 'bg-green-900/30 border-green-600 text-green-300' : 'bg-green-100 border-green-400 text-green-800',
    GOOD: isDark ? 'bg-emerald-900/30 border-emerald-600 text-emerald-300' : 'bg-emerald-100 border-emerald-400 text-emerald-800',
    FAIR: isDark ? 'bg-amber-900/30 border-amber-600 text-amber-300' : 'bg-amber-100 border-amber-400 text-amber-800',
    WEAK: isDark ? 'bg-orange-900/30 border-orange-600 text-orange-300' : 'bg-orange-100 border-orange-400 text-orange-800',
    RECONSIDER: isDark ? 'bg-red-900/30 border-red-600 text-red-300' : 'bg-red-100 border-red-400 text-red-800',
  };

  const PassFail = ({ pass, notes }) => (
    <div className="flex items-start gap-2">
      <span className="flex-shrink-0 mt-0.5">{pass ? '✅' : '❌'}</span>
      <span className={`text-sm ${c.textSecondary}`}>{notes}</span>
    </div>
  );

  const langSeverityStyle = (sev) => {
    if (sev === 'positive') return c.success;
    if (sev === 'problem') return c.danger;
    if (sev === 'caution') return c.warning;
    return c.cardAlt;
  };

  const langSeverityIcon = (sev) => {
    if (sev === 'positive') return <span>✅</span>;
    if (sev === 'problem') return <span>❌</span>;
    if (sev === 'caution') return <span>⚠️</span>;
    return <span>➖</span>;
  };

  // ─── Score Components ───
  const scoreColor = (score, max = 100) => {
    const pct = (score / max) * 100;
    if (pct >= 80) return isDark ? 'text-green-400' : 'text-green-600';
    if (pct >= 60) return isDark ? 'text-amber-400' : 'text-amber-600';
    if (pct >= 40) return isDark ? 'text-orange-400' : 'text-orange-600';
    return isDark ? 'text-red-400' : 'text-red-600';
  };

  const scoreBg = (score, max = 100) => {
    const pct = (score / max) * 100;
    if (pct >= 80) return isDark ? 'bg-green-500' : 'bg-green-500';
    if (pct >= 60) return isDark ? 'bg-amber-500' : 'bg-amber-500';
    if (pct >= 40) return isDark ? 'bg-orange-500' : 'bg-orange-500';
    return isDark ? 'bg-red-500' : 'bg-red-500';
  };

  const AnimatedScore = ({ score, size = 'lg' }) => {
    const [display, setDisplay] = useState(0);
    const frameRef = useRef(null);

    useEffect(() => {
      if (score == null) return;
      let start = null;
      const duration = 1200;
      const animate = (ts) => {
        if (!start) start = ts;
        const progress = Math.min((ts - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        setDisplay(Math.round(eased * score));
        if (progress < 1) frameRef.current = requestAnimationFrame(animate);
      };
      frameRef.current = requestAnimationFrame(animate);
      return () => { if (frameRef.current) cancelAnimationFrame(frameRef.current); };
    }, [score]);

    if (score == null) return null;

    const isLarge = size === 'lg';
    const radius = isLarge ? 54 : 20;
    const stroke = isLarge ? 8 : 4;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (display / 100) * circumference;
    const dim = isLarge ? 128 : 48;

    return (
      <div className={`relative inline-flex items-center justify-center ${isLarge ? 'w-32 h-32' : 'w-12 h-12'}`}>
        <svg width={dim} height={dim} className="-rotate-90">
          <circle cx={dim / 2} cy={dim / 2} r={radius} fill="none"
            stroke={isDark ? '#3f3f46' : '#e5e7eb'} strokeWidth={stroke} />
          <circle cx={dim / 2} cy={dim / 2} r={radius} fill="none"
            className={scoreBg(score)} strokeWidth={stroke}
            strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.1s ease-out' }} />
        </svg>
        <span className={`absolute font-bold ${scoreColor(score)} ${isLarge ? 'text-3xl' : 'text-xs'}`}>
          {display}
        </span>
      </div>
    );
  };

  const ScoreBar = ({ score, max = 10 }) => {
    if (score == null) return null;
    const pct = (score / max) * 100;
    return (
      <div className="flex items-center gap-2 ml-auto">
        <div className={`w-16 h-1.5 rounded-full ${isDark ? 'bg-zinc-700' : 'bg-gray-200'} overflow-hidden`}>
          <div className={`h-full rounded-full transition-all duration-700 ${scoreBg(score, max)}`}
            style={{ width: `${pct}%` }} />
        </div>
        <span className={`text-xs font-bold ${scoreColor(score, max)} w-6 text-right`}>{score}/{max}</span>
      </div>
    );
  };

  // Map section IDs to section_scores keys
  const sectionScoreKey = {
    impression: 'first_impression',
    phonetic: 'phonetics',
    memorability: 'memorability',
    radio: 'radio_test',
    visual: 'visual',
    language: 'global_safety',
    abbreviation: 'abbreviations',
    competitive: 'competitive',
    seo: 'seo',
    longevity: 'longevity',
    emotion: 'emotional_resonance',
  };

  const buildFullText = () => {
    if (!results) return '';
    const lines = [`NAMEAUDIT ANALYSIS: "${results.name_analyzed}"`, `Grade: ${results.overall_grade}${results.overall_score != null ? ` · Score: ${results.overall_score}/100` : ''}`, '', results.overall_summary, ''];
    if (results.strengths?.length > 0) { lines.push('STRENGTHS'); results.strengths.forEach(s => lines.push(`  \u2713 ${s}`)); lines.push(''); }
    if (results.weaknesses?.length > 0) { lines.push('WEAKNESSES'); results.weaknesses.forEach(w => lines.push(`  \u2717 ${w}`)); lines.push(''); }
    if (results.deal_breakers?.length > 0) { lines.push('DEAL BREAKERS'); results.deal_breakers.forEach(d => lines.push(`  ${d}`)); lines.push(''); }
    if (results.section_scores) {
      lines.push('SECTION SCORES');
      const labels = { first_impression: 'First Impression', phonetics: 'Phonetics', memorability: 'Memorability', radio_test: 'Radio Test', visual: 'Visual', global_safety: 'Global Safety', abbreviations: 'Abbreviations', competitive: 'Competitive', seo: 'SEO', longevity: 'Longevity', emotional_resonance: 'Emotional Resonance' };
      Object.entries(results.section_scores).forEach(([k, v]) => { lines.push(`  ${labels[k] || k}: ${v}/10`); });
      lines.push('');
    }
    if (results.tld_analysis) {
      lines.push('TLD ANALYSIS');
      ['tld_choice', 'trust_signal', 'confusion_risk', 'competing_com', 'alternative_tlds'].forEach(k => {
        if (results.tld_analysis[k]) lines.push(`${k.replace(/_/g, ' ').toUpperCase()}: ${results.tld_analysis[k]}`);
      });
      lines.push('');
    }
    if (results.domain_specific_tests) {
      lines.push('DOMAIN-SPECIFIC TESTS');
      ['browser_bar', 'typosquatting_risk', 'verbal_sharing', 'email_test'].forEach(k => {
        if (results.domain_specific_tests[k]) lines.push(`${k.replace(/_/g, ' ').toUpperCase()}: ${results.domain_specific_tests[k]}`);
      });
      lines.push('');
    }
    if (results.live_availability?.domains) {
      lines.push('LIVE AVAILABILITY', 'DOMAINS:');
      Object.entries(results.live_availability.domains).forEach(([d, s]) => {
        lines.push(`  ${s === 'likely_available' ? '\u2713' : '\u2717'} ${d}`);
      });
      if (results.live_availability?.social) {
        lines.push(`SOCIAL HANDLE: ${results.live_availability.social.handle}`);
        Object.entries(results.live_availability.social.platforms).forEach(([p, s]) => {
          lines.push(`  ${s === 'likely_available' ? '\u2713' : '\u2717'} ${p}`);
        });
      }
      lines.push('');
    }
    lines.push('\u2500\u2500\u2500', 'Generated by DeftBrain \u00b7 deftbrain.com');
    return lines.join('\n');
  };

  const handlePrint = () => {
    const content = buildFullText();
    const pw = window.open('', '_blank');
    if (!pw) return;
    pw.document.write(`<!DOCTYPE html><html><head><title>NameAudit — ${name}</title><style>body{font-family:Georgia,serif;max-width:700px;margin:40px auto;padding:0 20px;color:#1a1a1a;line-height:1.6;font-size:14px;}pre{white-space:pre-wrap;word-wrap:break-word;font-family:inherit;margin:0;}@media print{body{margin:20px;}}</style></head><body><pre>${content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre></body></html>`);
    pw.document.close(); pw.focus(); setTimeout(() => pw.print(), 250);
  };


  const handleShare = async () => {
    const text = buildFullText();
    if (navigator.share) {
      try { await navigator.share({ title: 'NameAudit Results', text, url: window.location.href }); }
      catch (err) { if (err.name !== 'AbortError') console.error('Share failed:', err); }
    } else { try { await navigator.clipboard.writeText(text); } catch(e) { console.error('Copy failed:', e); } }
  };

  const buildCompareText = () => {
    if (!compareResults) return '';
    const lines = ['NAMEAUDIT COMPARISON', ''];
    if (compareResults.winner) {
      lines.push(`WINNER: ${compareResults.winner.name} (${compareResults.winner.margin.replace(/_/g, ' ')})`);
      lines.push(compareResults.winner.why, '');
    }
    compareResults.candidates?.forEach(cand => {
      lines.push(`── ${cand.name} ──`);
      if (cand.score != null) lines.push(`Score: ${cand.score}/100`);
      lines.push(`Grade: ${cand.grade}`);
      lines.push(cand.one_liner);
      lines.push(`Best: ${cand.best_quality}`);
      lines.push(`Risk: ${cand.biggest_risk}`);
      lines.push(`Memorability: ${cand.memorability} · Radio: ${cand.radio_test} · Global: ${cand.global_safety}`);
      lines.push('');
    });
    if (compareResults.comparison_insight) {
      lines.push('KEY INSIGHT', compareResults.comparison_insight, '');
    }
    lines.push('\u2500\u2500\u2500', 'Generated by DeftBrain \u00b7 deftbrain.com');
    return lines.join('\n');
  };

  const handlePrintCompare = () => {
    const content = buildCompareText();
    const pw = window.open('', '_blank');
    if (!pw) return;
    pw.document.write(`<!DOCTYPE html><html><head><title>NameAudit — Comparison</title><style>body{font-family:Georgia,serif;max-width:700px;margin:40px auto;padding:0 20px;color:#1a1a1a;line-height:1.6;font-size:14px;}pre{white-space:pre-wrap;word-wrap:break-word;font-family:inherit;margin:0;}@media print{body{margin:20px;}}</style></head><body><pre>${content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre></body></html>`);
    pw.document.close(); pw.focus(); setTimeout(() => pw.print(), 250);
  };

  const handleShareCompare = async () => {
    const text = buildCompareText();
    if (navigator.share) {
      try { await navigator.share({ title: 'NameAudit Comparison', text, url: window.location.href }); }
      catch (err) { if (err.name !== 'AbortError') console.error('Share failed:', err); }
    } else { try { await navigator.clipboard.writeText(text); } catch(e) { console.error('Copy failed:', e); } }
  };

  // Collapsible section helper
  const Section = ({ id, title, icon, children, defaultOpen = false, score }) => {
    const isOpen = expandedSections[id] !== undefined ? expandedSections[id] : defaultOpen;
    const explainer = sectionExplainers[id];
    const explainerVisible = showExplainer[id];
    return (
      <div className={`${c.card} rounded-xl shadow-lg p-6`}>
        <button onClick={() => toggleSection(id)} className={`w-full flex items-center justify-between ${c.text}`}>
          <h3 className="font-bold flex items-center gap-2">
            <span>{icon}</span> {title}
            {explainer && (
              <span onClick={(e) => { e.stopPropagation(); toggleExplainer(id); }}
                className={`text-xs cursor-pointer ${isDark ? 'text-zinc-500 hover:text-zinc-300' : 'text-gray-400 hover:text-gray-600'}`}
                title="Why does this matter?">ℹ️</span>
            )}
          </h3>
          <div className="flex items-center gap-3">
            {score != null && <ScoreBar score={score} />}
            {isOpen ? <span>▲</span> : <span>▼</span>}
          </div>
        </button>
        {explainerVisible && explainer && (
          <div className={`mt-2 p-3 rounded-lg ${c.info} border text-sm`}>
            💡 {explainer}
          </div>
        )}
        {isOpen && <div className="mt-4">{children}</div>}
      </div>
    );
  };

  // ─── RENDER ───
  return (
    <div>
      <div className="mb-5 flex items-start justify-between">
        <div>
          <h2 className={`text-2xl font-bold ${c.text}`}>{toolData?.title || 'NameAudit'} {toolData?.icon || '🔍'}</h2>
          <p className={`text-sm ${c.textMuted}`}>{toolData?.tagline || 'Stress-test any name before you commit'}</p>
        </div>
      </div>

      {/* ═══ INPUT VIEW ═══ */}
      {!results && !compareResults && (
        <div className="space-y-5">

          {/* Mode Toggle */}
          <div className="flex gap-2">
            <button onClick={() => setMode('analyze')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg border text-sm font-semibold transition-all ${c.chip(mode === 'analyze')}`}>
              <span>🔍</span> Analyze a Name
            </button>
            <button onClick={() => setMode('compare')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg border text-sm font-semibold transition-all ${c.chip(mode === 'compare')}`}>
              <span>📊</span> Compare Names
            </button>
          </div>

          {/* Analyze Mode */}
          {mode === 'analyze' && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <label className={`block font-semibold ${c.text} mb-2`}>The name <span className="text-red-500">*</span></label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && name.trim() && context) handleAnalyze(); }}
                placeholder="Enter the name you want analyzed"
                className={`w-full p-4 border rounded-xl outline-none text-lg font-semibold focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
            </div>
          )}

          {/* Compare Mode */}
          {mode === 'compare' && (
            <div className={`${c.card} rounded-xl shadow-lg p-6 space-y-3`}>
              <label className={`block font-semibold ${c.text} mb-1`}>Names to compare <span className="text-red-500">*</span></label>
              {compareNames.map((n, idx) => (
                <div key={idx} className="flex gap-2">
                  <input type="text" value={n} onChange={(e) => {
                    const updated = [...compareNames]; updated[idx] = e.target.value; setCompareNames(updated);
                  }}
                    placeholder={`Name ${idx + 1}`}
                    onKeyDown={(e) => { if (e.key === 'Enter' && compareNames.filter(n => n.trim()).length >= 2 && context) handleCompare(); }}
                    className={`flex-1 p-3 border rounded-lg outline-none text-sm font-semibold focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
                  {compareNames.length > 2 && (
                    <button onClick={() => setCompareNames(compareNames.filter((_, i) => i !== idx))}
                      className={`p-2 rounded-lg ${c.btnSecondary}`}><span>✕</span></button>
                  )}
                </div>
              ))}
              {compareNames.length < 4 && (
                isUnlocked('nameAudit.compare3plus') || compareNames.length < 2 ? (
                  <button onClick={() => setCompareNames([...compareNames, ''])}
                    className={`flex items-center gap-1 text-sm ${c.textMuted} hover:${c.text}`}>
                    <span>➕</span> Add another <PremiumBadge feature="nameAudit.compare3plus" />
                  </button>
                ) : (
                  <PremiumGate feature="nameAudit.compare3plus" label="Compare 3-4 Names">
                    <button className={`flex items-center gap-1 text-sm ${c.textMuted}`}>
                      <span>➕</span> Add another
                    </button>
                  </PremiumGate>
                )
              )}
            </div>
          )}

          {/* Context */}
          <div className={`${c.card} rounded-xl shadow-lg p-6`}>
            <label className={`block font-semibold ${c.text} mb-3`}>What is this name for? <span className="text-red-500">*</span></label>
            <div className="flex flex-wrap gap-2">
              {contexts.map(ct => (
                <button key={ct.value} onClick={() => setContext(ct.value)}
                  className={`px-3 py-2 rounded-lg border text-sm font-medium transition-all ${c.chip(context === ct.value)}`}>
                  {ct.icon} {ct.value}
                </button>
              ))}
            </div>
          </div>

          {/* Optional */}
          <div className={`${c.card} rounded-xl shadow-lg p-6 space-y-4`}>
            <p className={`text-xs font-bold uppercase tracking-wide ${c.textMuted}`}>Optional — improves analysis accuracy</p>
            <div>
              <label className={`block text-sm font-semibold ${c.text} mb-1`}>Industry / Context</label>
              <input type="text" value={industry} onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g., Fintech, organic skincare, indie game studio"
                onKeyDown={(e) => { if (e.key === 'Enter') { mode === 'analyze' ? handleAnalyze() : handleCompare(); } }}
                className={`w-full p-3 border rounded-xl outline-none text-sm focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
            </div>
            {mode === 'analyze' && (
              <div>
                <label className={`block text-sm font-semibold ${c.text} mb-1`}>Target audience</label>
                <input type="text" value={targetAudience} onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder="e.g., Gen Z professionals, parents of toddlers, enterprise IT buyers"
                  onKeyDown={(e) => { if (e.key === 'Enter' && name.trim() && context) handleAnalyze(); }}
                  className={`w-full p-3 border rounded-xl outline-none text-sm focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
              </div>
            )}
          </div>

          {/* Audit History */}
          {auditHistory.length > 0 && (
            <div className={`${c.card} rounded-xl shadow-lg p-5`}>
              <button onClick={() => setShowHistory(!showHistory)}
                className={`w-full flex items-center justify-between ${c.text}`}>
                <span className="flex items-center gap-2 font-semibold text-sm">
                  <span>📜</span> Previous Audits ({auditHistory.length})
                </span>
                <span>{showHistory ? '▲' : '▼'}</span>
              </button>
              {showHistory && (
                <div className="mt-3 space-y-2">
                  {auditHistory.map((entry) => (
                    <div key={entry.id} className={`flex items-center gap-3 p-3 rounded-lg border ${c.border} ${c.cardAlt}`}>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`font-bold text-sm ${c.text}`}>{entry.name}</span>
                          <span className={`px-2 py-0.5 text-xs font-bold rounded-full border ${gradeColors[entry.grade] || c.warning}`}>{entry.grade}</span>
                          {entry.score != null && <span className={`text-xs font-bold ${scoreColor(entry.score)}`}>{entry.score}/100</span>}
                          {entry.dealBreakers > 0 && <span className={`text-xs px-1.5 py-0.5 rounded border ${c.danger}`}>🚨 {entry.dealBreakers} deal breaker{entry.dealBreakers > 1 ? 's' : ''}</span>}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          {entry.context && <span className={`text-xs ${c.textMuted}`}>{entry.context}</span>}
                          <span className={`text-xs ${c.textMuted}`}>
                            {new Date(entry.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                      <button onClick={() => loadFromHistory(entry)}
                        className={`flex-shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium ${c.btnSecondary}`}>
                        <span>🔄</span> Re-audit
                      </button>
                    </div>
                  ))}
                  <button onClick={() => { setAuditHistory([]); setShowHistory(false); }}
                    className={`text-xs ${c.textMuted} hover:underline mt-1`}>Clear history</button>
                </div>
              )}
            </div>
          )}

          {/* Submit */}
          <button onClick={mode === 'analyze' ? handleAnalyze : handleCompare}
            disabled={loading || compareLoading || (mode === 'analyze' ? (!name.trim() || !context) : (compareNames.filter(n => n.trim()).length < 2 || !context))}
            className={`w-full py-4 px-6 rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-2 shadow-lg ${
              (loading || compareLoading) ? (isDark ? 'bg-zinc-700 text-zinc-400' : 'bg-gray-200 text-gray-400') : c.btnPrimary
            }`}>
            {(loading || compareLoading) ? (<><span className="animate-spin inline-block">⏳</span> {mode === 'analyze' ? 'Analyzing...' : 'Comparing...'}</>)
              : (<><span>🔍</span> {mode === 'analyze' ? 'Analyze This Name' : 'Compare These Names'}</>)}
          </button>

          {error && (
            <div className={`p-4 rounded-xl flex items-start gap-3 ${c.danger} border`}>
              <span className="flex-shrink-0 mt-0.5">⚠️</span><p className="text-sm">{error}</p>
            </div>
          )}

          {/* NameStorm cross-ref */}
          <p className={`text-xs text-center ${c.textMuted}`}>
            Need name ideas first? Try{' '}
            <a href="/NameStorm" className={linkStyle}>NameStorm</a>{' '}
            to generate names, then bring your favorites here.
          </p>
        </div>
      )}

      {/* ═══ COMPARE RESULTS ═══ */}
      {compareResults && (
        <div className="space-y-5">
          <div className={`${c.card} rounded-xl shadow-lg p-4 flex items-center justify-between flex-wrap gap-3`}>
            <span className={`text-sm font-semibold ${c.text}`}>Comparison: {compareNames.filter(n => n.trim()).join(' vs ')}</span>
            <div className="flex items-center gap-2 flex-wrap">
              <CopyBtn content={buildCompareText()} label="Copy All" />
              <button onClick={handlePrintCompare} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                <span>🖨️</span> Print
              </button>
              <button onClick={handleShareCompare} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                <span>📤</span> Share
              </button>
              <BookmarkButton toolId="NameAudit" isDark={isDark} size="sm" />
              <button onClick={reset} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${isDark ? 'bg-cyan-900/30 text-cyan-300' : 'bg-cyan-50 text-cyan-700'}`}>
                <span>🔄</span> New Analysis
              </button>
            </div>
          </div>

          {/* Winner */}
          {compareResults.winner && (
            <div className={`${c.card} rounded-xl shadow-lg p-6 border-l-4 ${isDark ? 'border-amber-500' : 'border-amber-400'}`}>
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">🏆</span>
                <h3 className={`text-xl font-bold ${c.text}`}>{compareResults.winner.name}</h3>
                <span className={`px-2 py-0.5 text-xs font-bold rounded-full ${c.warning} border`}>{compareResults.winner.margin.replace(/_/g, ' ')}</span>
              </div>
              <p className={`text-sm ${c.textSecondary}`}>{compareResults.winner.why}</p>
              <p className={`text-xs ${c.textMuted} mt-3 italic`}>💡 Run this comparison 2-3 times — if the same name wins consistently, you've got your answer! If it's a toss-up, your finalists are genuinely close and you can trust your instincts.</p>
            </div>
          )}

          {/* Side by side */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {compareResults.candidates?.map((cand, idx) => {
              const isWinner = cand.name === compareResults.winner?.name;
              return (
                <div key={idx} className={`${c.card} rounded-xl shadow-lg p-5 border-2 ${isWinner ? (isDark ? 'border-amber-600' : 'border-amber-400') : c.border}`}>
                  <div className="flex items-start gap-3 mb-3">
                    {cand.score != null && (
                      <div className="flex-shrink-0">
                        <AnimatedScore score={cand.score} size="sm" />
                      </div>
                    )}
                    <div className="flex-1 flex items-center justify-between">
                      <h4 className={`text-lg font-bold ${c.text}`}>{cand.name}</h4>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${gradeColors[cand.grade] || c.warning}`}>{cand.grade}</span>
                    </div>
                  </div>
                  <p className={`text-sm ${c.textSecondary} mb-3`}>{cand.one_liner}</p>
                  <div className="space-y-2">
                    <div className={`p-2 rounded-lg ${c.success} border`}>
                      <p className="text-xs font-bold mb-0.5">Best quality</p><p className="text-sm">{cand.best_quality}</p>
                    </div>
                    <div className={`p-2 rounded-lg ${c.danger} border`}>
                      <p className="text-xs font-bold mb-0.5">Biggest risk</p><p className="text-sm">{cand.biggest_risk}</p>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <span className={`px-2 py-0.5 rounded text-xs border ${c.chip(false)}`}>Memorability: {cand.memorability}</span>
                      <span className={`px-2 py-0.5 rounded text-xs border ${cand.radio_test === 'pass' ? c.success : cand.radio_test === 'fail' ? c.danger : c.warning}`}>Radio: {cand.radio_test}</span>
                      <span className={`px-2 py-0.5 rounded text-xs border ${cand.global_safety === 'clean' ? c.success : cand.global_safety === 'problem' ? c.danger : c.warning}`}>Global: {cand.global_safety}</span>
                    </div>
                    <p className={`text-xs ${c.textMuted} italic`}>Personality: {cand.personality}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {compareResults.comparison_insight && (
            <div className={`p-4 rounded-xl ${c.info} border text-center`}>
              <p className="text-sm font-medium">{compareResults.comparison_insight}</p>
            </div>
          )}
        </div>
      )}

      {/* ═══ ANALYSIS RESULTS ═══ */}
      {results && (
        <div className="space-y-5">

          {/* Controls */}
          <div className={`${c.card} rounded-xl shadow-lg p-4 space-y-3`}>
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2">
                <span className={`text-sm font-semibold ${c.text}`}>"{results.name_analyzed}"</span>
                <button onClick={() => speakName(results.name_analyzed)}
                  className={`p-1 rounded transition-all ${isDark ? 'hover:bg-zinc-700' : 'hover:bg-gray-100'}`}
                  title="Hear pronunciation">
                  <span className="text-sm">🔊</span>
                </button>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <CopyBtn content={buildFullText()} label="Copy All" />
                <button onClick={handlePrint} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                  <span>🖨️</span> Print
                </button>
                <button onClick={handleShare} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                  <span>📤</span> Share
                </button>
                <PremiumGate feature="nameAudit.pdfExport" inline>
                  <button onClick={handlePdfExport} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                    <span>📄</span> PDF <PremiumBadge feature="nameAudit.pdfExport" />
                  </button>
                </PremiumGate>
                <button onClick={() => allExpanded ? collapseAll() : expandAll()}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                  <span>{allExpanded ? '🔼' : '🔽'}</span> {allExpanded ? 'Collapse All' : 'Expand All'}
                </button>
                <button onClick={() => setShowMockups(!showMockups)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${showMockups ? (isDark ? 'bg-cyan-900/40 text-cyan-200' : 'bg-cyan-100 text-cyan-700') : c.btnSecondary}`}>
                  <span>🎨</span> Mockups
                </button>
                <button onClick={reset} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${isDark ? 'bg-cyan-900/30 text-cyan-300' : 'bg-cyan-50 text-cyan-700'}`}>
                  <span>🔄</span> New Analysis
                </button>
              </div>
            </div>

            {/* Analyze Another — quick input */}
            <div className={`flex items-center gap-2 pt-2 border-t ${c.border}`}>
              <span className={`text-xs font-semibold ${c.textMuted} flex-shrink-0`}>Quick audit:</span>
              <input type="text" value={quickName} onChange={(e) => setQuickName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleQuickAnalyze(); }}
                placeholder="Test another name (same settings)"
                className={`flex-1 p-2 border rounded-lg outline-none text-sm focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
              <button onClick={handleQuickAnalyze} disabled={loading || !quickName.trim()}
                className={`px-3 py-2 rounded-lg text-sm font-medium ${loading || !quickName.trim() ? (isDark ? 'bg-zinc-700 text-zinc-500' : 'bg-gray-100 text-gray-400') : c.btnPrimary}`}>
                {loading ? <span className="animate-spin inline-block">⏳</span> : 'Audit'}
              </button>
              {/* Compare from Analyze */}
              {!analyzeToCompare ? (
                <button onClick={() => setAnalyzeToCompare(true)}
                  className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium flex-shrink-0 ${c.btnSecondary}`}>
                  <span>📊</span> Compare
                </button>
              ) : (
                <>
                  <input type="text" value={compareSecondName} onChange={(e) => setCompareSecondName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleCompareFromAnalyze(); }}
                    placeholder="vs..."
                    className={`w-28 p-2 border rounded-lg outline-none text-sm focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
                  <button onClick={handleCompareFromAnalyze} disabled={compareLoading || !compareSecondName.trim()}
                    className={`px-3 py-2 rounded-lg text-sm font-medium ${compareLoading || !compareSecondName.trim() ? (isDark ? 'bg-zinc-700 text-zinc-500' : 'bg-gray-100 text-gray-400') : c.btnPrimary}`}>
                    {compareLoading ? <span className="animate-spin inline-block">⏳</span> : 'Go'}
                  </button>
                  <button onClick={() => { setAnalyzeToCompare(false); setCompareSecondName(''); }}
                    className={`text-xs ${c.textMuted}`}>✕</button>
                </>
              )}
            </div>
          </div>

          {/* Overall Verdict */}
          <div className={`${c.card} rounded-xl shadow-lg p-6 border-l-4 ${
            results.overall_grade === 'STRONG' || results.overall_grade === 'GOOD' ? (isDark ? 'border-green-500' : 'border-green-400')
            : results.overall_grade === 'FAIR' ? (isDark ? 'border-amber-500' : 'border-amber-400')
            : (isDark ? 'border-red-500' : 'border-red-400')
          }`}>
            <div className="flex items-start gap-5">
              {results.overall_score != null && (
                <div className="flex-shrink-0">
                  <AnimatedScore score={results.overall_score} size="lg" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-3">
                  <span className={`px-3 py-1.5 rounded-full text-sm font-bold border ${gradeColors[results.overall_grade] || c.warning}`}>
                    {results.overall_grade}
                  </span>
                  <h3 className={`text-lg font-bold ${c.text}`}>"{results.name_analyzed}"</h3>
                </div>
                <p className={`text-sm ${c.textSecondary} leading-relaxed`}>{results.overall_summary}</p>
              </div>
            </div>
          </div>

          {/* Strengths + Weaknesses + Deal Breakers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {results.strengths?.length > 0 && (
              <div className={`p-5 rounded-xl ${c.success} border`}>
                <p className="text-xs font-bold mb-2">STRENGTHS</p>
                {results.strengths.map((s, i) => <p key={i} className="text-sm mb-1">✓ {s}</p>)}
              </div>
            )}
            {results.weaknesses?.length > 0 && (
              <div className={`p-5 rounded-xl ${c.warning} border`}>
                <p className="text-xs font-bold mb-2">WEAKNESSES</p>
                {results.weaknesses.map((w, i) => <p key={i} className="text-sm mb-1">⚠ {w}</p>)}
              </div>
            )}
          </div>

          {results.deal_breakers?.length > 0 && (
            <div className={`p-5 rounded-xl ${c.danger} border`}>
              <p className="text-xs font-bold mb-2">🚨 DEAL BREAKERS</p>
              {results.deal_breakers.map((d, i) => <p key={i} className="text-sm mb-1 font-medium">{d}</p>)}
            </div>
          )}

          {/* Score Radar Chart */}
          {results.section_scores && Object.keys(results.section_scores).length >= 3 && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <h3 className={`font-bold ${c.text} mb-3 flex items-center gap-2`}>
                <span>📊</span> Score Profile
              </h3>
              <RadarChart scores={results.section_scores} />
              <p className={`text-xs ${c.textMuted} text-center mt-2`}>Each axis represents a 0-10 score. Larger area = stronger name overall.</p>
            </div>
          )}

          {/* ─── #6: Name Psychology Profile ─── */}
          {results && (() => {
            const psych = computePsychology(results.name_analyzed);
            if (!psych) return null;
            return (
              <Section id="psychology" title="Name Psychology (Sound Science)" icon="🧠">
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>BOUBA / KIKI EFFECT</p>
                      <p className={`text-sm font-semibold ${c.text}`}>{psych.boubaKiki}</p>
                      <p className={`text-xs ${c.textMuted} mt-0.5`}>Round sounds feel soft & friendly. Sharp sounds feel angular & modern.</p>
                    </div>
                    <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>SIZE SYMBOLISM</p>
                      <p className={`text-sm font-semibold ${c.text}`}>{psych.sizeSymbol}</p>
                      <p className={`text-xs ${c.textMuted} mt-0.5`}>Front vowels (e, i) feel small & light. Back vowels (a, o, u) feel large & heavy.</p>
                    </div>
                    <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>VOWEL : CONSONANT RATIO</p>
                      <p className={`text-sm font-semibold ${c.text}`}>{psych.vowelRatio}</p>
                    </div>
                    <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>LEXICAL NEIGHBORHOOD</p>
                      <p className={`text-sm font-semibold ${c.text}`}>{psych.neighborDensity}</p>
                      <p className={`text-xs ${c.textMuted} mt-0.5`}>More similar-sounding words = harder to recall distinctly.</p>
                    </div>
                  </div>
                  {psych.traits.length > 0 && (
                    <div className={`p-3 rounded-lg ${c.cyan} border`}>
                      <p className="text-xs font-bold mb-1">PHONETIC PERSONALITY TRAITS</p>
                      <div className="flex flex-wrap gap-1.5">
                        {psych.traits.map((t, i) => (
                          <span key={i} className={`px-2 py-0.5 rounded-full text-xs border ${c.chip(false)}`}>{t}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Section>
            );
          })()}

          {/* ─── #7: Pronunciation Confidence Map ─── */}
          {results && (
            <Section id="pronunciation-map" title="Global Pronunciation Confidence" icon="🗺️">
              <div className="space-y-3">
                <p className={`text-xs ${c.textMuted}`}>Estimated pronunciation accuracy based on phoneme inventory of each language. ✓ = likely correct, ~ = close but imperfect, ✗ = frequently mispronounced.</p>
                <PronunciationMap nameStr={results.name_analyzed} />
              </div>
            </Section>
          )}

          {/* ─── #9: Context Mockups Toggle (in controls area) ─── */}
          {results && showMockups && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <h3 className={`font-bold ${c.text} mb-3 flex items-center gap-2`}>
                <span>🎨</span> Real-World Mockups
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(mockupContexts[context] || mockupContexts['Business'] || ['app_store', 'business_card', 'email_sig', 'hero']).map(type => (
                  <MockupCard key={type} type={type} displayName={results.name_analyzed} />
                ))}
              </div>
            </div>
          )}

          {/* First Impression */}
          {results.first_impression && (
            <Section id="impression" title="First Impression" icon="👁️" defaultOpen score={results.section_scores?.first_impression}>
              <div className="space-y-3">
                <p className={`text-sm ${c.textSecondary}`}>{results.first_impression.gut_reaction}</p>
                <div className="flex flex-wrap gap-1.5">
                  {results.first_impression.associations?.map((a, i) => (
                    <span key={i} className={`px-2.5 py-1 rounded-full text-xs border ${c.chip(false)}`}>{a}</span>
                  ))}
                </div>
                <p className={`text-sm ${c.textMuted} italic`}>Personality: {results.first_impression.personality_projected}</p>
              </div>
            </Section>
          )}

          {/* Phonetic Profile */}
          {results.phonetic_profile && (
            <Section id="phonetic" title="Phonetic Profile" icon="👂" score={results.section_scores?.phonetics}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {['syllables', 'mouth_feel', 'accent_notes', 'sound_psychology', 'rhythm'].map(key => (
                  results.phonetic_profile[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.phonetic_profile[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Memorability */}
          {results.memorability && (
            <Section id="memorability" title="Memorability Tests" icon="⚡" score={results.section_scores?.memorability}>
              <div className="space-y-3">
                {[
                  { key: 'day_after_test', label: 'Day-After Test' },
                  { key: 'tell_a_friend_test', label: 'Tell-A-Friend Test' },
                  { key: 'phone_test', label: 'Phone Test' },
                  { key: 'drunk_test', label: 'Drunk Test 🍺' },
                  { key: 'shout_test', label: 'Shout Test' },
                ].map(({ key, label }) => results.memorability[key] && (
                  <div key={key} className="flex items-start gap-3">
                    <span className={`text-xs font-bold w-32 flex-shrink-0 pt-0.5 ${c.textMuted}`}>{label}</span>
                    <PassFail pass={results.memorability[key].pass} notes={results.memorability[key].notes} />
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Radio Test */}
          {results.radio_test && (
            <Section id="radio" title="Radio Test (Spell From Hearing)" icon="💬" score={results.section_scores?.radio_test}>
              <div className="space-y-3">
                <PassFail pass={results.radio_test.pass} notes={results.radio_test.notes} />
                {results.radio_test.likely_misspellings?.length > 0 && (
                  <div className={`p-3 rounded-lg ${c.warning} border`}>
                    <p className="text-xs font-bold mb-1">LIKELY MISSPELLINGS</p>
                    <div className="flex flex-wrap gap-1.5">
                      {results.radio_test.likely_misspellings.map((m, i) => (
                        <span key={i} className={`px-2 py-0.5 rounded text-xs font-mono ${isDark ? 'bg-zinc-800' : 'bg-white'}`}>{m}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Section>
          )}

          {/* Visual Analysis */}
          {results.visual_analysis && (
            <Section id="visual" title="Visual Analysis" icon="👁️" score={results.section_scores?.visual}>
              <div className="space-y-3">
                <div className="flex flex-wrap gap-3 mb-3">
                  {[
                    { label: 'lowercase', val: results.visual_analysis.lowercase },
                    { label: 'UPPERCASE', val: results.visual_analysis.uppercase },
                    { label: 'Title Case', val: results.visual_analysis.title_case },
                  ].map(({ label, val }) => val && (
                    <div key={label} className={`p-3 rounded-lg ${c.cardAlt} text-center`}>
                      <p className={`text-xs ${c.textMuted} mb-1`}>{label}</p>
                      <p className={`text-lg font-bold ${c.text}`}>{val}</p>
                    </div>
                  ))}
                </div>
                {['url_appearance', 'logo_potential', 'visual_issues'].map(key => (
                  results.visual_analysis[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.visual_analysis[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Global Language Scan */}
          {results.global_language_scan?.length > 0 && (
            <Section id="language" title={`Global Language Scan (${results.global_language_scan.length} languages)`} icon="🌐" score={results.section_scores?.global_safety}>
              <div className="flex flex-wrap gap-2">
                {results.global_language_scan.map((lang, idx) => (
                  <div key={idx} className={`px-3 py-2 rounded-lg border text-sm flex items-center gap-1.5 ${langSeverityStyle(lang.severity)}`}>
                    {langSeverityIcon(lang.severity)}
                    <span className="font-semibold">{lang.language}:</span>
                    <span>{lang.finding}</span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Abbreviation Audit */}
          {results.abbreviation_audit && (
            <Section id="abbreviation" title="Abbreviation & Nickname Audit" icon="#️⃣" score={results.section_scores?.abbreviations}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {['natural_shortening', 'initials', 'hashtag', 'issues'].map(key => (
                  results.abbreviation_audit[key] && (
                    <div key={key} className={`p-3 rounded-lg ${key === 'issues' && results.abbreviation_audit[key] !== 'Clean' ? c.warning : c.cardAlt} ${key === 'issues' && results.abbreviation_audit[key] !== 'Clean' ? 'border' : ''}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary} ${key === 'hashtag' ? 'font-mono' : ''}`}>{results.abbreviation_audit[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Competitive Landscape */}
          {results.competitive_landscape && (
            <Section id="competitive" title="Competitive Landscape" icon="🛡️" score={results.section_scores?.competitive}>
              <div className="space-y-3">
                {results.competitive_landscape.similar_names?.length > 0 && (
                  <div className={`p-3 rounded-lg ${c.warning} border`}>
                    <p className="text-xs font-bold mb-1">SIMILAR EXISTING NAMES</p>
                    {results.competitive_landscape.similar_names.map((n, i) => <p key={i} className="text-sm mb-0.5">• {n}</p>)}
                  </div>
                )}
                <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                  <p className={`text-xs font-bold ${c.textMuted} mb-1`}>DIFFERENTIATION</p>
                  <p className={`text-sm ${c.textSecondary}`}>{results.competitive_landscape.differentiation}</p>
                </div>
              </div>
            </Section>
          )}

          {/* SEO / Searchability */}
          {results.searchability && (
            <Section id="seo" title="SEO & Searchability" icon="🔍" score={results.section_scores?.seo}>
              <div className="space-y-3">
                {['uniqueness', 'google_competition', 'seo_assessment'].map(key => (
                  results.searchability[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.searchability[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Longevity */}
          {results.longevity && (
            <Section id="longevity" title="Longevity Check" icon="⏰" score={results.section_scores?.longevity}>
              <div className="space-y-3">
                {['trend_dependency', 'aging_risk', 'verdict'].map(key => (
                  results.longevity[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.longevity[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}


          {/* TLD Analysis (domain names) */}
          {results.tld_analysis && (
            <Section id="tld" title="TLD Analysis" icon="🌐">
              <div className="space-y-3">
                {['tld_choice', 'trust_signal', 'confusion_risk', 'competing_com', 'alternative_tlds'].map(key => (
                  results.tld_analysis[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.tld_analysis[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Domain-Specific Tests */}
          {results.domain_specific_tests && (
            <Section id="domain-tests" title="Domain-Specific Tests" icon="🔍">
              <div className="space-y-3">
                {['browser_bar', 'typosquatting_risk', 'verbal_sharing', 'email_test'].map(key => (
                  results.domain_specific_tests[key] && (
                    <div key={key} className={`p-3 rounded-lg ${c.cardAlt}`}>
                      <p className={`text-xs font-bold ${c.textMuted} mb-1`}>{key.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className={`text-sm ${c.textSecondary}`}>{results.domain_specific_tests[key]}</p>
                    </div>
                  )
                ))}
              </div>
            </Section>
          )}

          {/* Emotional Resonance */}
          {results.emotional_resonance && (
            <Section id="emotion" title="Emotional Resonance" icon="❤️" score={results.section_scores?.emotional_resonance}>
              <div className="space-y-3">
                {results.emotional_resonance.personality_match && (
                  <p className={`text-sm ${c.textSecondary}`}>{results.emotional_resonance.personality_match}</p>
                )}
                {results.emotional_resonance.sensory_associations && (
                  <div className={`p-3 rounded-lg ${c.purple} border`}>
                    <p className="text-xs font-bold mb-1">SENSORY ASSOCIATIONS</p>
                    <p className="text-sm">{results.emotional_resonance.sensory_associations}</p>
                  </div>
                )}
                {results.emotional_resonance.if_it_were_a_person && (
                  <div className={`p-3 rounded-lg ${c.cardAlt}`}>
                    <p className={`text-xs font-bold ${c.textMuted} mb-1`}>IF THIS NAME WERE A PERSON</p>
                    <p className={`text-sm ${c.textSecondary} italic`}>{results.emotional_resonance.if_it_were_a_person}</p>
                  </div>
                )}
              </div>
            </Section>
          )}

          {/* Live Availability */}
          {results.live_availability && (
            <Section id="availability" title="Live Availability" icon="🌐">
              <div className="space-y-3">
                {results.live_availability.domains && (
                  <div>
                    <p className={`text-xs font-bold ${c.textMuted} mb-2`}>DOMAINS</p>
                    <div className="flex flex-wrap gap-1.5">
                      {Object.entries(results.live_availability.domains).map(([domain, status]) => (
                        <span key={domain} className={`px-2.5 py-1 rounded text-xs font-mono border ${
                          status === 'likely_available' ? (isDark ? 'bg-green-900/30 border-green-700 text-green-300' : 'bg-green-50 border-green-300 text-green-700')
                          : status === 'taken' ? (isDark ? 'bg-red-900/20 border-red-800 text-red-400' : 'bg-red-50 border-red-200 text-red-500')
                          : (isDark ? 'bg-zinc-700 border-zinc-600 text-zinc-400' : 'bg-gray-100 border-gray-200 text-gray-400')
                        }`}>
                          {domain} {status === 'likely_available' ? '✓' : status === 'taken' ? '✗' : '?'}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {results.live_availability.social && (
                  <div>
                    <p className={`text-xs font-bold ${c.textMuted} mb-2`}>SOCIAL: {results.live_availability.social.handle}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {Object.entries(results.live_availability.social.platforms).map(([platform, status]) => (
                        <span key={platform} className={`px-2.5 py-1 rounded text-xs border ${
                          status === 'likely_available' ? (isDark ? 'bg-green-900/30 border-green-700 text-green-300' : 'bg-green-50 border-green-300 text-green-700')
                          : status === 'likely_taken' ? (isDark ? 'bg-red-900/20 border-red-800 text-red-400' : 'bg-red-50 border-red-200 text-red-500')
                          : (isDark ? 'bg-zinc-700 border-zinc-600 text-zinc-400' : 'bg-gray-100 border-gray-200 text-gray-400')
                        }`}>
                          {platform} {status === 'likely_available' ? '✓' : status === 'likely_taken' ? '✗' : '?'}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Section>
          )}

          {/* ═══ NEW AI FEATURES ═══ */}

          {/* ─── #1: Audience Reaction Simulator ─── */}
          <div className={`${c.card} rounded-xl shadow-lg p-6`}>
            <h3 className={`font-bold ${c.text} mb-2 flex items-center gap-2`}>
              <span>👥</span> Audience Reaction Simulator
            </h3>
            <p className={`text-xs ${c.textMuted} mb-3`}>
              How would your target audience react to hearing this name for the first time?
            </p>
            {!reactionsResults ? (
              <button onClick={handleReactions} disabled={reactionsLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                  reactionsLoading ? (isDark ? 'bg-zinc-700 text-zinc-400' : 'bg-gray-200 text-gray-400') : c.btnPrimary
                }`}>
                {reactionsLoading ? (<><span className="animate-spin inline-block">⏳</span> Simulating reactions...</>)
                  : (<><span>👥</span> Simulate Audience Reactions
                    <span className={`text-[9px] px-1 py-0.5 rounded font-bold ${isDark ? 'bg-cyan-900/50 text-cyan-300' : 'bg-cyan-100 text-cyan-700'}`}>PRO</span></>)}
              </button>
            ) : (
              <div className="space-y-3">
                {reactionsResults.personas?.map((persona, i) => (
                  <div key={i} className={`p-4 rounded-lg border ${c.border} ${c.cardAlt}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg">{persona.emoji || '👤'}</span>
                      <div>
                        <p className={`text-sm font-bold ${c.text}`}>{persona.name}</p>
                        <p className={`text-xs ${c.textMuted}`}>{persona.description}</p>
                      </div>
                    </div>
                    <p className={`text-sm ${c.textSecondary} italic`}>"{persona.reaction}"</p>
                    {persona.would_they_remember && (
                      <p className={`text-xs ${c.textMuted} mt-1.5`}>
                        Would they remember it? <span className="font-semibold">{persona.would_they_remember}</span>
                      </p>
                    )}
                    {persona.trust_level && (
                      <p className={`text-xs ${c.textMuted}`}>
                        Trust level: <span className="font-semibold">{persona.trust_level}</span>
                      </p>
                    )}
                  </div>
                ))}
                {reactionsResults.consensus && (
                  <div className={`p-3 rounded-lg ${c.info} border`}>
                    <p className="text-xs font-bold mb-1">AUDIENCE CONSENSUS</p>
                    <p className="text-sm">{reactionsResults.consensus}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ─── #3: Context-Specific Deep Dive ─── */}
          <div className={`${c.card} rounded-xl shadow-lg p-6`}>
            <h3 className={`font-bold ${c.text} mb-2 flex items-center gap-2`}>
              <span>🔬</span> {context === 'Baby' ? 'Baby Name Deep Dive' : context === 'Band / Music Project' ? 'Music Industry Deep Dive' : context === 'Pet' ? 'Pet Name Deep Dive' : 'Industry-Specific Deep Dive'}
            </h3>
            <p className={`text-xs ${c.textMuted} mb-3`}>
              {context === 'Baby' ? 'Popularity trends, sibling compatibility, playground-proofing, and more.'
                : context === 'Band / Music Project' ? 'Genre fit, Spotify searchability, tour poster test, and merch potential.'
                : context === 'Pet' ? 'Call-and-response test, vet-confusion check, and multi-pet compatibility.'
                : 'Trademark risk, expansion readiness, funding potential, and market positioning.'}
            </p>
            {!deepDiveResults ? (
              <button onClick={handleDeepDive} disabled={deepDiveLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                  deepDiveLoading ? (isDark ? 'bg-zinc-700 text-zinc-400' : 'bg-gray-200 text-gray-400') : c.btnPrimary
                }`}>
                {deepDiveLoading ? (<><span className="animate-spin inline-block">⏳</span> Running deep dive...</>)
                  : (<><span>🔬</span> Run Deep Dive
                    <span className={`text-[9px] px-1 py-0.5 rounded font-bold ${isDark ? 'bg-cyan-900/50 text-cyan-300' : 'bg-cyan-100 text-cyan-700'}`}>PRO</span></>)}
              </button>
            ) : (
              <div className="space-y-3">
                {deepDiveResults.sections?.map((section, i) => (
                  <div key={i} className={`p-3 rounded-lg ${section.severity === 'positive' ? c.success : section.severity === 'problem' ? c.danger : section.severity === 'caution' ? c.warning : c.cardAlt} ${section.severity ? 'border' : ''}`}>
                    <p className="text-xs font-bold mb-1">{section.title}</p>
                    <p className="text-sm">{section.finding}</p>
                    {section.detail && <p className={`text-xs ${c.textMuted} mt-1`}>{section.detail}</p>}
                  </div>
                ))}
                {deepDiveResults.verdict && (
                  <div className={`p-3 rounded-lg ${c.info} border`}>
                    <p className="text-xs font-bold mb-1">DEEP DIVE VERDICT</p>
                    <p className="text-sm">{deepDiveResults.verdict}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ─── #10: Second Opinion ─── */}
          <div className={`${c.card} rounded-xl shadow-lg p-6`}>
            <h3 className={`font-bold ${c.text} mb-2 flex items-center gap-2`}>
              <span>🔄</span> Second Opinion
            </h3>
            <p className={`text-xs ${c.textMuted} mb-3`}>
              Run the analysis again independently and see where two opinions agree vs. disagree. Agreement = reliable signal.
            </p>
            {!secondOpinionResults ? (
              <button onClick={handleSecondOpinion} disabled={secondOpinionLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                  secondOpinionLoading ? (isDark ? 'bg-zinc-700 text-zinc-400' : 'bg-gray-200 text-gray-400') : c.btnPrimary
                }`}>
                {secondOpinionLoading ? (<><span className="animate-spin inline-block">⏳</span> Getting second opinion...</>)
                  : (<><span>🔄</span> Get Second Opinion
                    <span className={`text-[9px] px-1 py-0.5 rounded font-bold ${isDark ? 'bg-cyan-900/50 text-cyan-300' : 'bg-cyan-100 text-cyan-700'}`}>PRO</span></>)}
              </button>
            ) : (
              <div className="space-y-3">
                {/* Score comparison */}
                <div className="grid grid-cols-2 gap-3">
                  <div className={`p-3 rounded-lg text-center ${c.cardAlt}`}>
                    <p className={`text-xs font-bold ${c.textMuted} mb-1`}>FIRST ANALYSIS</p>
                    <p className={`text-2xl font-bold ${scoreColor(results?.overall_score || 0)}`}>{results?.overall_score}</p>
                    <p className={`text-xs font-bold ${c.textMuted}`}>{results?.overall_grade}</p>
                  </div>
                  <div className={`p-3 rounded-lg text-center ${c.cardAlt}`}>
                    <p className={`text-xs font-bold ${c.textMuted} mb-1`}>SECOND OPINION</p>
                    <p className={`text-2xl font-bold ${scoreColor(secondOpinionResults.score || 0)}`}>{secondOpinionResults.score}</p>
                    <p className={`text-xs font-bold ${c.textMuted}`}>{secondOpinionResults.grade}</p>
                  </div>
                </div>
                {/* Agreements */}
                {secondOpinionResults.agreements?.length > 0 && (
                  <div className={`p-3 rounded-lg ${c.success} border`}>
                    <p className="text-xs font-bold mb-1">✅ BOTH ANALYSES AGREE</p>
                    {secondOpinionResults.agreements.map((a, i) => <p key={i} className="text-sm mb-0.5">• {a}</p>)}
                  </div>
                )}
                {/* Disagreements */}
                {secondOpinionResults.disagreements?.length > 0 && (
                  <div className={`p-3 rounded-lg ${c.warning} border`}>
                    <p className="text-xs font-bold mb-1">⚠ ANALYSES DISAGREE ON</p>
                    {secondOpinionResults.disagreements.map((d, i) => <p key={i} className="text-sm mb-0.5">• {d}</p>)}
                  </div>
                )}
                {/* New insights */}
                {secondOpinionResults.new_insights?.length > 0 && (
                  <div className={`p-3 rounded-lg ${c.info} border`}>
                    <p className="text-xs font-bold mb-1">💡 NEW INSIGHTS</p>
                    {secondOpinionResults.new_insights.map((n, i) => <p key={i} className="text-sm mb-0.5">• {n}</p>)}
                  </div>
                )}
                {secondOpinionResults.confidence_verdict && (
                  <p className={`text-sm ${c.textSecondary} italic text-center`}>🎯 {secondOpinionResults.confidence_verdict}</p>
                )}
              </div>
            )}
          </div>

          {/* Suggestions */}
          {results.suggestions && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <h3 className={`font-bold ${c.text} mb-3 flex items-center gap-2`}>
                <span>→</span> Next Steps
              </h3>
              {results.suggestions.to_strengthen && (
                <div className={`p-3 rounded-lg ${c.success} border mb-3`}>
                  <p className="text-xs font-bold mb-1">TO STRENGTHEN THIS NAME</p>
                  <p className="text-sm">{results.suggestions.to_strengthen}</p>
                </div>
              )}
              {results.suggestions.alternatives_direction && (
                <div className={`p-3 rounded-lg ${c.info} border mb-3`}>
                  <p className="text-xs font-bold mb-1">IF RECONSIDERING</p>
                  <p className="text-sm">{results.suggestions.alternatives_direction}</p>
                </div>
              )}
              {/* Fix This Name — premium */}
              <PremiumGate feature="nameAudit.fixThisName" label="Fix This Name">
                <button onClick={handleFixThisName} disabled={fixLoading || !!fixResults}
                  className={`w-full mt-2 py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    fixResults ? (isDark ? 'bg-zinc-700 border border-zinc-600 text-zinc-400' : 'bg-gray-100 border border-gray-200 text-gray-400')
                    : fixLoading ? (isDark ? 'bg-zinc-700 border border-zinc-600 text-zinc-400' : 'bg-gray-200 border border-gray-200 text-gray-400')
                    : isDark ? 'bg-violet-900/30 border border-violet-700 text-violet-200 hover:bg-violet-900/50'
                      : 'bg-violet-50 border border-violet-200 text-violet-700 hover:bg-violet-100'
                  }`}
                >
                  {fixLoading ? (<><span className="animate-spin inline-block">⏳</span> Generating fixes...</>)
                    : fixResults ? (<><span>✅</span> Fixes generated below</>)
                    : (<><span>✨</span> Fix This Name — Generate improved variations <PremiumBadge feature="nameAudit.fixThisName" /></>)}
                </button>
              </PremiumGate>
            </div>
          )}

          {/* ─── Fix This Name Results ─── */}
          {fixResults && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <h3 className={`font-bold ${c.text} mb-2 flex items-center gap-2`}>
                <span>✨</span> Improved Variations of "{results?.name_analyzed}"
              </h3>
              {fixResults.approach && (
                <p className={`text-sm ${c.textSecondary} mb-4 italic`}>{fixResults.approach}</p>
              )}
              <div className="space-y-3">
                {fixResults.variations?.map((v, i) => (
                  <div key={i} className={`p-4 rounded-xl border ${c.border} ${c.cardAlt}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className={`text-lg font-bold ${c.text}`}>{v.name}</h4>
                          {v.pronunciation && <span className={`text-xs font-mono ${c.textMuted}`}>/{v.pronunciation}/</span>}
                          <button onClick={() => speakName(v.name)} className="p-0.5 rounded" title="Hear it">
                            <span className="text-sm">🔊</span>
                          </button>
                          {v.estimated_score != null && (
                            <span className={`text-xs font-bold px-1.5 py-0.5 rounded border ${
                              v.estimated_score >= 80 ? (isDark ? 'text-green-400 bg-green-900/30 border-green-700' : 'text-green-700 bg-green-50 border-green-300')
                              : v.estimated_score >= 60 ? (isDark ? 'text-amber-400 bg-amber-900/30 border-amber-700' : 'text-amber-700 bg-amber-50 border-amber-300')
                              : (isDark ? 'text-red-400 bg-red-900/30 border-red-700' : 'text-red-600 bg-red-50 border-red-300')
                            }`}>{v.estimated_score}</span>
                          )}
                        </div>
                        <p className={`text-sm ${c.textSecondary} mt-1.5`}>{v.why_its_better}</p>
                        {v.what_it_fixes && (
                          <p className={`text-xs ${isDark ? 'text-violet-300' : 'text-violet-600'} mt-1 font-medium`}>
                            → Fixes: {v.what_it_fixes}
                          </p>
                        )}
                        {v.tradeoff && (
                          <p className={`text-xs ${c.textMuted} mt-1`}>⚖️ Tradeoff: {v.tradeoff}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <CopyBtn content={v.name} />
                        <a href={`/NameAudit?name=${encodeURIComponent(v.name)}`}
                          className={`p-1.5 rounded-lg transition-all ${c.btnSecondary}`} title="Audit this name">
                          <span className="text-sm">🔍</span>
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {fixResults.naming_direction && (
                <p className={`text-sm ${c.textSecondary} mt-4 italic`}>💡 {fixResults.naming_direction}</p>
              )}
            </div>
          )}

          {/* Cross-tool: smart NameStorm handoff with context */}
          {(() => {
            const isWeak = results?.overall_grade === 'WEAK' || results?.overall_grade === 'RECONSIDER';
            const weaknesses = results?.weaknesses?.slice(0, 2).join(', ') || '';
            const stormParams = new URLSearchParams();
            if (context && context !== 'Other') stormParams.set('category', context);
            if (weaknesses) stormParams.set('constraints', `Avoid issues: ${weaknesses}`);
            if (industry) stormParams.set('industry', industry);
            const stormUrl = `/NameStorm${stormParams.toString() ? '?' + stormParams.toString() : ''}`;

            return isWeak ? (
              <div className={`p-4 rounded-xl ${c.warning} border text-center`}>
                <p className={`text-sm font-medium mb-2`}>This name scored low — try NameStorm for stronger alternatives.</p>
                <a href={stormUrl} className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${isDark ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-amber-600 hover:bg-amber-700 text-white'}`}>
                  <span>⚡</span> Generate Better Names
                </a>
                {weaknesses && <p className={`text-xs ${c.textMuted} mt-2`}>NameStorm will be pre-filled with your context and told to avoid: {weaknesses}</p>}
              </div>
            ) : (
              <p className={`text-xs text-center ${c.textMuted}`}>
                Want alternatives? <a href={stormUrl} className={linkStyle}>Open NameStorm</a> with your settings pre-filled.
              </p>
            );
          })()}

          {/* ─── #4: Evolution Timeline ─── */}
          <EvolutionTimeline />

          {/* ─── #11: Naming Journal ─── */}
          {results && (
            <div className={`${c.card} rounded-xl shadow-lg p-6`}>
              <h3 className={`font-bold ${c.text} mb-3 flex items-center gap-2`}>
                <span>📝</span> Naming Journal
              </h3>
              <p className={`text-xs ${c.textMuted} mb-3`}>
                Jot down thoughts, stakeholder feedback, or context that will help you decide later.
              </p>
              {/* Existing notes */}
              {(journalEntries[results.name_analyzed] || []).length > 0 && (
                <div className="space-y-2 mb-3">
                  {journalEntries[results.name_analyzed].map((note) => (
                    <div key={note.id} className={`flex items-start justify-between gap-2 p-2.5 rounded-lg ${c.cardAlt}`}>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${c.textSecondary}`}>{note.text}</p>
                        <p className={`text-xs ${c.textMuted} mt-0.5`}>
                          {new Date(note.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
                        </p>
                      </div>
                      <button onClick={() => deleteJournalNote(results.name_analyzed, note.id)}
                        className={`text-xs ${c.textMuted} hover:${c.text} flex-shrink-0`}>✕</button>
                    </div>
                  ))}
                </div>
              )}
              {/* Add note input */}
              <div className="flex gap-2">
                <input type="text" value={journalDraft} onChange={(e) => setJournalDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') addJournalNote(results.name_analyzed); }}
                  placeholder="e.g., Sarah loved this one / Board prefers shorter names / Too close to CompetitorX"
                  className={`flex-1 p-2.5 border rounded-lg outline-none text-sm focus:ring-2 focus:ring-cyan-300 ${c.input}`} />
                <button onClick={() => addJournalNote(results.name_analyzed)} disabled={!journalDraft.trim()}
                  className={`px-4 py-2 rounded-lg text-sm font-medium ${!journalDraft.trim() ? (isDark ? 'bg-zinc-700 text-zinc-500' : 'bg-gray-100 text-gray-400') : c.btnPrimary}`}>
                  Add
                </button>
              </div>
            </div>
          )}

          {/* ─── #2: Stakeholder Decision Kit (export CTA) ─── */}
          {results && (
            <div className={`p-4 rounded-xl border-2 border-dashed ${isDark ? 'border-cyan-800' : 'border-cyan-300'} text-center`}>
              <p className={`text-sm font-semibold ${c.text} mb-1`}>📋 Need to share this with your team?</p>
              <p className={`text-xs ${c.textMuted} mb-3`}>Copy the full analysis with radar chart, key findings, and your journal notes.</p>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <CopyBtn content={buildFullText() + (journalEntries[results.name_analyzed]?.length > 0
                  ? '\n\nJOURNAL NOTES\n' + journalEntries[results.name_analyzed].map(n => `• ${n.text}`).join('\n')
                  : '')} label="Copy Full Report" />
                <button onClick={handlePdfExport} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${c.btnSecondary}`}>
                  <span>📄</span> Print / Save as PDF
                </button>
              </div>
            </div>
          )}

          {/* Disclaimer */}
          <div className={`p-4 rounded-xl text-center ${isDark ? 'bg-zinc-800/50' : 'bg-gray-50'}`}>
            <p className={`text-xs ${c.textMuted}`}>
              🔍 Domain and social availability checks are approximations via DNS. Language analysis is AI-generated — verify critical findings with native speakers. Trademark analysis is informational, not legal advice.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

NameAudit.displayName = 'NameAudit';
export default NameAudit;
