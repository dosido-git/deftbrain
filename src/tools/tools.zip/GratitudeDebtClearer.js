import React, { useState, useEffect } from 'react';
import { useClaudeAPI } from '../hooks/useClaudeAPI';
import { useTheme } from '../hooks/useTheme';
import { usePersistentState } from '../hooks/usePersistentState';
import { CopyBtn, ShareBtn, PrintBtn, ActionBar } from '../components/ActionButtons';

const GratitudeDebtClearer = () => {
  const { callToolEndpoint, loading } = useClaudeAPI();
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Theme-aware colors
  const c = {
    bg: isDark ? 'bg-zinc-900' : 'bg-gradient-to-br from-emerald-50 to-emerald-50',
    card: isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-emerald-200',
    cardAlt: isDark ? 'bg-zinc-700 border-zinc-600' : 'bg-emerald-50 border-emerald-200',
    
    input: isDark
      ? 'bg-zinc-900 border-zinc-600 text-zinc-50 placeholder:text-zinc-500 focus:border-emerald-500 focus:ring-emerald-500/20'
      : 'bg-white border-slate-300 text-emerald-900 placeholder:text-slate-500 focus:border-emerald-500 focus:ring-emerald-200',
    select: isDark
      ? 'bg-zinc-900 border-zinc-600 text-zinc-50'
      : 'bg-white border-slate-300 text-emerald-900',
    
    text: isDark ? 'text-zinc-50' : 'text-emerald-900',
    textSecondary: isDark ? 'text-zinc-300' : 'text-emerald-700',
    textMuted: isDark ? 'text-zinc-400' : 'text-emerald-600',
    label: isDark ? 'text-zinc-300' : 'text-slate-700',
    
    btnPrimary: isDark
      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
      : 'bg-emerald-600 hover:bg-emerald-700 text-white',
    btnSecondary: isDark
      ? 'bg-zinc-700 hover:bg-zinc-600 text-zinc-100'
      : 'bg-slate-100 hover:bg-slate-200 text-slate-700',
    btnDisabled: isDark
      ? 'bg-zinc-700 text-zinc-500'
      : 'bg-slate-300 text-slate-400',
    
    success: isDark
      ? 'bg-emerald-900/20 border-emerald-700 text-emerald-200'
      : 'bg-emerald-50 border-emerald-200 text-emerald-800',
    warning: isDark
      ? 'bg-amber-900/20 border-amber-700 text-amber-200'
      : 'bg-amber-50 border-amber-200 text-amber-800',
    error: isDark
      ? 'bg-red-900/20 border-red-700 text-red-200'
      : 'bg-red-50 border-red-200 text-red-800',
    info: isDark
      ? 'bg-blue-900/20 border-blue-700 text-blue-200'
      : 'bg-blue-50 border-blue-200 text-blue-800',
    purple: isDark
      ? 'bg-purple-900/20 border-purple-700 text-purple-200'
      : 'bg-purple-50 border-purple-200 text-purple-900',
    
    // Result-specific
    messageCard: isDark
      ? 'bg-zinc-800 border-zinc-600 hover:border-emerald-600'
      : 'bg-white border-slate-200 hover:border-emerald-300',
    messageBody: isDark
      ? 'bg-zinc-900 border-zinc-700'
      : 'bg-slate-50 border-slate-200',
    toneChip: (active) => active
      ? (isDark ? 'border-emerald-500 bg-emerald-900/30 text-emerald-200' : 'border-emerald-500 bg-emerald-50 text-emerald-900')
      : (isDark ? 'border-zinc-600 hover:border-emerald-600 bg-zinc-800 text-zinc-300' : 'border-slate-200 hover:border-emerald-300 bg-white text-slate-700'),
    toneBadge: isDark
      ? 'bg-emerald-900/40 text-emerald-300'
      : 'bg-emerald-100 text-emerald-700',
    giftSection: isDark
      ? 'bg-amber-900/15 border-l-4 border-amber-600 rounded-r-lg'
      : 'bg-amber-50 border-l-4 border-amber-400 rounded-r-lg',
    giftInput: isDark
      ? 'bg-zinc-900 border-zinc-600 text-zinc-50 placeholder:text-zinc-500'
      : 'bg-white border-amber-300 text-emerald-900 placeholder:text-slate-500',
    handwritingCheck: isDark
      ? 'bg-blue-900/15 border-blue-700 hover:bg-blue-900/25'
      : 'bg-blue-50 border-blue-200 hover:bg-blue-100',
    link: isDark
      ? 'text-cyan-400 hover:text-cyan-300 underline underline-offset-2'
      : 'text-cyan-600 hover:text-cyan-700 underline underline-offset-2',
  };
  // Helper function to detect cultural context from browser locale
  const detectCulturalContext = () => {
    const locale = navigator.language || navigator.userLanguage || 'en-US';
    const lowercaseLocale = locale.toLowerCase();
    
    // Map browser locales to cultural contexts
    if (lowercaseLocale.startsWith('ja') || lowercaseLocale.startsWith('ko') || 
        lowercaseLocale.startsWith('zh')) {
      return 'East Asian (Japanese, Korean, Chinese)';
    }
    if (lowercaseLocale.startsWith('hi') || lowercaseLocale.startsWith('ur') || 
        lowercaseLocale.startsWith('pa') || lowercaseLocale.startsWith('bn') ||
        lowercaseLocale.startsWith('ta') || lowercaseLocale.startsWith('te')) {
      return 'South Asian (Indian, Pakistani)';
    }
    if (lowercaseLocale.startsWith('ar') || lowercaseLocale.startsWith('fa') || 
        lowercaseLocale.startsWith('he') || lowercaseLocale.startsWith('tr')) {
      return 'Middle Eastern';
    }
    if (lowercaseLocale.startsWith('es-mx') || lowercaseLocale.startsWith('es-co') || 
        lowercaseLocale.startsWith('es-ar') || lowercaseLocale.startsWith('pt-br') ||
        lowercaseLocale.startsWith('es-cl') || lowercaseLocale.startsWith('es-pe')) {
      return 'Latin American';
    }
    if (lowercaseLocale.startsWith('en-gb') || lowercaseLocale.startsWith('en-au') || 
        lowercaseLocale.startsWith('en-nz') || lowercaseLocale.startsWith('en-ca') ||
        lowercaseLocale.startsWith('en-ie') || lowercaseLocale.startsWith('en-za')) {
      return 'British/Commonwealth';
    }
    if (lowercaseLocale.startsWith('af') || lowercaseLocale.startsWith('sw') ||
        lowercaseLocale.startsWith('am') || lowercaseLocale.startsWith('ha')) {
      return 'African';
    }
    
    // Default to American/Western for en-US and other locales
    return 'American/Western';
  };
  
  // Form state
  const [recipientName, setRecipientName] = useState('');
  const [gratitudePoints, setGratitudePoints] = useState('');
  const [context, setContext] = useState('General kindness');
  const [relationship, setRelationship] = useState('Personal');
  const [tone, setTone] = useState('Warm & casual');
  const [length, setLength] = useState(5); // 1-10 scale
  
  // New: Enhanced specificity fields
  const [specificGiftDetails, setSpecificGiftDetails] = useState('');
  const [howYoullUseIt, setHowYoullUseIt] = useState('');
  
  // New: Cultural context - will be set by useEffect
  const [culturalContext, setCulturalContext] = useState('American/Western');
  
  // New: Delivery preferences
  const [deliveryMethod, setDeliveryMethod] = useState('Let AI suggest');
  const [needHandwritingTemplate, setNeedHandwritingTemplate] = useState(false);
  
  // Results state
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [adjustingIndex, setAdjustingIndex] = useState(null);
  const [validationFailed, setValidationFailed] = useState(false);

  // Editable messages
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedMessages, setEditedMessages] = useState({}); // { index: edited_text }

  // Message history (persistent)
  const [messageHistory, setMessageHistory] = usePersistentState('gdc-msg-history', []);

  // Recipient profiles (persistent) — built automatically from history
  const [recipientProfiles, setRecipientProfiles] = usePersistentState('gdc-profiles', {});
  // { [name_lower]: { name, relationship, tone, culturalContext, lastThanked, thankCount, reactions: [] } }

  // ── Gratitude Debt Ledger (persisted) ──
  const [ledger, setLedger] = usePersistentState('gdc-ledger', []);
  const [newLedgerName, setNewLedgerName] = useState('');
  const [newLedgerReason, setNewLedgerReason] = useState('');
  const [showLedger, setShowLedger] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Comparison mode
  const [showComparison, setShowComparison] = useState(false);

  // Specificity pre-pass
  const [specificityData, setSpecificityData] = useState(null);
  const [specificityLoading, setSpecificityLoading] = useState(false);
  const [specificityAnswers, setSpecificityAnswers] = useState({});
  const [specificityDismissed, setSpecificityDismissed] = useState(false);

  // Follow-up mode
  const [followUpTarget, setFollowUpTarget] = useState(null); // history entry to follow up on
  const [followUpOutcome, setFollowUpOutcome] = useState('');
  const [followUpResults, setFollowUpResults] = useState(null);
  const [followUpLoading, setFollowUpLoading] = useState(false);

  // Reaction tracking
  const [reactionTarget, setReactionTarget] = useState(null); // history entry id
  const [reactionText, setReactionText] = useState('');

  // Tone calibration
  const [toneWarning, setToneWarning] = useState(null);

  // Batch mode
  const [batchMode, setBatchMode] = useState(false);
  const [batchEntries, setBatchEntries] = useState([]);
  const [batchContext, setBatchContext] = useState('Gift received');
  const [batchRelationship, setBatchRelationship] = useState('Family');
  const [newBatchName, setNewBatchName] = useState('');
  const [newBatchGift, setNewBatchGift] = useState('');

  // Recipient auto-suggest
  const [recipientSuggestions, setRecipientSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const addToLedger = () => {
    if (!newLedgerName.trim()) return;
    setLedger(prev => [...prev, {
      id: Date.now(),
      name: newLedgerName.trim(),
      reason: newLedgerReason.trim(),
      done: false,
      addedAt: new Date().toISOString()
    }]);
    setNewLedgerName('');
    setNewLedgerReason('');
  };

  const toggleLedgerItem = (id) => {
    setLedger(prev => prev.map(item => item.id === id ? { ...item, done: !item.done, completedAt: !item.done ? new Date().toISOString() : null } : item));
  };

  const removeLedgerItem = (id) => {
    setLedger(prev => prev.filter(item => item.id !== id));
  };

  const loadFromLedger = (item) => {
    setRecipientName(item.name);
    setGratitudePoints(item.reason || '');
    setResults(null);
    setEditingIndex(null);
    setEditedMessages({});
    setShowLedger(false);
  };

  // ── Mark as sent: bridge ledger ↔ messages ──
  const markMessageSent = (messageIndex) => {
    const msg = results?.thank_you_messages?.[messageIndex];
    if (!msg) return;
    const messageText = getMessageText(messageIndex, msg.message_text);

    // Save to history
    const historyEntry = {
      id: Date.now().toString(),
      recipientName: recipientName.trim(),
      context,
      relationship,
      tone,
      messageVersion: msg.version,
      messageText,
      generatedAt: new Date().toISOString(),
      sentAt: new Date().toISOString(),
    };
    setMessageHistory(prev => [historyEntry, ...prev].slice(0, 30));

    // Update recipient profile
    updateRecipientProfile(recipientName, { relationship, tone, culturalContext });

    // Update ledger if there's a matching entry
    const matchingLedger = ledger.find(l => l.name.toLowerCase() === recipientName.trim().toLowerCase() && !l.done);
    if (matchingLedger) {
      setLedger(prev => prev.map(item =>
        item.id === matchingLedger.id
          ? { ...item, done: true, completedAt: new Date().toISOString(), sentVersion: msg.version, deliveryMethod }
          : item
      ));
    }
  };

  // ── Editable messages ──
  const getMessageText = (index, originalText) => {
    return editedMessages[index] ?? originalText;
  };

  const startEditing = (index, originalText) => {
    if (!editedMessages[index]) {
      setEditedMessages(prev => ({ ...prev, [index]: originalText }));
    }
    setEditingIndex(index);
  };

  const cancelEditing = (index, originalText) => {
    setEditedMessages(prev => ({ ...prev, [index]: originalText }));
    setEditingIndex(null);
  };

  // ── Recipient auto-fill from history ──
  const handleRecipientChange = (value) => {
    setRecipientName(value);
    if (validationFailed) setValidationFailed(false);

    // Auto-suggest from profiles
    if (value.trim().length >= 2) {
      const lower = value.trim().toLowerCase();
      const matches = Object.values(recipientProfiles)
        .filter(p => p.name.toLowerCase().includes(lower))
        .slice(0, 4);
      setRecipientSuggestions(matches);
      setShowSuggestions(matches.length > 0);
    } else {
      setShowSuggestions(false);
    }
  };

  const selectRecipient = (profile) => {
    setRecipientName(profile.name);
    if (profile.relationship) setRelationship(profile.relationship);
    if (profile.tone) setTone(profile.tone);
    if (profile.culturalContext) setCulturalContext(profile.culturalContext);
    setShowSuggestions(false);
  };

  const getRecipientHistory = (name) => {
    if (!name?.trim()) return [];
    const lower = name.trim().toLowerCase();
    return messageHistory.filter(h => h.recipientName.toLowerCase() === lower);
  };

  // ── Update recipient profile on send ──
  const updateRecipientProfile = (name, data) => {
    const key = name.trim().toLowerCase();
    setRecipientProfiles(prev => ({
      ...prev,
      [key]: {
        name: name.trim(),
        relationship: data.relationship || prev[key]?.relationship,
        tone: data.tone || prev[key]?.tone,
        culturalContext: data.culturalContext || prev[key]?.culturalContext,
        lastThanked: new Date().toISOString(),
        thankCount: (prev[key]?.thankCount || 0) + 1,
      }
    }));
  };

  // ── Tone calibration check ──
  const checkToneCalibration = (selectedTone, rel, ctx) => {
    const mismatches = [];
    if (selectedTone === 'Heartfelt & emotional' && rel === 'Professional') {
      mismatches.push({ suggested: 'Professional', reason: 'Heartfelt & emotional can feel overly personal in professional relationships. A Professional or Warm & casual tone usually lands better with colleagues and bosses.' });
    }
    if (selectedTone === 'Professional' && rel === 'Family' && (ctx === 'Emotional support' || ctx === 'General kindness' || ctx === 'Condolence support')) {
      mismatches.push({ suggested: 'Heartfelt & emotional', reason: 'A Professional tone for a family member who provided emotional support may feel distant. Something warmer would honor the relationship better.' });
    }
    if (selectedTone === 'Brief' && (ctx === 'Condolence support' || ctx === 'Mentorship')) {
      mismatches.push({ suggested: 'Heartfelt & emotional', reason: 'Brief messages can feel dismissive for deep support like condolences or mentorship. A bit more depth shows you value what they did.' });
    }
    setToneWarning(mismatches.length > 0 ? mismatches[0] : null);
  };

  // ── Specificity pre-pass ──
  const checkSpecificity = async () => {
    if (!gratitudePoints.trim() || specificityDismissed) return;
    setSpecificityLoading(true);
    try {
      const data = await callToolEndpoint('gratitude-debt-specificity', {
        recipientName: recipientName.trim(),
        gratitudePoints: gratitudePoints.trim(),
        context,
        relationship,
        userLanguage: navigator.language || 'en',
      });
      if (data.needs_questions) {
        setSpecificityData(data);
      } else {
        setSpecificityData(null);
      }
    } catch {
      // Silently fail — specificity is optional enhancement
    }
    setSpecificityLoading(false);
  };

  // ── Follow-up generation ──
  const handleFollowUp = async () => {
    if (!followUpTarget || !followUpOutcome.trim()) return;
    setFollowUpLoading(true);
    setFollowUpResults(null);
    try {
      const data = await callToolEndpoint('gratitude-debt-followup', {
        recipientName: followUpTarget.recipientName,
        originalContext: followUpTarget.context,
        originalMessage: followUpTarget.messageText,
        originalDate: followUpTarget.sentAt,
        outcome: followUpOutcome.trim(),
        relationship: followUpTarget.relationship,
        tone: followUpTarget.tone || tone,
        culturalContext,
        deliveryMethod,
        userLanguage: navigator.language || 'en',
      });
      setFollowUpResults(data);
    } catch (err) {
      setError(err.message || 'Failed to generate follow-up');
    }
    setFollowUpLoading(false);
  };

  // ── Reaction tracking ──
  const saveReaction = (historyId, reaction) => {
    setMessageHistory(prev => prev.map(h =>
      h.id === historyId ? { ...h, reaction } : h
    ));
    // Update recipient profile with reaction data
    const entry = messageHistory.find(h => h.id === historyId);
    if (entry) {
      const key = entry.recipientName.trim().toLowerCase();
      setRecipientProfiles(prev => ({
        ...prev,
        [key]: {
          ...prev[key],
          lastReaction: reaction,
          lastReactionTone: entry.tone,
        }
      }));
    }
    setReactionTarget(null);
    setReactionText('');
  };

  // ── Delivery shortcuts ──
  const buildMailtoLink = (text) => {
    return `mailto:?subject=${encodeURIComponent(`Thank you, ${recipientName}`)}&body=${encodeURIComponent(text)}`;
  };
  const buildSmsLink = (text) => {
    return `sms:?body=${encodeURIComponent(text)}`;
  };
  const buildWhatsAppLink = (text) => {
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  };

  // ── Batch mode ──
  const addBatchEntry = () => {
    if (!newBatchName.trim()) return;
    setBatchEntries(prev => [...prev, {
      id: Date.now(),
      name: newBatchName.trim(),
      gift: newBatchGift.trim(),
    }]);
    setNewBatchName('');
    setNewBatchGift('');
  };

  const removeBatchEntry = (id) => {
    setBatchEntries(prev => prev.filter(e => e.id !== id));
  };

  // ── Follow-up nudges computed from history ──
  const getFollowUpNudges = () => {
    const now = Date.now();
    const thirtyDays = 30 * 24 * 60 * 60 * 1000;
    return messageHistory
      .filter(h => {
        const age = now - new Date(h.sentAt).getTime();
        return age > thirtyDays && !h.followedUp && !h.reaction;
      })
      .slice(0, 3);
  };

  // Detect and set cultural context on component mount
  useEffect(() => {
    const detectedContext = detectCulturalContext();
    setCulturalContext(detectedContext);
  }, []);

  // Check tone calibration when tone/relationship/context change
  useEffect(() => {
    checkToneCalibration(tone, relationship, context);
  }, [tone, relationship, context]);

  const contextOptions = [
    'Post-interview',
    'Gift received',
    'Emotional support',
    'Mentorship',
    'Hospitality',
    'General kindness',
    'Professional help',
    'Personal favor',
    'Condolence support',
    'Wedding gift',
    'Baby shower gift',
    'Get well soon',
    'Recommendation/Reference',
    'Business opportunity'
  ];

  const relationshipOptions = [
    'Professional',
    'Personal',
    'Family',
    'Casual acquaintance'
  ];

  const culturalContextOptions = [
    'American/Western',
    'British/Commonwealth',
    'East Asian (Japanese, Korean, Chinese)',
    'South Asian (Indian, Pakistani)',
    'Middle Eastern',
    'Latin American',
    'African',
    'Southern US',
    'Not sure/Mixed'
  ];

  const deliveryMethodOptions = [
    'Let AI suggest',
    'Email',
    'Handwritten card',
    'Text message',
    'In-person',
    'Social media message'
  ];

  const toneOptions = [
    { id: 'warm', label: 'Warm & casual', icon: '😊' },
    { id: 'heartfelt', label: 'Heartfelt & emotional', icon: '❤️' },
    { id: 'professional', label: 'Professional', icon: '💼' },
    { id: 'brief', label: 'Brief', icon: '✨' }
  ];

  // ── Print helpers ──
  const buildPrintHTML = (title, body) => {
    const escaped = body.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${title}</title>
<style>
body{font-family:-apple-system,'Segoe UI',Helvetica,sans-serif;max-width:700px;margin:40px auto;padding:0 24px;color:#1c1917;line-height:1.7;font-size:14px}
h1{font-size:1.3em;margin-bottom:4px}
.sub{color:#78716c;font-size:0.85em;margin-bottom:18px}
pre{white-space:pre-wrap;word-wrap:break-word;font-family:inherit;margin:0}
.branding{margin-top:28px;padding-top:14px;border-top:1px solid #e7e5e4;color:#a8a29e;font-size:0.75em;text-align:center}
@media print{body{margin:16px;font-size:12px}}
</style></head><body>
<h1>${title}</h1>
<div class="sub">For: ${recipientName} · ${context} · ${tone}</div>
<pre>${escaped}</pre>
<div class="branding">Generated by DeftBrain · deftbrain.com</div>
</body></html>`;
  };

  const printSection = (title, content) => {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(buildPrintHTML(title, content));
    w.document.close();
    w.onload = () => { w.focus(); w.print(); };
  };

  const printAll = () => {
    if (!results?.thank_you_messages) return;
    const combined = results.thank_you_messages
      .map((m, i) => `── ${m.version} (${m.tone}, ${m.length} words) ──\n\n${m.message_text}\n\nWhy this works: ${m.why_this_works}\nBest for: ${m.best_for}`)
      .join('\n\n────────────────────────────────\n\n');
    const extras = [];
    if (results.delivery_suggestions) {
      extras.push(`\n── Delivery Suggestions ──\nMethod: ${results.delivery_suggestions.method}\nTiming: ${results.delivery_suggestions.timing}${results.delivery_suggestions.additional_gesture ? '\nBonus idea: ' + results.delivery_suggestions.additional_gesture : ''}`);
    }
    if (results.personalization_tips?.length) {
      extras.push(`\n── Personalization Tips ──\n${results.personalization_tips.map(t => '• ' + t).join('\n')}`);
    }
    printSection(`Thank You Messages for ${recipientName}`, combined + extras.join('\n'));
  };

  const buildAllText = () => {
    if (!results?.thank_you_messages) return '';
    const combined = results.thank_you_messages
      .map((m, i) => `── ${m.version} (${m.tone}, ${m.length} words) ──\n\n${getMessageText(i, m.message_text)}\n\nWhy this works: ${m.why_this_works}\nBest for: ${m.best_for}`)
      .join('\n\n────────────────────────────────\n\n');
    const extras = [];
    if (results.delivery_suggestions) {
      extras.push(`\n── Delivery Suggestions ──\nMethod: ${results.delivery_suggestions.method}\nTiming: ${results.delivery_suggestions.timing}`);
    }
    if (results.personalization_tips?.length) {
      extras.push(`\n── Personalization Tips ──\n${results.personalization_tips.map(t => '• ' + t).join('\n')}`);
    }
    return `Thank You Messages for ${recipientName}\n${'═'.repeat(40)}\n\n${combined}${extras.join('\n')}\n\n— Generated by DeftBrain · deftbrain.com`;
  };

  // ── Keyboard: Enter = add ledger / Ctrl+Enter = submit ──
  const handleFormKeyDown = (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleGenerate();
    }
  };

  const handleGenerate = async () => {
    if (!recipientName.trim() || !gratitudePoints.trim()) {
      setError(!recipientName.trim() ? 'Please enter who you\'re thanking' : 'Please list what you\'re grateful for');
      setValidationFailed(true);
      setTimeout(() => setValidationFailed(false), 2500);
      return;
    }

    setError('');
    setResults(null);

    // Enrich gratitude points with specificity answers
    let enrichedGratitude = gratitudePoints.trim();
    if (Object.keys(specificityAnswers).length > 0 && specificityData?.questions) {
      const extras = specificityData.questions
        .map((q, i) => specificityAnswers[i]?.trim() ? `${q.question}: ${specificityAnswers[i].trim()}` : null)
        .filter(Boolean);
      if (extras.length > 0) {
        enrichedGratitude += '\n\nAdditional details:\n' + extras.join('\n');
      }
    }

    try {
      const recHistory = getRecipientHistory(recipientName);
      const data = await callToolEndpoint('gratitude-debt-clearer', {
        recipientName: recipientName.trim(),
        gratitudePoints: enrichedGratitude,
        context,
        relationship,
        tone,
        length,
        specificGiftDetails: specificGiftDetails.trim() || null,
        howYoullUseIt: howYoullUseIt.trim() || null,
        culturalContext,
        deliveryMethod,
        needHandwritingTemplate,
        userLanguage: navigator.language || 'en',
        recipientHistory: recHistory.length > 0 ? recHistory : null,
        toneOverride: toneWarning?.suggested || null,
      });

      setResults(data);
      setEditingIndex(null);
      setEditedMessages({});
      setSpecificityData(null);
      setSpecificityAnswers({});
      setSpecificityDismissed(false);
      setShowComparison(false);
    } catch (err) {
      setError(err.message || 'Failed to generate messages. Please try again.');
    }
  };

  const handleAdjust = async (message, index, adjustment) => {
    setAdjustingIndex(index);
    setError('');

    try {
      let adjustmentPrompt = '';
      if (adjustment === 'less-mushy') {
        adjustmentPrompt = 'Make this thank you message less intense and more understated while keeping it sincere';
      } else if (adjustment === 'more-specific') {
        adjustmentPrompt = 'Make this thank you message more specific by elaborating on the details';
      }

      const data = await callToolEndpoint('gratitude-debt-clearer', {
        recipientName: recipientName.trim(),
        gratitudePoints: gratitudePoints.trim(),
        context,
        relationship,
        tone,
        length,
        specificGiftDetails: specificGiftDetails.trim() || null,
        howYoullUseIt: howYoullUseIt.trim() || null,
        culturalContext,
        deliveryMethod,
        needHandwritingTemplate,
        adjustmentPrompt,
        originalMessage: message.message_text,
        userLanguage: navigator.language || 'en',
      });

      // Update just this message
      setResults(prev => ({
        ...prev,
        thank_you_messages: prev.thank_you_messages.map((msg, i) => 
          i === index ? data.thank_you_messages[0] : msg
        )
      }));
    } catch (err) {
      setError('Failed to adjust message. Please try again.');
    } finally {
      setAdjustingIndex(null);
    }
  };

  const handleReset = () => {
    setRecipientName(''); setGratitudePoints(''); setContext('General kindness');
    setRelationship('Personal'); setTone('Warm & casual'); setLength(5);
    setSpecificGiftDetails(''); setHowYoullUseIt('');
    setCulturalContext('American/Western'); setDeliveryMethod('Let AI suggest');
    setNeedHandwritingTemplate(false); setResults(null); setError('');
    setValidationFailed(false); setEditingIndex(null); setEditedMessages({});
    setShowComparison(false); setSpecificityData(null); setSpecificityAnswers({});
    setSpecificityDismissed(false); setToneWarning(null);
    setFollowUpTarget(null); setFollowUpOutcome(''); setFollowUpResults(null);
  };

  return (
    <div>
      <div className="space-y-6">
      
      {/* Header */}
      <div className={`${c.card} border rounded-xl shadow-lg p-6 transition-colors duration-200`}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <h2 className={`text-2xl font-bold ${c.text}`}>Gratitude Debt Clearer 💝</h2>
            <p className={`text-sm ${c.textMuted}`}>Turn your gratitude into heartfelt messages – without the writing paralysis</p>
          </div>
          <div className="flex items-center gap-2">
            {messageHistory.length > 0 && (
              <button
                onClick={() => { setShowHistory(!showHistory); setShowLedger(false); }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  showHistory
                    ? (isDark ? 'bg-violet-900/40 text-violet-300' : 'bg-violet-100 text-violet-700')
                    : c.btnSecondary
                }`}
                title="Sent Messages"
              >
                <span>📜</span>
                <span className="hidden sm:inline">Sent</span>
                <span className={`px-1.5 py-0.5 rounded-full text-xs font-bold ${isDark ? 'bg-violet-600 text-white' : 'bg-violet-600 text-white'}`}>
                  {messageHistory.length}
                </span>
              </button>
            )}
            <button
              onClick={() => { setShowLedger(!showLedger); setShowHistory(false); }}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                showLedger
                  ? (isDark ? 'bg-emerald-900/40 text-emerald-300' : 'bg-emerald-100 text-emerald-700')
                  : c.btnSecondary
              }`}
              title="Gratitude Debt Ledger"
            >
              <span>📖</span>
              <span className="hidden sm:inline">Debt Ledger</span>
              {ledger.filter(i => !i.done).length > 0 && (
                <span className={`ml-1 px-1.5 py-0.5 rounded-full text-xs font-bold ${isDark ? 'bg-emerald-600 text-white' : 'bg-emerald-600 text-white'}`}>
                  {ledger.filter(i => !i.done).length}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* ── Gratitude Debt Ledger ── */}
      {showLedger && (
        <div className={`${c.card} border rounded-xl shadow-lg p-5 transition-colors duration-200`}>
          <div className="flex items-center gap-2 mb-3">
            <span>📖</span>
            <h3 className={`text-lg font-bold ${c.text}`}>Gratitude Debt Ledger</h3>
            <span className={`text-xs ${c.textMuted}`}>
              ({ledger.filter(i => !i.done).length} pending · {ledger.filter(i => i.done).length} cleared)
            </span>
          </div>
          <p className={`text-xs ${c.textMuted} mb-4`}>
            Track everyone you want to thank. Click a name to load it into the form.
          </p>

          {/* Mode toggle */}
          <div className="flex items-center gap-2 mb-3">
            <button onClick={() => setBatchMode(false)}
              className={`px-2.5 py-1 rounded text-xs font-medium ${!batchMode ? (isDark ? 'bg-emerald-900/40 text-emerald-300' : 'bg-emerald-100 text-emerald-700') : c.btnSecondary}`}>
              One at a time
            </button>
            <button onClick={() => setBatchMode(true)}
              className={`px-2.5 py-1 rounded text-xs font-medium ${batchMode ? (isDark ? 'bg-emerald-900/40 text-emerald-300' : 'bg-emerald-100 text-emerald-700') : c.btnSecondary}`}>
              📦 Batch mode
            </button>
          </div>

          {batchMode ? (
            <div className="space-y-3">
              <p className={`text-xs ${c.textSecondary}`}>Add everyone at once (post-wedding, post-holiday). Set shared context, then generate messages one by one.</p>
              <div className="grid grid-cols-2 gap-2">
                <select value={batchContext} onChange={e => setBatchContext(e.target.value)}
                  className={`p-2 border rounded-lg text-sm ${c.select}`}>
                  {contextOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
                <select value={batchRelationship} onChange={e => setBatchRelationship(e.target.value)}
                  className={`p-2 border rounded-lg text-sm ${c.select}`}>
                  {relationshipOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
              <div className="flex gap-2">
                <input type="text" placeholder="Name" value={newBatchName}
                  onChange={e => setNewBatchName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addBatchEntry()}
                  className={`flex-1 px-3 py-2 border rounded-lg text-sm outline-none ${c.input}`} />
                <input type="text" placeholder="Gift / reason (optional)" value={newBatchGift}
                  onChange={e => setNewBatchGift(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addBatchEntry()}
                  className={`flex-1 px-3 py-2 border rounded-lg text-sm outline-none ${c.input}`} />
                <button onClick={addBatchEntry} disabled={!newBatchName.trim()}
                  className={`px-3 py-2 rounded-lg text-sm font-medium ${newBatchName.trim() ? c.btnPrimary : c.btnDisabled + ' cursor-not-allowed'}`}>➕</button>
              </div>
              {batchEntries.length > 0 && (
                <div className="space-y-1.5">
                  {batchEntries.map(entry => (
                    <div key={entry.id} className={`flex items-center justify-between px-3 py-2 rounded-lg border ${c.cardAlt}`}>
                      <div>
                        <span className={`text-sm font-medium ${c.text}`}>{entry.name}</span>
                        {entry.gift && <span className={`text-xs ${c.textMuted} ml-2`}>— {entry.gift}</span>}
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => {
                          setRecipientName(entry.name);
                          setGratitudePoints(entry.gift || `Thank you for ${batchContext.toLowerCase()}`);
                          setContext(batchContext);
                          setRelationship(batchRelationship);
                          setResults(null);
                          setBatchMode(false);
                          setShowLedger(false);
                        }} className={`px-2 py-0.5 rounded text-[10px] font-bold ${c.btnPrimary}`}>Generate</button>
                        <button onClick={() => removeBatchEntry(entry.id)} className={`text-sm ${c.textMuted}`}>🗑️</button>
                      </div>
                    </div>
                  ))}
                  <button onClick={() => {
                    batchEntries.forEach(e => {
                      setLedger(prev => [...prev, {
                        id: Date.now() + Math.random(),
                        name: e.name,
                        reason: e.gift || batchContext,
                        done: false,
                        addedAt: new Date().toISOString(),
                      }]);
                    });
                    setBatchEntries([]);
                  }} className={`w-full py-2 rounded-lg text-xs font-bold ${c.btnSecondary}`}>
                    📖 Add all {batchEntries.length} to Debt Ledger
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
          {/* Add new entry */}
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Who do you owe thanks to?"
              value={newLedgerName}
              onChange={(e) => setNewLedgerName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addToLedger(); }}}
              className={`flex-1 px-3 py-2 border rounded-lg text-sm outline-none ${c.input}`}
            />
            <input
              type="text"
              placeholder="For what? (optional)"
              value={newLedgerReason}
              onChange={(e) => setNewLedgerReason(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addToLedger(); }}}
              className={`flex-1 px-3 py-2 border rounded-lg text-sm outline-none ${c.input}`}
            />
            <button
              onClick={addToLedger}
              disabled={!newLedgerName.trim()}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                newLedgerName.trim() ? c.btnPrimary : c.btnDisabled + ' cursor-not-allowed'
              }`}
            >
              <span>➕</span>
            </button>
          </div>

          {/* Ledger items */}
          {ledger.length === 0 ? (
            <p className={`text-sm ${c.textMuted} text-center py-4 italic`}>
              No gratitude debts tracked yet. Add someone above!
            </p>
          ) : (
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {ledger.map(item => (
                <div
                  key={item.id}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors ${
                    item.done
                      ? (isDark ? 'bg-zinc-800/50 border-zinc-700/50 opacity-60' : 'bg-slate-50 border-slate-100 opacity-60')
                      : (isDark ? 'bg-zinc-800 border-zinc-700 hover:border-emerald-600' : 'bg-white border-slate-200 hover:border-emerald-300')
                  }`}
                >
                  <button
                    onClick={() => toggleLedgerItem(item.id)}
                    className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                      item.done
                        ? (isDark ? 'bg-emerald-600 border-emerald-600' : 'bg-emerald-500 border-emerald-500')
                        : (isDark ? 'border-zinc-500 hover:border-emerald-500' : 'border-slate-300 hover:border-emerald-400')
                    }`}
                    title={item.done ? 'Mark as not sent' : 'Mark as sent'}
                  >
                    {item.done && <span className="text-xs text-white font-bold">✓</span>}
                  </button>
                  <button
                    onClick={() => !item.done && loadFromLedger(item)}
                    className={`flex-1 text-left ${item.done ? 'cursor-default' : 'cursor-pointer'}`}
                    disabled={item.done}
                  >
                    <span className={`text-sm font-medium ${item.done ? 'line-through' : ''} ${c.text}`}>
                      {item.name}
                    </span>
                    {item.reason && (
                      <span className={`text-xs ${c.textMuted} ml-2`}>— {item.reason}</span>
                    )}
                    {item.done && item.completedAt && (
                      <span className={`text-xs ${isDark ? 'text-emerald-400' : 'text-emerald-600'} ml-2`}>
                        ✅ {new Date(item.completedAt).toLocaleDateString()}
                        {item.sentVersion ? ` · ${item.sentVersion}` : ''}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => removeLedgerItem(item.id)}
                    className={`flex-shrink-0 p-1 rounded transition-colors ${isDark ? 'hover:bg-red-900/30 text-zinc-500 hover:text-red-400' : 'hover:bg-red-50 text-slate-400 hover:text-red-500'}`}
                    title="Remove"
                  >
                    <span className="text-sm">🗑️</span>
                  </button>
                </div>
              ))}
            </div>
          )}
            </>
          )}
        </div>
      )}
      {showHistory && messageHistory.length > 0 && (
        <div className={`${c.card} border rounded-xl shadow-lg p-5 transition-colors duration-200`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span>📜</span>
              <h3 className={`text-lg font-bold ${c.text}`}>Sent Messages</h3>
              <span className={`text-xs ${c.textMuted}`}>({messageHistory.length})</span>
            </div>
            <button onClick={() => { if (window.confirm('Clear all sent message history?')) setMessageHistory([]); }}
              className={`text-xs ${c.textMuted} hover:${isDark ? 'text-red-400' : 'text-red-500'}`}>Clear all</button>
          </div>

          {/* Follow-up nudges */}
          {(() => {
            const nudges = getFollowUpNudges();
            return nudges.length > 0 ? (
              <div className={`mb-4 p-3 rounded-lg border ${c.purple}`}>
                <p className={`text-xs font-bold mb-2`}>🔔 Follow-up opportunities</p>
                {nudges.map(n => (
                  <div key={n.id} className="flex items-center justify-between mb-1.5">
                    <span className={`text-xs`}>
                      You thanked <strong>{n.recipientName}</strong> for {n.context.toLowerCase()} on {new Date(n.sentAt).toLocaleDateString()}
                    </span>
                    <button onClick={() => { setFollowUpTarget(n); setShowHistory(false); }}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${isDark ? 'bg-purple-800 text-purple-200' : 'bg-purple-100 text-purple-800'}`}>
                      Send update →
                    </button>
                  </div>
                ))}
              </div>
            ) : null;
          })()}

          <div className="space-y-2 max-h-72 overflow-y-auto">
            {messageHistory.map(h => (
              <div key={h.id} className={`p-3 rounded-xl border ${c.messageCard} transition-colors`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${c.text}`}>{h.recipientName}</span>
                  <div className="flex items-center gap-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${c.toneBadge}`}>{h.messageVersion}</span>
                    <span className={`text-xs ${c.textMuted}`}>{new Date(h.sentAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <p className={`text-xs ${c.textSecondary} line-clamp-2`}>{h.messageText.slice(0, 140)}…</p>
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <span className={`text-[10px] ${c.textMuted}`}>{h.context} · {h.relationship}</span>
                  <CopyBtn content={`${h.messageText}\n\n— Generated by DeftBrain · deftbrain.com`} label="Copy" />
                  {/* Reaction display or prompt */}
                  {h.reaction ? (
                    <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${isDark ? 'bg-emerald-900/30 text-emerald-300 border border-emerald-700' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                      💬 {h.reaction}
                    </span>
                  ) : reactionTarget === h.id ? (
                    <div className="flex items-center gap-1">
                      <div className="flex gap-1">
                        {['They loved it', 'Seemed surprised', 'Was touched', 'No response'].map(r => (
                          <button key={r} onClick={() => saveReaction(h.id, r)}
                            className={`px-1.5 py-0.5 rounded text-[10px] ${c.btnSecondary}`}>{r}</button>
                        ))}
                      </div>
                      <input type="text" value={reactionText} onChange={e => setReactionText(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && reactionText.trim() && saveReaction(h.id, reactionText.trim())}
                        placeholder="Custom…" className={`w-20 px-1.5 py-0.5 text-[10px] border rounded ${c.input}`} />
                      <button onClick={() => setReactionTarget(null)} className={`text-[10px] ${c.textMuted}`}>✕</button>
                    </div>
                  ) : (
                    <button onClick={() => setReactionTarget(h.id)}
                      className={`text-[10px] ${c.textMuted} hover:${isDark ? 'text-zinc-300' : 'text-slate-600'}`}>
                      💬 How'd it land?
                    </button>
                  )}
                  {/* Follow-up button */}
                  {!h.followedUp && (
                    <button onClick={() => { setFollowUpTarget(h); setShowHistory(false); }}
                      className={`text-[10px] ${isDark ? 'text-violet-400 hover:text-violet-300' : 'text-violet-600 hover:text-violet-700'}`}>
                      🔁 Send follow-up
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Follow-Up Generation ── */}
      {followUpTarget && !showHistory && (
        <div className={`${c.card} border rounded-xl shadow-lg p-5`}>
          <div className="flex items-center justify-between mb-3">
            <h3 className={`text-lg font-bold ${c.text} flex items-center gap-2`}>
              <span>🔁</span> Follow Up with {followUpTarget.recipientName}
            </h3>
            <button onClick={() => { setFollowUpTarget(null); setFollowUpResults(null); setFollowUpOutcome(''); }}
              className={`text-sm ${c.textMuted}`}>✕</button>
          </div>
          <p className={`text-xs ${c.textSecondary} mb-3`}>
            You thanked {followUpTarget.recipientName} for {followUpTarget.context.toLowerCase()} on {new Date(followUpTarget.sentAt).toLocaleDateString()}.
            {followUpTarget.reaction ? ` They reacted: "${followUpTarget.reaction}".` : ''}
          </p>
          <div className={`p-3 rounded-lg border mb-3 ${c.messageBody}`}>
            <p className={`text-xs ${c.textMuted} mb-1`}>Original message:</p>
            <p className={`text-xs ${c.textSecondary} italic`}>{followUpTarget.messageText.slice(0, 200)}…</p>
          </div>
          <label className={`block text-sm font-medium ${c.label} mb-2`}>What happened since? What's the update?</label>
          <textarea value={followUpOutcome} onChange={e => setFollowUpOutcome(e.target.value)}
            placeholder="e.g., I got the job! / The cookbook has become my go-to / That advice changed how I approach..."
            rows={3} className={`w-full p-3 border rounded-lg text-sm outline-none resize-y ${c.input}`} />
          <button onClick={handleFollowUp} disabled={followUpLoading || !followUpOutcome.trim()}
            className={`mt-3 px-5 py-2 rounded-lg font-semibold text-sm ${c.btnPrimary} disabled:opacity-40 flex items-center gap-2`}>
            {followUpLoading ? (<><span className="animate-spin inline-block">⏳</span> Generating…</>) : (<><span>💌</span> Generate Follow-Up</>)}
          </button>

          {/* Follow-up results */}
          {followUpResults && (
            <div className="mt-4 space-y-3">
              {followUpResults.timing_note && (
                <p className={`text-xs ${c.textMuted}`}>⏰ {followUpResults.timing_note}</p>
              )}
              {followUpResults.follow_up_messages?.map((msg, i) => (
                <div key={i} className={`p-4 rounded-xl border ${c.messageCard}`}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className={`text-sm font-bold ${c.text}`}>{msg.version}</h4>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${c.toneBadge}`}>{msg.tone}</span>
                  </div>
                  <p className={`text-sm ${c.textSecondary} leading-relaxed mb-2`}>{msg.message_text}</p>
                  <p className={`text-[10px] ${c.textMuted} mb-2`}>{msg.why_this_works}</p>
                  <div className="flex flex-wrap gap-1.5">
                    <CopyBtn content={`${msg.message_text}\n\n— Generated by DeftBrain · deftbrain.com`} label="Copy" />
                    <a href={buildMailtoLink(msg.message_text)} target="_blank" rel="noopener noreferrer"
                      className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium ${c.btnSecondary}`}>
                      <span>📧</span> Email
                    </a>
                    <a href={buildSmsLink(msg.message_text)} target="_blank" rel="noopener noreferrer"
                      className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium ${c.btnSecondary}`}>
                      <span>📱</span> Text
                    </a>
                    <button onClick={() => {
                      setMessageHistory(prev => prev.map(h => h.id === followUpTarget.id ? { ...h, followedUp: true } : h));
                      setFollowUpTarget(null); setFollowUpResults(null); setFollowUpOutcome('');
                    }} className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold ${isDark ? 'bg-emerald-900/30 text-emerald-300 border border-emerald-700' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                      <span>✅</span> Sent
                    </button>
                  </div>
                </div>
              ))}
              {followUpResults.bonus_gesture && (
                <p className={`text-xs p-2.5 rounded-lg border ${c.info}`}>🎁 {followUpResults.bonus_gesture}</p>
              )}
            </div>
          )}
        </div>
      )}

      {/* Empty-state hook — show sample before submission */}
      {!results && (
        <div className={`rounded-xl p-4 border ${isDark ? 'border-emerald-800/40 bg-emerald-900/10' : 'border-emerald-200 bg-gradient-to-r from-emerald-50/80 to-white'}`}>
          <div className="flex items-start gap-3">
            <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? 'bg-emerald-900/40' : 'bg-emerald-100'}`}>
              <span>✨</span>
            </div>
            <div className="min-w-0 flex-1">
              <p className={`text-sm font-semibold ${c.text} mb-1`}>What you'll get</p>
              <div className={`rounded-lg p-3 border mb-2 ${c.messageBody}`}>
                <p className={`text-sm ${c.text} leading-relaxed italic`}>
                  "Sarah, I've been meaning to tell you — that afternoon you spent helping me prep for the interview genuinely changed how I walked into the room. I felt prepared in a way I wouldn't have on my own, and I got the offer."
                </p>
              </div>
              <p className={`text-xs ${c.textMuted}`}>
                2-3 message versions · tone-matched to your relationship · cultural etiquette guidance · per-message "Too mushy?" and "More specific?" adjustments
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Input Form */}
      <div className={`${c.card} border rounded-xl shadow-lg p-6`} onKeyDown={handleFormKeyDown}>
          {/* Recipient Name */}
          <div className="mb-6">
            <label 
              htmlFor="recipient-name"
              className={`block text-lg font-semibold ${c.text} mb-3`}
            >
              Who are you thanking?
            </label>
            <div className="relative">
              <input
                id="recipient-name"
                type="text"
                value={recipientName}
                onChange={(e) => handleRecipientChange(e.target.value)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onFocus={() => recipientName.trim().length >= 2 && recipientSuggestions.length > 0 && setShowSuggestions(true)}
                placeholder="e.g., Sarah, Dr. Martinez, the whole team"
                className={`w-full p-4 border-2 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all ${c.input} ${
                  validationFailed && !recipientName.trim() ? 'ring-2 ring-red-500 border-red-400' : ''
                }`}
                aria-required="true"
                autoComplete="off"
              />
              {/* Auto-suggest dropdown */}
              {showSuggestions && recipientSuggestions.length > 0 && (
                <div className={`absolute z-20 w-full mt-1 border rounded-xl shadow-lg overflow-hidden ${c.card}`}>
                  {recipientSuggestions.map(p => (
                    <button key={p.name} onClick={() => selectRecipient(p)}
                      className={`w-full text-left px-4 py-3 flex items-center justify-between transition-colors ${isDark ? 'hover:bg-zinc-700' : 'hover:bg-emerald-50'}`}>
                      <div>
                        <span className={`text-sm font-bold ${c.text}`}>{p.name}</span>
                        <span className={`text-xs ${c.textMuted} ml-2`}>{p.relationship} · {p.tone}</span>
                      </div>
                      <span className={`text-[10px] ${c.textMuted}`}>Thanked {p.thankCount}x · last {new Date(p.lastThanked).toLocaleDateString()}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {/* Recipient history indicator */}
            {recipientName.trim().length >= 2 && (() => {
              const recHist = getRecipientHistory(recipientName);
              return recHist.length > 0 ? (
                <div className={`mt-2 p-2.5 rounded-lg border text-xs ${c.info}`}>
                  <span className="font-bold">💡 You've thanked {recipientName.trim()} {recHist.length} time{recHist.length > 1 ? 's' : ''} before.</span>
                  <span className={`${isDark ? 'text-blue-300' : 'text-blue-700'} ml-1`}>
                    Last: {new Date(recHist[0].sentAt).toLocaleDateString()} ({recHist[0].context}).
                  </span>
                  <span className={`ml-1 ${c.textMuted}`}>Your messages will be varied to avoid repetition.</span>
                </div>
              ) : null;
            })()}
          </div>

          {/* Gratitude Points */}
          <div className="mb-6">
            <label 
              htmlFor="gratitude-points"
              className={`block text-lg font-semibold ${c.text} mb-3`}
            >
              What are you grateful for?
            </label>
            <textarea
              id="gratitude-points"
              value={gratitudePoints}
              onChange={(e) => { setGratitudePoints(e.target.value); if (validationFailed) setValidationFailed(false); }}
              placeholder="List the things you're thankful for (bullet points or free-form):&#10;• Helped me move apartments&#10;• Listened when I was stressed&#10;• Recommended me for the job&#10;• Made me feel welcome"
              className={`w-full h-40 p-4 border-2 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none resize-none transition-all ${c.input} ${
                validationFailed && !gratitudePoints.trim() ? 'ring-2 ring-red-500 border-red-400' : ''
              }`}
              aria-required="true"
            />
            <p className={`text-sm ${c.textMuted} mt-2`}>
              💡 Be specific! The more details you give, the more personal your message will be.
            </p>
            {/* Specificity analysis */}
            {gratitudePoints.trim().length > 10 && !specificityData && !specificityDismissed && !results && (
              <button onClick={checkSpecificity} disabled={specificityLoading}
                className={`mt-2 flex items-center gap-1.5 text-xs font-medium ${isDark ? 'text-emerald-400 hover:text-emerald-300' : 'text-emerald-600 hover:text-emerald-700'}`}>
                {specificityLoading ? (<><span className="animate-spin inline-block">⏳</span> Checking…</>) : (<><span>🔍</span> Check if this is specific enough</>)}
              </button>
            )}
            {specificityData && !specificityDismissed && (
              <div className={`mt-3 p-4 rounded-xl border ${c.info}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span>{specificityData.specificity_level === 'vague' ? '🔍' : '💡'}</span>
                    <span className={`text-xs font-bold ${c.text}`}>
                      {specificityData.specificity_level === 'vague' ? 'A few details would make this much more personal' : 'Good start — a bit more detail will make it great'}
                    </span>
                  </div>
                  <button onClick={() => setSpecificityDismissed(true)} className={`text-xs ${c.textMuted}`}>Skip</button>
                </div>
                <p className={`text-xs ${c.textSecondary} mb-3`}>{specificityData.existing_strengths}</p>
                <div className="space-y-2">
                  {specificityData.questions?.map((q, i) => (
                    <div key={i}>
                      <label className={`text-xs font-medium ${c.text} mb-1 block`}>{q.question}</label>
                      <input type="text" value={specificityAnswers[i] || ''} placeholder={q.placeholder}
                        onChange={(e) => setSpecificityAnswers(prev => ({ ...prev, [i]: e.target.value }))}
                        className={`w-full p-2.5 border rounded-lg text-sm outline-none ${c.input}`} />
                      <p className={`text-[10px] ${c.textMuted} mt-0.5`}>{q.why}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Gift Specificity Enhancement - Show for gift-related contexts */}
          {(context === 'Gift received' || context === 'Wedding gift' || context === 'Baby shower gift') && (
            <div className={`mb-6 p-4 ${c.giftSection}`}>
              <h3 className={`text-sm font-semibold ${isDark ? 'text-amber-200' : 'text-amber-900'} mb-3 flex items-center gap-2`}>
                <span>🎁</span>
                Make It Extra Personal (Optional)
              </h3>
              
              <div className="space-y-3">
                <div>
                  <label 
                    htmlFor="gift-details"
                    className={`block text-sm font-medium ${isDark ? 'text-amber-200' : 'text-amber-900'} mb-2`}
                  >
                    Specific details about the gift
                  </label>
                  <input
                    id="gift-details"
                    type="text"
                    value={specificGiftDetails}
                    onChange={(e) => setSpecificGiftDetails(e.target.value)}
                    placeholder="e.g., 'the blue scarf', 'the cookbook with Italian recipes', 'the personalized mug'"
                    className={`w-full p-3 border rounded-lg focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none ${c.giftInput}`}
                  />
                </div>
                
                <div>
                  <label 
                    htmlFor="how-use"
                    className={`block text-sm font-medium ${isDark ? 'text-amber-200' : 'text-amber-900'} mb-2`}
                  >
                    How you'll use it or what it means to you
                  </label>
                  <input
                    id="how-use"
                    type="text"
                    value={howYoullUseIt}
                    onChange={(e) => setHowYoullUseIt(e.target.value)}
                    placeholder="e.g., 'I'll wear it to work', 'reminds me of our trip', 'perfect for my morning coffee'"
                    className={`w-full p-3 border rounded-lg focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none ${c.giftInput}`}
                  />
                </div>
              </div>
              
              <p className={`text-xs ${isDark ? 'text-amber-300' : 'text-amber-700'} mt-2`}>
                ✨ These details will make your thank-you feel much more thoughtful and genuine
              </p>
            </div>
          )}

          {/* Context and Relationship Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label 
                htmlFor="context"
                className={`block text-sm font-medium ${c.label} mb-2`}
              >
                Context / Occasion
              </label>
              <select
                id="context"
                value={context}
                onChange={(e) => setContext(e.target.value)}
                className={`w-full p-3 border rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none ${c.select}`}
              >
                {contextOptions.map(opt => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>

            <div>
              <label 
                htmlFor="relationship"
                className={`block text-sm font-medium ${c.label} mb-2`}
              >
                Your Relationship
              </label>
              <select
                id="relationship"
                value={relationship}
                onChange={(e) => setRelationship(e.target.value)}
                className={`w-full p-3 border rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none ${c.select}`}
              >
                {relationshipOptions.map(opt => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Tone Selection */}
          <div className="mb-6">
            <label className={`block text-sm font-medium ${c.label} mb-3`}>
              Tone Preference
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {toneOptions.map(option => (
                <button
                  key={option.id}
                  onClick={() => setTone(option.label)}
                  className={`p-3 rounded-lg border-2 transition-all text-center ${c.toneChip(tone === option.label)}`}
                  aria-pressed={tone === option.label}
                >
                  <div className="text-2xl mb-1">{option.icon}</div>
                  <div className="text-sm font-medium">{option.label}</div>
                </button>
              ))}
            </div>
            {/* Tone calibration warning */}
            {toneWarning && (
              <div className={`mt-3 p-3 rounded-lg border ${c.warning}`}>
                <div className="flex items-start gap-2">
                  <span className="text-sm mt-0.5">💡</span>
                  <div>
                    <p className={`text-xs font-bold`}>Consider: {toneWarning.suggested} tone</p>
                    <p className={`text-xs mt-0.5`}>{toneWarning.reason}</p>
                    <button onClick={() => setTone(toneWarning.suggested)}
                      className={`mt-1.5 px-2.5 py-1 rounded text-[10px] font-bold ${isDark ? 'bg-amber-800 text-amber-100 hover:bg-amber-700' : 'bg-amber-200 text-amber-900 hover:bg-amber-300'}`}>
                      Switch to {toneWarning.suggested}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Cultural Context */}
          <div className="mb-6">
            <label 
              htmlFor="cultural-context"
              className={`block text-sm font-medium ${c.label} mb-2`}
            >
              Cultural Context (helps with formality and etiquette)
            </label>
            <select
              id="cultural-context"
              value={culturalContext}
              onChange={(e) => setCulturalContext(e.target.value)}
              className={`w-full p-3 border rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none ${c.select}`}
            >
              {culturalContextOptions.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            <p className={`text-xs ${c.textMuted} mt-1`}>
              ✨ Auto-detected from your browser settings. Different cultures have different gratitude etiquette — this helps tailor the formality and timing.
            </p>
          </div>

          {/* Delivery Method */}
          <div className="mb-6">
            <label 
              htmlFor="delivery-method"
              className={`block text-sm font-medium ${c.label} mb-2`}
            >
              How will you send this?
            </label>
            <select
              id="delivery-method"
              value={deliveryMethod}
              onChange={(e) => setDeliveryMethod(e.target.value)}
              className={`w-full p-3 border rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none ${c.select}`}
            >
              {deliveryMethodOptions.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          {/* Handwriting Template Option */}
          <div className="mb-6">
            <label className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-colors ${c.handwritingCheck}`}>
              <input
                type="checkbox"
                checked={needHandwritingTemplate}
                onChange={(e) => setNeedHandwritingTemplate(e.target.checked)}
                className="w-5 h-5 rounded border-zinc-400 text-emerald-600 focus:ring-2 focus:ring-emerald-500"
              />
              <div className="flex-1">
                <div className={`font-medium ${isDark ? 'text-blue-200' : 'text-blue-900'}`}>Generate handwritten card template</div>
                <div className={`text-sm ${isDark ? 'text-blue-300' : 'text-blue-700'}`}>
                  Get layout guidance, font suggestions, and formatting for physical cards
                </div>
              </div>
            </label>
          </div>

          {/* Length Slider */}
          <div className="mb-6">
            <label 
              htmlFor="length-slider"
              className={`block text-sm font-medium ${c.label} mb-3`}
            >
              Message Length: <span className={`font-semibold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>
                {length <= 3 ? 'Concise' : length <= 7 ? 'Moderate' : 'Detailed'}
              </span>
            </label>
            <input
              id="length-slider"
              type="range"
              min="1"
              max="10"
              value={length}
              onChange={(e) => setLength(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              aria-valuemin="1"
              aria-valuemax="10"
              aria-valuenow={length}
              aria-label="Message length slider"
            />
            <div className={`flex justify-between text-xs ${c.textMuted} mt-1`}>
              <span>Short & sweet</span>
              <span>Detailed & thorough</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleGenerate}
              disabled={loading}
              className={`flex-1 font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 ${
                loading ? c.btnDisabled + ' cursor-not-allowed' : c.btnPrimary
              }`}
              aria-label="Generate thank you messages"
            >
              {loading ? (
                <>
                  <span className="animate-spin inline-block">⏳</span>
                  Crafting messages...
                </>
              ) : (
                <>
                  <span>❤️</span>
                  Generate Thank You Messages
                </>
              )}
            </button>
            
            {results && (
              <button
                onClick={handleReset}
                className={`px-6 py-3 border-2 font-semibold rounded-lg transition-colors ${
                  isDark ? 'border-zinc-600 hover:border-zinc-500 text-zinc-200' : 'border-slate-300 hover:border-slate-400 text-slate-700'
                }`}
                aria-label="Reset form"
              >
                Reset
              </button>
            )}
          </div>
          <p className={`text-xs text-center ${c.textMuted} mt-2`}>
            <kbd className={`px-1.5 py-0.5 rounded text-xs font-mono ${isDark ? 'bg-zinc-700' : 'bg-slate-100'}`}>Ctrl</kbd>+<kbd className={`px-1.5 py-0.5 rounded text-xs font-mono ${isDark ? 'bg-zinc-700' : 'bg-slate-100'}`}>Enter</kbd> to submit from any field
          </p>

          {/* Error Display */}
          {error && (
            <div 
              className={`mt-4 p-4 border rounded-lg flex items-start gap-3 ${c.error}`}
              role="alert"
            >
              <span className="flex-shrink-0 mt-0.5">⚠️</span>
              <p className="text-sm">{error}</p>
            </div>
          )}

          {/* Pre-result cross-ref */}
          <p className={`text-xs text-center ${c.textMuted} mt-4`}>
            Need to apologize alongside your thanks?{' '}
            <a href="/ApologyCalibrator" target="_blank" rel="noopener noreferrer" className={c.link}>Apology Calibrator</a>{' '}
            helps you get the tone exactly right.
          </p>
        </div>

        {/* Results Section */}
        {results && (
          <div className="space-y-6">
            {/* Awkwardness Acknowledgment */}
            {results.if_you_feel_awkward && (
              <div className={`border-2 rounded-xl p-5 ${c.purple}`}>
                <div className="flex items-start gap-3">
                  <span className="flex-shrink-0 mt-1">🎁</span>
                  <div>
                    <p className="font-medium mb-1">
                      {results.if_you_feel_awkward.permission}
                    </p>
                    <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-800'}`}>
                      {results.if_you_feel_awkward.reframe}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Message Options */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className={`text-2xl font-bold ${c.text}`}>
                  Your Thank You Messages
                </h2>
                <div className="flex items-center gap-2">
                  {results.thank_you_messages?.length > 1 && (
                    <button onClick={() => setShowComparison(!showComparison)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                        showComparison ? (isDark ? 'bg-emerald-900/40 text-emerald-300' : 'bg-emerald-100 text-emerald-700') : c.btnSecondary
                      }`}>
                      <span>{showComparison ? '📋' : '⚖️'}</span> {showComparison ? 'Full View' : 'Compare'}
                    </button>
                  )}
                  <ActionBar
                    content={buildAllText()}
                    title={`Thank You Messages — ${recipientName}`}
                    copyLabel="Copy All"
                    printLabel="Print All"
                  />
                </div>
              </div>

              {/* Tone calibration suggestion from AI */}
              {results.tone_calibration && (
                <div className={`mb-4 p-3 rounded-lg border ${c.warning}`}>
                  <p className="text-xs"><strong>💡 Tone suggestion:</strong> {results.tone_calibration.reason}</p>
                </div>
              )}

              {/* ── COMPARISON VIEW ── */}
              {showComparison && results.thank_you_messages?.length > 1 ? (
                <div className={`border-2 rounded-xl overflow-hidden ${c.card}`}>
                  <div className={`grid grid-cols-${Math.min(results.thank_you_messages.length, 3)} divide-x ${isDark ? 'divide-zinc-700' : 'divide-slate-200'}`}>
                    {results.thank_you_messages.map((msg, i) => (
                      <div key={i} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className={`text-sm font-bold ${c.text}`}>{msg.version}</h4>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${c.toneBadge}`}>{msg.tone}</span>
                        </div>
                        <p className={`text-sm ${c.textSecondary} leading-relaxed mb-3`}>{getMessageText(i, msg.message_text)}</p>
                        <p className={`text-[10px] ${c.textMuted} mb-2`}>{msg.length} words · {msg.best_for}</p>
                        <div className="flex gap-1.5">
                          <CopyBtn content={`${getMessageText(i, msg.message_text)}\n\n— Generated by DeftBrain · deftbrain.com`} label="Copy" />
                          <button onClick={() => { markMessageSent(i); }}
                            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold ${isDark ? 'bg-emerald-900/30 text-emerald-300 border border-emerald-700' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                            <span>✅</span> Sent
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
              
              <div className="space-y-4">
                {results.thank_you_messages?.map((message, index) => {
                  const messageText = getMessageText(index, message.message_text);
                  const isEditing = editingIndex === index;
                  const isEdited = editedMessages[index] != null && editedMessages[index] !== message.message_text;
                  return (
                  <div 
                    key={index} 
                    className={`rounded-xl shadow-lg p-6 border-2 transition-colors ${c.messageCard}`}
                  >
                    {/* Message Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className={`text-lg font-bold ${c.text} mb-1`}>
                            {message.version}
                          </h3>
                          {isEdited && <span className={`text-xs ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>✏️ edited</span>}
                        </div>
                        <div className={`flex items-center gap-3 text-sm ${c.textSecondary}`}>
                          <span className={`inline-block px-3 py-1 rounded-full font-medium ${c.toneBadge}`}>
                            {message.tone}
                          </span>
                          <span>{message.length} words</span>
                        </div>
                      </div>
                    </div>

                    {/* Why This Works */}
                    <div className={`border-l-4 rounded-r-lg p-3 mb-4 ${c.info}`}>
                      <p className="text-sm">
                        <strong>Why this works:</strong> {message.why_this_works}
                      </p>
                      <p className={`text-sm mt-1 ${isDark ? 'text-blue-300' : 'text-blue-800'}`}>
                        <strong>Best for:</strong> {message.best_for}
                      </p>
                    </div>

                    {/* Message Text — editable */}
                    <div className={`rounded-lg p-4 border mb-4 ${c.messageBody}`}>
                      {isEditing ? (
                        <textarea
                          value={editedMessages[index] ?? message.message_text}
                          onChange={(e) => setEditedMessages(prev => ({ ...prev, [index]: e.target.value }))}
                          rows={8}
                          className={`w-full p-3 border rounded-lg outline-none text-sm resize-y focus:ring-2 focus:ring-emerald-300 ${c.input}`}
                        />
                      ) : (
                        <p className={`${c.text} text-base leading-relaxed whitespace-pre-wrap`}>
                          {messageText}
                        </p>
                      )}
                    </div>

                    {/* Edit controls */}
                    {isEditing ? (
                      <div className="flex gap-2 mb-3">
                        <button onClick={() => setEditingIndex(null)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold ${c.btnPrimary}`}>Done Editing</button>
                        <button onClick={() => cancelEditing(index, message.message_text)}
                          className={`text-xs ${c.textMuted}`}>Reset to original</button>
                      </div>
                    ) : null}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2">
                      <CopyBtn content={`${messageText}\n\n— Generated by DeftBrain · deftbrain.com`} label="Copy" />

                      <button
                        onClick={() => printSection(message.version, messageText)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors text-sm font-medium ${c.btnSecondary}`}
                        aria-label={`Print ${message.version}`}
                      >
                        <span className="text-sm">🖨️</span>
                        Print
                      </button>

                      {!isEditing && (
                        <button onClick={() => startEditing(index, message.message_text)}
                          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors text-sm font-medium ${c.btnSecondary}`}>
                          <span>✏️</span> Edit
                        </button>
                      )}

                      <button
                        onClick={() => { markMessageSent(index); }}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors text-sm font-medium ${isDark ? 'bg-emerald-900/30 text-emerald-300 hover:bg-emerald-800/40 border border-emerald-700' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'}`}
                      >
                        <span>✅</span> Mark Sent
                      </button>

                      <button
                        onClick={() => handleAdjust(message, index, 'less-mushy')}
                        disabled={adjustingIndex === index}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
                          adjustingIndex === index ? c.btnDisabled + ' cursor-not-allowed' : c.btnSecondary
                        }`}
                        aria-label="Make this message less intense"
                      >
                        {adjustingIndex === index ? (
                          <><span className="animate-spin inline-block">⏳</span> Adjusting...</>
                        ) : (
                          <><span>➖</span> Too mushy?</>
                        )}
                      </button>

                      <button
                        onClick={() => handleAdjust(message, index, 'more-specific')}
                        disabled={adjustingIndex === index}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
                          adjustingIndex === index ? c.btnDisabled + ' cursor-not-allowed' : c.btnSecondary
                        }`}
                        aria-label="Make this message more specific"
                      >
                        {adjustingIndex === index ? (
                          <><span className="animate-spin inline-block">⏳</span> Adjusting...</>
                        ) : (
                          <><span>➕</span> More specific?</>
                        )}
                      </button>
                    </div>

                    {/* Delivery shortcuts */}
                    <div className={`flex flex-wrap gap-1.5 mt-2 pt-2 border-t ${isDark ? 'border-zinc-700' : 'border-slate-200'}`}>
                      <span className={`text-[10px] ${c.textMuted} self-center mr-1`}>Send via:</span>
                      <a href={buildMailtoLink(messageText)} target="_blank" rel="noopener noreferrer"
                        className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium ${c.btnSecondary}`}>
                        <span>📧</span> Email
                      </a>
                      <a href={buildSmsLink(messageText)} target="_blank" rel="noopener noreferrer"
                        className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium ${c.btnSecondary}`}>
                        <span>📱</span> Text
                      </a>
                      <a href={buildWhatsAppLink(messageText)} target="_blank" rel="noopener noreferrer"
                        className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium ${c.btnSecondary}`}>
                        <span>💬</span> WhatsApp
                      </a>
                    </div>
                  </div>
                  );
                })}
              </div>
              )}

            {/* Delivery Suggestions */}
            {results.delivery_suggestions && (
              <div className={`border-2 rounded-xl p-5 ${c.success}`}>
                <div className="flex items-start gap-3 mb-3">
                  <span className="flex-shrink-0 mt-1">📤</span>
                  <h3 className="text-lg font-bold">
                    Delivery Suggestions
                  </h3>
                </div>
                <div className={`space-y-2 ml-8 ${isDark ? 'text-emerald-200' : 'text-emerald-800'}`}>
                  <p>
                    <strong>Method:</strong> {results.delivery_suggestions.method}
                  </p>
                  <p>
                    <strong>Timing:</strong> {results.delivery_suggestions.timing}
                  </p>
                  {results.delivery_suggestions.timing_cultural_note && (
                    <p className={`p-2 rounded ${isDark ? 'bg-emerald-900/30' : 'bg-emerald-100'}`}>
                      <strong>Cultural Note:</strong> {results.delivery_suggestions.timing_cultural_note}
                    </p>
                  )}
                  {results.delivery_suggestions.additional_gesture && (
                    <p>
                      <strong>Bonus idea:</strong> {results.delivery_suggestions.additional_gesture}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Personalization Tips */}
            {results.personalization_tips && results.personalization_tips.length > 0 && (
              <div className={`border-2 rounded-xl p-5 ${c.warning}`}>
                <div className="flex items-start gap-3 mb-3">
                  <span className="flex-shrink-0 mt-1">✉️</span>
                  <h3 className="text-lg font-bold">
                    Make It Even More Personal
                  </h3>
                </div>
                <ul className={`space-y-2 ml-8 list-disc ${isDark ? 'text-amber-200' : 'text-amber-800'}`}>
                  {results.personalization_tips.map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Conditional cross-ref — context-aware */}
            {context === 'Post-interview' && (
              <p className={`text-xs text-center ${c.textMuted} mt-2`}>
                Sending a follow-up can feel awkward —{' '}
                <a href="/DifficultTalkRehearser" target="_blank" rel="noopener noreferrer" className={c.link}>Difficult Talk Rehearser</a>{' '}
                can help you prepare if the conversation continues.
              </p>
            )}
            {(context === 'Condolence support' || context === 'Emotional support') && (
              <p className={`text-xs text-center ${c.textMuted} mt-2`}>
                If you're navigating a sensitive relationship,{' '}
                <a href="/VelvetHammer" target="_blank" rel="noopener noreferrer" className={c.link}>Velvet Hammer</a>{' '}
                helps you say hard things with warmth.
              </p>
            )}
            </div>
          </div>
        )}

        {/* Handwriting Template */}
        {results && results.handwriting_template && (
          <div className={`border-2 rounded-xl p-6 ${c.success}`}>
            <div className="flex items-start gap-3 mb-4">
              <span className="text-xl flex-shrink-0 mt-1">✉️</span>
              <div>
                <h3 className="text-lg font-bold mb-1">
                  Handwritten Card Template
                </h3>
                <p className={`text-sm ${c.textSecondary}`}>
                  Follow this layout for a beautiful handwritten thank-you note
                </p>
              </div>
              
            </div>

            <div className={`rounded-lg p-6 border-2 shadow-inner ${isDark ? 'bg-zinc-900 border-emerald-800' : 'bg-white border-emerald-300'}`}>
              {/* Card Layout Visual Guide */}
              <div className="space-y-4">
                <div className={`border-b pb-3 ${isDark ? 'border-zinc-700' : 'border-slate-200'}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide mb-1 ${c.textMuted}`}>
                    Opening (top right or center)
                  </p>
                  <p className={`${c.text} font-serif text-lg`}>
                    {results.handwriting_template.opening_placement}
                  </p>
                </div>

                <div className={`border-b pb-3 ${isDark ? 'border-zinc-700' : 'border-slate-200'}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide mb-1 ${c.textMuted}`}>
                    Main Message (body)
                  </p>
                  <p className={`${c.text} leading-relaxed whitespace-pre-wrap`}>
                    {results.handwriting_template.message_layout}
                  </p>
                </div>

                <div>
                  <p className={`text-xs font-semibold uppercase tracking-wide mb-1 ${c.textMuted}`}>
                    Closing (bottom right)
                  </p>
                  <p className={`${c.text} font-serif`}>
                    {results.handwriting_template.closing_placement}
                  </p>
                </div>
              </div>
            </div>

            {/* Font & Style Suggestions */}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className={`rounded-lg p-4 border ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-emerald-200'}`}>
                <h4 className={`font-semibold ${c.text} mb-2 text-sm`}>Font Suggestions</h4>
                <ul className={`space-y-1 text-sm ${c.textSecondary}`}>
                  {results.handwriting_template.font_suggestions?.map((font, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className={isDark ? 'text-emerald-500' : 'text-emerald-400'}>•</span>
                      {font}
                    </li>
                  ))}
                </ul>
              </div>

              <div className={`rounded-lg p-4 border ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-emerald-200'}`}>
                <h4 className={`font-semibold ${c.text} mb-2 text-sm`}>Card Tips</h4>
                <ul className={`space-y-1 text-sm ${c.textSecondary}`}>
                  {results.handwriting_template.writing_tips?.map((tip, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className={isDark ? 'text-emerald-500' : 'text-emerald-400'}>•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {results.handwriting_template.length_guidance && (
              <div className={`mt-4 p-3 rounded-lg ${isDark ? 'bg-emerald-900/30' : 'bg-emerald-100'}`}>
                <p className={`text-sm ${c.text}`}>
                  <strong>Length:</strong> {results.handwriting_template.length_guidance}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Post-result cross-ref */}
        {results && (
          <p className={`text-xs text-center ${c.textMuted}`}>
            Message feeling close but not quite right?{' '}
            <a href="/ApologyCalibrator" target="_blank" rel="noopener noreferrer" className={c.link}>Apology Calibrator</a>{' '}
            fine-tunes tone when gratitude mixes with "sorry it took so long."
          </p>
        )}
      </div>
    </div>
  );
};

GratitudeDebtClearer.displayName = 'GratitudeDebtClearer';
export default GratitudeDebtClearer;
