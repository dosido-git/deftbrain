import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useClaudeAPI } from '../hooks/useClaudeAPI';
import { useTheme } from '../hooks/useTheme';
import { CopyBtn, PrintBtn } from '../components/ActionButtons';

// ════════════════════════════════════════════════════════════
// THEME
// ════════════════════════════════════════════════════════════
const useColors = () => {
  const { theme } = useTheme();
  const d = theme === 'dark';
  return {
    d,
    bg: d ? 'bg-zinc-900' : 'bg-stone-50',
    bgCard: d ? 'bg-zinc-800' : 'bg-white',
    bgInset: d ? 'bg-zinc-700' : 'bg-stone-100',
    bgWarm: d ? 'bg-amber-900/20' : 'bg-amber-50/60',
    bgHover: d ? 'hover:bg-zinc-700' : 'hover:bg-stone-50',
    text: d ? 'text-zinc-50' : 'text-stone-900',
    textSec: d ? 'text-zinc-400' : 'text-stone-600',
    textMut: d ? 'text-zinc-500' : 'text-stone-400',
    textWarm: d ? 'text-amber-300' : 'text-amber-800',
    border: d ? 'border-zinc-700' : 'border-stone-200',
    borderWarm: d ? 'border-amber-700/40' : 'border-amber-200',
    accent: d ? 'text-amber-400' : 'text-amber-600',
    accentBg: d ? 'bg-amber-400' : 'bg-amber-600',
    input: d ? 'bg-zinc-700 border-zinc-600 text-zinc-100 placeholder-zinc-500 focus:border-amber-500' : 'bg-white border-stone-300 text-stone-900 placeholder-stone-400 focus:border-amber-500',
    btn: d ? 'bg-amber-500 hover:bg-amber-400 text-zinc-900' : 'bg-stone-800 hover:bg-stone-900 text-white',
    btnSec: d ? 'bg-zinc-700 hover:bg-zinc-600 text-zinc-200' : 'bg-stone-100 hover:bg-stone-200 text-stone-700',
    btnGhost: d ? 'text-zinc-400 hover:text-zinc-100' : 'text-stone-500 hover:text-stone-800',
    btnDis: d ? 'bg-zinc-700 text-zinc-500 cursor-not-allowed' : 'bg-stone-200 text-stone-400 cursor-not-allowed',
    tag: d ? 'bg-zinc-700 text-zinc-300' : 'bg-stone-100 text-stone-600',
    successBg: d ? 'bg-emerald-900/30 border-emerald-700 text-emerald-300' : 'bg-emerald-50 border-emerald-200 text-emerald-800',
    errBg: d ? 'bg-red-900/30 border-red-700' : 'bg-red-50 border-red-200',
    errText: d ? 'text-red-300' : 'text-red-700',
    letterBg: d ? 'bg-zinc-800 border-amber-700/30' : 'bg-amber-50/40 border-amber-200',
    letterText: d ? 'text-zinc-200' : 'text-stone-800',
    progressDone: d ? 'bg-amber-400' : 'bg-amber-600',
    progressPending: d ? 'bg-zinc-700' : 'bg-stone-200',
    envelopeBg: d ? 'bg-amber-900/30 border-amber-700/50' : 'bg-amber-100/60 border-amber-300',
    diffAdd: d ? 'bg-emerald-900/30 border-emerald-700' : 'bg-emerald-50 border-emerald-200',
    diffRem: d ? 'bg-red-900/20 border-red-800' : 'bg-red-50 border-red-200',
    diffChg: d ? 'bg-amber-900/20 border-amber-700' : 'bg-amber-50 border-amber-200',
    lockBg: d ? 'bg-indigo-900/20 border-indigo-700' : 'bg-indigo-50 border-indigo-200',
    lockText: d ? 'text-indigo-300' : 'text-indigo-800',
  };
};

// ════════════════════════════════════════════════════════════
// CONSTANTS
// ════════════════════════════════════════════════════════════
const LS_KEY = 'deftbrain_finalwish_draft';

const CHAPTERS = [
  { id: 'accounts', label: 'Accounts', icon: '🔑', short: 'Accounts' },
  { id: 'documents', label: 'Documents & Files', icon: '📄', short: 'Docs' },
  { id: 'financial', label: 'Financial', icon: '💰', short: 'Financial' },
  { id: 'messages', label: 'Messages', icon: '💌', short: 'Messages' },
  { id: 'wishes', label: 'Wishes', icon: '🏠', short: 'Wishes' },
  { id: 'review', label: 'Review & Export', icon: '📋', short: 'Export' },
];

const ACCOUNT_CATEGORIES = [
  { id: 'financial', label: 'Financial', icon: '💳' },
  { id: 'email', label: 'Email', icon: '📧' },
  { id: 'social', label: 'Social Media', icon: '🌐' },
  { id: 'cloud', label: 'Cloud Storage', icon: '☁️' },
  { id: 'subscription', label: 'Subscriptions', icon: '⭐' },
  { id: 'work', label: 'Work', icon: '📄' },
  { id: 'medical', label: 'Medical', icon: '🛡️' },
  { id: 'other', label: 'Other', icon: '🔑' },
];

const SOCIAL_MEDIA_OPTIONS = [
  { value: 'memorialize', label: 'Memorialize (keep as memorial)' },
  { value: 'delete', label: 'Delete after downloading data' },
  { value: 'decide', label: 'Let them decide' },
  { value: 'custom', label: 'Custom instructions' },
];

const DOC_CHECKLIST = [
  { id: 'will', label: 'Will / estate documents', icon: '📄' },
  { id: 'insurance', label: 'Insurance policies (life, health, auto, home)', icon: '📄' },
  { id: 'tax', label: 'Tax returns / financial records', icon: '📄' },
  { id: 'identity', label: 'Birth certificate / passport / ID', icon: '📄' },
  { id: 'property', label: 'Property deeds / vehicle titles', icon: '📄' },
  { id: 'medical', label: 'Medical records / advance directive', icon: '📄' },
  { id: 'photos', label: 'Photos & videos that matter most', icon: '📋' },
  { id: 'sentimental', label: 'Sentimental digital files (journals, creative work)', icon: '📋' },
];

const FOLLOW_UP_PROMPTS = [
  "Do you have any cryptocurrency or digital wallets?",
  "What about cloud storage — Google Drive, Dropbox, iCloud? There might be photos or documents they'd want.",
  "Any subscriptions that should be cancelled to avoid ongoing charges? Streaming, gym, SaaS tools?",
  "Work accounts that need to be handed off or deactivated?",
  "Medical patient portals or insurance accounts?",
  "Social media — do you want profiles memorialized, deleted, or left alone?",
];

const LANGUAGES = [
  { code: 'en', name: 'English' }, { code: 'es', name: 'Spanish' }, { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' }, { code: 'pt', name: 'Portuguese' }, { code: 'it', name: 'Italian' },
  { code: 'zh', name: 'Chinese' }, { code: 'ja', name: 'Japanese' }, { code: 'ko', name: 'Korean' },
  { code: 'ar', name: 'Arabic' }, { code: 'hi', name: 'Hindi' }, { code: 'ru', name: 'Russian' },
  { code: 'vi', name: 'Vietnamese' }, { code: 'tl', name: 'Filipino' }, { code: 'pl', name: 'Polish' },
];

const DELIVERY_LOCATIONS = [
  { id: 'safe', label: 'Home safe or lockbox', icon: '🔒' },
  { id: 'attorney', label: "Attorney's office", icon: '⚖️' },
  { id: 'deposit', label: 'Safety deposit box', icon: '🏦' },
  { id: 'drawer', label: 'Desk drawer / filing cabinet', icon: '📁' },
  { id: 'digital', label: 'Shared cloud drive', icon: '☁️' },
  { id: 'envelope', label: 'Sealed envelope with trusted person', icon: '✉️' },
  { id: 'other', label: 'Other', icon: '📍' },
];

const BRANDING = '\n\n— Generated by DeftBrain · deftbrain.com';
const BRANDING_HTML = '<div style="text-align:center;color:#a8a29e;font-size:0.8em;margin-top:40px;padding-top:16px;border-top:1px solid #e7e5e4;">Generated by DeftBrain · deftbrain.com</div>';

// ════════════════════════════════════════════════════════════
// FEATURE 1: ENCRYPTION UTILITIES (Web Crypto API)
// ════════════════════════════════════════════════════════════
const CRYPTO_ALGO = 'AES-GCM';
const CRYPTO_ITER = 100000;

async function deriveKey(passphrase, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: CRYPTO_ITER, hash: 'SHA-256' }, keyMaterial, { name: CRYPTO_ALGO, length: 256 }, false, ['encrypt', 'decrypt']);
}

async function encryptText(plaintext, passphrase) {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(passphrase, salt);
  const encrypted = await crypto.subtle.encrypt({ name: CRYPTO_ALGO, iv }, key, enc.encode(plaintext));
  const combined = new Uint8Array(salt.length + iv.length + new Uint8Array(encrypted).length);
  combined.set(salt, 0);
  combined.set(iv, salt.length);
  combined.set(new Uint8Array(encrypted), salt.length + iv.length);
  return btoa(String.fromCharCode(...combined));
}

async function decryptText(base64Data, passphrase) {
  const data = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
  const salt = data.slice(0, 16);
  const iv = data.slice(16, 28);
  const encrypted = data.slice(28);
  const key = await deriveKey(passphrase, salt);
  const dec = new TextDecoder();
  const decrypted = await crypto.subtle.decrypt({ name: CRYPTO_ALGO, iv }, key, encrypted);
  return dec.decode(decrypted);
}

// ════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ════════════════════════════════════════════════════════════
const FinalWish = () => {
  const { callToolEndpoint, loading } = useClaudeAPI();
  const c = useColors();
  const fileInputRef = useRef(null);

  // ── Navigation ──
  const [screen, setScreen] = useState('welcome');
  // welcome | chapter | emergency | diff | interview | delivery
  const [currentChapter, setCurrentChapter] = useState(0);
  const [resumePrompt, setResumePrompt] = useState(false);

  // ── Core data (all persisted) ──
  const [userName, setUserName] = useState('');
  const [trustedPeople, setTrustedPeople] = useState([{ id: 'tp_1', name: '', role: 'primary' }]);
  const [accounts, setAccounts] = useState([]);
  const [documents, setDocuments] = useState({});
  const [docNotes, setDocNotes] = useState('');
  const [financialAccounts, setFinancialAccounts] = useState([]);
  const [recurringBills, setRecurringBills] = useState('');
  const [messages, setMessages] = useState([]);
  const [pets, setPets] = useState([]);
  const [homeNotes, setHomeNotes] = useState('');
  const [deviceNotes, setDeviceNotes] = useState('');
  const [memorialWishes, setMemorialWishes] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [emergencyContacts, setEmergencyContacts] = useState([]);
  const [sectionVisibility, setSectionVisibility] = useState({});
  // ── v3: Delivery & encryption persisted data ──
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [passphraseHint, setPassphraseHint] = useState('');

  // ── UI-only state (not persisted) ──
  const [accountDump, setAccountDump] = useState('');
  const [accountFollowUpIndex, setAccountFollowUpIndex] = useState(0);
  const [followUpAnswer, setFollowUpAnswer] = useState('');
  const [showFollowUps, setShowFollowUps] = useState(false);
  const [financialDump, setFinancialDump] = useState('');
  const [messageRecipient, setMessageRecipient] = useState('');
  const [activeMessageIndex, setActiveMessageIndex] = useState(null);
  const [messageStep, setMessageStep] = useState(0);
  const [editingDraft, setEditingDraft] = useState(false);
  const [showMemorial, setShowMemorial] = useState(false);
  const [aiError, setAiError] = useState('');
  const [chapterComplete, setChapterComplete] = useState({});
  const [toasts, setToasts] = useState([]);
  const [exportFilter, setExportFilter] = useState('all');
  const [importedData, setImportedData] = useState(null);

  // ── Emergency mode state ──
  const [emergencyDump, setEmergencyDump] = useState('');
  const [emergencyMessage, setEmergencyMessage] = useState('');

  // ── v3: Encryption state ──
  const [passphrase, setPassphrase] = useState('');
  const [showPassphrase, setShowPassphrase] = useState(false);
  const [encryptionEnabled, setEncryptionEnabled] = useState(false);

  // ── v3: Interview state ──
  const [interviewHistory, setInterviewHistory] = useState([]);
  const [interviewAnswer, setInterviewAnswer] = useState('');
  const [currentInterviewQ, setCurrentInterviewQ] = useState(null);

  // ── v3: Smart gaps state ──
  const [smartGaps, setSmartGaps] = useState(null);
  const [gapsLoading, setGapsLoading] = useState(false);

  // ── v3: Translation state ──
  const [translatingIdx, setTranslatingIdx] = useState(null);

  // ── Derived ──
  const primaryPerson = trustedPeople.find(p => p.role === 'primary') || trustedPeople[0];
  const trustedPerson = primaryPerson?.name || '';
  const allPeopleNames = trustedPeople.filter(p => p.name.trim()).map(p => p.name);

  // ══════════════════════════════════════════
  // SAVE & RESUME (localStorage)
  // ══════════════════════════════════════════
  const buildSaveData = useCallback(() => ({
    userName, trustedPeople, accounts, documents, docNotes,
    financialAccounts, recurringBills, messages, pets,
    homeNotes, deviceNotes, memorialWishes, specialRequests,
    emergencyContacts, sectionVisibility,
    deliveryLocation, deliveryNotes, passphraseHint,
    lastSaved: new Date().toISOString(),
    createdAt: null,
  }), [userName, trustedPeople, accounts, documents, docNotes, financialAccounts, recurringBills, messages, pets, homeNotes, deviceNotes, memorialWishes, specialRequests, emergencyContacts, sectionVisibility, deliveryLocation, deliveryNotes, passphraseHint]);

  const loadSavedData = useCallback((data) => {
    if (!data) return;
    if (data.userName) setUserName(data.userName);
    if (data.trustedPeople?.length) setTrustedPeople(data.trustedPeople);
    if (data.accounts?.length) setAccounts(data.accounts);
    if (data.documents) setDocuments(data.documents);
    if (data.docNotes) setDocNotes(data.docNotes);
    if (data.financialAccounts?.length) setFinancialAccounts(data.financialAccounts);
    if (data.recurringBills) setRecurringBills(data.recurringBills);
    if (data.messages?.length) setMessages(data.messages);
    if (data.pets?.length) setPets(data.pets);
    if (data.homeNotes) setHomeNotes(data.homeNotes);
    if (data.deviceNotes) setDeviceNotes(data.deviceNotes);
    if (data.memorialWishes) setMemorialWishes(data.memorialWishes);
    if (data.specialRequests) setSpecialRequests(data.specialRequests);
    if (data.emergencyContacts?.length) setEmergencyContacts(data.emergencyContacts);
    if (data.sectionVisibility) setSectionVisibility(data.sectionVisibility);
    if (data.deliveryLocation) setDeliveryLocation(data.deliveryLocation);
    if (data.deliveryNotes) setDeliveryNotes(data.deliveryNotes);
    if (data.passphraseHint) setPassphraseHint(data.passphraseHint);
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        const hasContent = data.accounts?.length || data.messages?.length || data.financialAccounts?.length || data.trustedPeople?.some(p => p.name.trim());
        if (hasContent) setResumePrompt(true);
      }
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    if (screen === 'welcome' && !resumePrompt) return;
    const timer = setTimeout(() => {
      try { localStorage.setItem(LS_KEY, JSON.stringify(buildSaveData())); } catch { /* full */ }
    }, 1500);
    return () => clearTimeout(timer);
  }, [buildSaveData, screen, resumePrompt]);

  const resumeDraft = useCallback(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) { loadSavedData(JSON.parse(raw)); setResumePrompt(false); setScreen('chapter'); setCurrentChapter(0); addToast('Draft restored', 'success'); }
    } catch { addToast('Could not restore draft', 'error'); }
  }, [loadSavedData]);

  const clearDraft = useCallback(() => { localStorage.removeItem(LS_KEY); setResumePrompt(false); addToast('Previous draft cleared', 'success'); }, []);

  const clearAllAndRestart = useCallback(() => {
    localStorage.removeItem(LS_KEY);
    setUserName(''); setTrustedPeople([{ id: 'tp_1', name: '', role: 'primary' }]); setAccounts([]); setDocuments({}); setDocNotes('');
    setFinancialAccounts([]); setRecurringBills(''); setMessages([]); setPets([]); setHomeNotes(''); setDeviceNotes('');
    setMemorialWishes(''); setSpecialRequests(''); setEmergencyContacts([]); setSectionVisibility({});
    setDeliveryLocation(''); setDeliveryNotes(''); setPassphraseHint('');
    setScreen('welcome'); setCurrentChapter(0); addToast('Started fresh', 'success');
  }, []);

  // ══════════════════════════════════════════
  // TOASTS
  // ══════════════════════════════════════════
  const addToast = useCallback((msg, type = 'info') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3500);
  }, []);

  // ══════════════════════════════════════════
  // AI HELPERS
  // ══════════════════════════════════════════
  const callAI = useCallback(async (mode, payload) => {
    setAiError('');
    try {
      return await callToolEndpoint('final-wish', { mode, payload, locale: navigator.language || 'en' });
    } catch (e) { setAiError(e.message || 'AI request failed.'); return null; }
  }, [callToolEndpoint]);

  // ── Build document state summary for AI ──
  const buildDocumentState = useCallback(() => ({
    accountCount: accounts.length,
    accountNames: accounts.map(a => a.name).join(', ') || 'none',
    accountCategories: [...new Set(accounts.map(a => a.category))].join(', ') || 'none',
    financialCount: financialAccounts.length,
    financialNames: financialAccounts.map(f => f.name).join(', ') || 'none',
    financialTypes: [...new Set(financialAccounts.map(f => f.type))].join(', ') || 'none',
    messageCount: messages.filter(m => m.hasDraft).length,
    messageRecipients: messages.filter(m => m.hasDraft).map(m => m.recipientName).join(', ') || 'nobody',
    hasDocuments: Object.values(documents).some(v => v.checked),
    documentsChecked: Object.entries(documents).filter(([_, v]) => v.checked).map(([id]) => DOC_CHECKLIST.find(d => d.id === id)?.label || id).join(', ') || 'none checked',
    hasRecurringBills: !!recurringBills,
    hasPets: pets.length > 0,
    hasHomeNotes: !!homeNotes,
    hasDeviceNotes: !!deviceNotes,
    hasEmergencyContacts: emergencyContacts.length > 0,
    hasMemorial: !!memorialWishes,
    trustedPerson,
  }), [accounts, financialAccounts, messages, documents, recurringBills, pets, homeNotes, deviceNotes, emergencyContacts, memorialWishes, trustedPerson]);

  // ══════════════════════════════════════════
  // CHAPTER 1: Parse accounts
  // ══════════════════════════════════════════
  const parseAccountDump = useCallback(async () => {
    if (!accountDump.trim()) return;
    const res = await callAI('parse-accounts', { text: accountDump, trustedPerson, existingNames: accounts.map(a => a.name).join(', ') || null });
    if (res?.accounts && Array.isArray(res.accounts)) {
      const newAccounts = res.accounts.map((a, i) => ({ id: `acc_${Date.now()}_${i}`, name: a.name || 'Unknown', category: a.category || 'other', priority: a.priority || 'important', accessNotes: a.accessNotes || '', isSocialMedia: a.isSocialMedia || false, socialWish: 'decide', socialCustom: '', visibleTo: 'all' }));
      setAccounts(prev => [...prev, ...newAccounts]);
      setAccountDump(''); setShowFollowUps(true);
      addToast(`${newAccounts.length} account${newAccounts.length !== 1 ? 's' : ''} added`, 'success');
    }
  }, [accountDump, callAI, trustedPerson, accounts, addToast]);

  const parseFollowUpAnswer = useCallback(async () => {
    if (!followUpAnswer.trim()) { setAccountFollowUpIndex(prev => prev + 1); setFollowUpAnswer(''); return; }
    const res = await callAI('parse-accounts', { text: followUpAnswer, trustedPerson, existingNames: accounts.map(a => a.name).join(', ') });
    if (res?.accounts?.length) {
      const newAccounts = res.accounts.map((a, i) => ({ id: `acc_${Date.now()}_${i}`, name: a.name || 'Unknown', category: a.category || 'other', priority: a.priority || 'important', accessNotes: a.accessNotes || '', isSocialMedia: a.isSocialMedia || false, socialWish: 'decide', socialCustom: '', visibleTo: 'all' }));
      setAccounts(prev => [...prev, ...newAccounts]);
      addToast(`${newAccounts.length} more added`, 'success');
    }
    setAccountFollowUpIndex(prev => prev + 1); setFollowUpAnswer('');
  }, [followUpAnswer, accounts, callAI, trustedPerson, addToast]);

  // ══════════════════════════════════════════
  // CHAPTER 3: Parse financial
  // ══════════════════════════════════════════
  const parseFinancialDump = useCallback(async () => {
    if (!financialDump.trim()) return;
    const res = await callAI('parse-financial', { text: financialDump });
    if (res?.financials?.length) {
      const items = res.financials.map((f, i) => ({ id: `fin_${Date.now()}_${i}`, name: f.name || 'Unknown', type: f.type || 'bank', institution: f.institution || '', notes: f.notes || '', visibleTo: 'all' }));
      setFinancialAccounts(prev => [...prev, ...items]);
      setFinancialDump('');
      addToast(`${items.length} financial item${items.length !== 1 ? 's' : ''} added`, 'success');
    }
  }, [financialDump, callAI, addToast]);

  // ══════════════════════════════════════════
  // CHAPTER 4: Generate / adjust / translate messages
  // ══════════════════════════════════════════
  const generateMessageDraft = useCallback(async (msgIndex) => {
    const msg = messages[msgIndex];
    if (!msg) return;
    const res = await callAI('generate-message', { recipientName: msg.recipientName, relationship: msg.relationship, whatToKnow: msg.whatToKnow, memories: msg.memories, tone: msg.tone, userName, trustedPerson });
    if (res?.message?.draft) {
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, draft: res.message.draft, hasDraft: true } : m));
      setMessageStep(4); addToast('Draft ready', 'success');
    }
  }, [messages, callAI, userName, trustedPerson, addToast]);

  const adjustMessage = useCallback(async (msgIndex, adjustment) => {
    const msg = messages[msgIndex];
    if (!msg?.draft) return;
    const res = await callAI('adjust-message', { draft: msg.draft, adjustment, recipientName: msg.recipientName, relationship: msg.relationship, tone: msg.tone });
    if (res?.message?.draft) {
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, draft: res.message.draft } : m));
      addToast('Message updated', 'success');
    }
  }, [messages, callAI, addToast]);

  // v3: Translate message
  const translateMessage = useCallback(async (msgIndex, targetLang) => {
    const msg = messages[msgIndex];
    if (!msg?.draft) return;
    setTranslatingIdx(msgIndex);
    const langName = LANGUAGES.find(l => l.code === targetLang)?.name || targetLang;
    const res = await callAI('translate-message', { draft: msg.draft, targetLanguage: langName, recipientName: msg.recipientName, relationship: msg.relationship });
    if (res?.translation?.translatedDraft) {
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, translatedDraft: res.translation.translatedDraft, translatedLang: langName } : m));
      addToast(`Translated to ${langName}`, 'success');
    }
    setTranslatingIdx(null);
  }, [messages, callAI, addToast]);

  // ══════════════════════════════════════════
  // v3: AI INTERVIEW MODE
  // ══════════════════════════════════════════
  const askNextQuestion = useCallback(async () => {
    const res = await callAI('interview-question', {
      documentState: buildDocumentState(),
      previousQuestions: interviewHistory.map(h => h.question),
    });
    if (res?.interview) setCurrentInterviewQ(res.interview);
  }, [callAI, buildDocumentState, interviewHistory]);

  const submitInterviewAnswer = useCallback(async () => {
    if (!currentInterviewQ || !interviewAnswer.trim()) return;
    // Add to history
    setInterviewHistory(prev => [...prev, { question: currentInterviewQ.question, answer: interviewAnswer, category: currentInterviewQ.category }]);
    // If the answer mentions accounts, try parsing
    if (currentInterviewQ.category === 'accounts' || currentInterviewQ.category === 'financial') {
      const mode = currentInterviewQ.category === 'financial' ? 'parse-financial' : 'parse-accounts';
      const res = await callAI(mode, { text: interviewAnswer, trustedPerson, existingNames: accounts.map(a => a.name).join(', ') });
      if (mode === 'parse-accounts' && res?.accounts?.length) {
        const newItems = res.accounts.map((a, i) => ({ id: `acc_${Date.now()}_${i}`, name: a.name || 'Unknown', category: a.category || 'other', priority: a.priority || 'important', accessNotes: a.accessNotes || '', isSocialMedia: a.isSocialMedia || false, socialWish: 'decide', socialCustom: '', visibleTo: 'all' }));
        setAccounts(prev => [...prev, ...newItems]);
        addToast(`${newItems.length} account${newItems.length !== 1 ? 's' : ''} added from interview`, 'success');
      }
      if (mode === 'parse-financial' && res?.financials?.length) {
        const newItems = res.financials.map((f, i) => ({ id: `fin_${Date.now()}_${i}`, name: f.name || 'Unknown', type: f.type || 'bank', institution: f.institution || '', notes: f.notes || '', visibleTo: 'all' }));
        setFinancialAccounts(prev => [...prev, ...newItems]);
        addToast(`${newItems.length} financial item${newItems.length !== 1 ? 's' : ''} added`, 'success');
      }
    }
    setInterviewAnswer('');
    setCurrentInterviewQ(null);
    // Auto-ask next question
    setTimeout(() => askNextQuestion(), 500);
  }, [currentInterviewQ, interviewAnswer, callAI, trustedPerson, accounts, addToast, askNextQuestion]);

  // ══════════════════════════════════════════
  // v3: SMART GAPS ANALYSIS
  // ══════════════════════════════════════════
  const runSmartGaps = useCallback(async () => {
    setGapsLoading(true);
    const res = await callAI('smart-gaps', { documentState: buildDocumentState() });
    if (res?.analysis) setSmartGaps(res.analysis);
    setGapsLoading(false);
  }, [callAI, buildDocumentState]);

  // ══════════════════════════════════════════
  // NAVIGATION
  // ══════════════════════════════════════════
  const goToChapter = useCallback((idx) => { setCurrentChapter(idx); setScreen('chapter'); setAiError(''); }, []);
  const nextChapter = useCallback(() => { setChapterComplete(prev => ({ ...prev, [currentChapter]: true })); if (currentChapter < CHAPTERS.length - 1) setCurrentChapter(prev => prev + 1); setAiError(''); }, [currentChapter]);
  const prevChapter = useCallback(() => { if (currentChapter > 0) setCurrentChapter(prev => prev - 1); setAiError(''); }, [currentChapter]);

  // ══════════════════════════════════════════
  // DATA HELPERS
  // ══════════════════════════════════════════
  const updateAccount = useCallback((id, field, value) => { setAccounts(prev => prev.map(a => a.id === id ? { ...a, [field]: value } : a)); }, []);
  const removeAccount = useCallback((id) => { setAccounts(prev => prev.filter(a => a.id !== id)); }, []);
  const addManualAccount = useCallback(() => { setAccounts(prev => [...prev, { id: `acc_${Date.now()}`, name: '', category: 'other', priority: 'important', accessNotes: '', isSocialMedia: false, socialWish: 'decide', socialCustom: '', visibleTo: 'all' }]); }, []);

  const addManualFinancial = useCallback(() => { setFinancialAccounts(prev => [...prev, { id: `fin_${Date.now()}`, name: '', type: 'bank', institution: '', notes: '', visibleTo: 'all' }]); }, []);
  const updateFinancial = useCallback((id, field, value) => { setFinancialAccounts(prev => prev.map(f => f.id === id ? { ...f, [field]: value } : f)); }, []);
  const removeFinancial = useCallback((id) => { setFinancialAccounts(prev => prev.filter(f => f.id !== id)); }, []);

  const startNewMessage = useCallback(() => {
    if (!messageRecipient.trim()) return;
    setMessages(prev => [...prev, { recipientName: messageRecipient.trim(), relationship: '', whatToKnow: '', memories: '', tone: 'warm', draft: '', hasDraft: false, visibleTo: 'all', translatedDraft: '', translatedLang: '' }]);
    setActiveMessageIndex(messages.length); setMessageStep(1); setMessageRecipient(''); setEditingDraft(false);
  }, [messageRecipient, messages.length]);
  const updateMessageField = useCallback((idx, field, value) => { setMessages(prev => prev.map((m, i) => i === idx ? { ...m, [field]: value } : m)); }, []);
  const removeMessage = useCallback((idx) => { setMessages(prev => prev.filter((_, i) => i !== idx)); setActiveMessageIndex(null); setMessageStep(0); }, []);

  const addPet = useCallback(() => { setPets(prev => [...prev, { id: `pet_${Date.now()}`, name: '', type: '', careNotes: '', guardian: '', vetInfo: '' }]); }, []);
  const updatePet = useCallback((id, field, value) => { setPets(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p)); }, []);
  const removePet = useCallback((id) => { setPets(prev => prev.filter(p => p.id !== id)); }, []);

  const addTrustedPerson = useCallback(() => { setTrustedPeople(prev => [...prev, { id: `tp_${Date.now()}`, name: '', role: 'additional' }]); }, []);
  const updateTrustedPerson = useCallback((id, field, value) => { setTrustedPeople(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p)); }, []);
  const removeTrustedPerson = useCallback((id) => { setTrustedPeople(prev => prev.filter(p => p.id !== id || p.role === 'primary')); }, []);

  const addEmergencyContact = useCallback(() => { setEmergencyContacts(prev => [...prev, { id: `ec_${Date.now()}`, name: '', phone: '', relationship: '' }]); }, []);
  const updateEmergencyContact = useCallback((id, field, value) => { setEmergencyContacts(prev => prev.map(e => e.id === id ? { ...e, [field]: value } : e)); }, []);
  const removeEmergencyContact = useCallback((id) => { setEmergencyContacts(prev => prev.filter(e => e.id !== id)); }, []);

  // ── Visibility helpers ──
  const getVisibilityOptions = useCallback(() => {
    const options = [{ value: 'all', label: 'Everyone' }];
    trustedPeople.filter(p => p.name.trim()).forEach(p => { options.push({ value: p.id, label: p.name }); });
    return options;
  }, [trustedPeople]);
  const isVisibleTo = useCallback((item, filterPersonId) => {
    if (filterPersonId === 'all') return true;
    const v = item.visibleTo || 'all';
    return v === 'all' || v === filterPersonId;
  }, []);
  // ══════════════════════════════════════════
  // EXPORT: Generate HTML document
  // ══════════════════════════════════════════
  const generateExportHTML = useCallback((filterPerson = 'all') => {
    const tp = trustedPerson || 'My Trusted Person';
    const filterName = filterPerson === 'all' ? tp : (trustedPeople.find(p => p.id === filterPerson)?.name || tp);
    const un = userName || 'Me';
    const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    const priorityLabel = (p) => p === 'critical' ? '🔴 Critical' : p === 'important' ? '🟡 Important' : '🟢 Nice-to-have';
    const catLabel = (cid) => ACCOUNT_CATEGORIES.find(x => x.id === cid)?.label || cid;
    const finTypeLabel = (t) => ({ bank: 'Bank', investment: 'Investment/Retirement', debt: 'Debt', income: 'Income Source', insurance: 'Insurance' })[t] || t;
    const socialWishLabel = (v) => SOCIAL_MEDIA_OPTIONS.find(o => o.value === v)?.label || v;

    const filteredAccounts = accounts.filter(a => isVisibleTo(a, filterPerson));
    const filteredFinancial = financialAccounts.filter(f => isVisibleTo(f, filterPerson));
    const filteredMessages = messages.filter(m => m.draft && isVisibleTo(m, filterPerson));

    const accountsHTML = filteredAccounts.length > 0 ? `
      <h2>1. Digital Accounts</h2>
      <p class="count">${filteredAccounts.length} accounts documented</p>
      <table>
        <thead><tr><th>Service</th><th>Category</th><th>Priority</th><th>Access Notes</th></tr></thead>
        <tbody>
          ${filteredAccounts.map(a => `<tr>
            <td><strong>${a.name}</strong>${a.isSocialMedia ? `<br><em style="color:#888;font-size:0.85em">Social media wish: ${socialWishLabel(a.socialWish)}${a.socialWish === 'custom' ? ' — ' + a.socialCustom : ''}</em>` : ''}</td>
            <td>${catLabel(a.category)}</td>
            <td>${priorityLabel(a.priority)}</td>
            <td>${a.accessNotes || '—'}</td>
          </tr>`).join('')}
        </tbody>
      </table>` : '';

    const docsChecked = Object.entries(documents).filter(([_, v]) => v.checked);
    const docsHTML = docsChecked.length > 0 || docNotes ? `
      <h2>2. Important Documents & Files</h2>
      ${docsChecked.length > 0 ? `<table>
        <thead><tr><th>Document</th><th>Location</th></tr></thead>
        <tbody>${docsChecked.map(([id, v]) => `<tr><td>${DOC_CHECKLIST.find(d => d.id === id)?.label || id}</td><td>${v.location || '—'}</td></tr>`).join('')}</tbody>
      </table>` : ''}
      ${docNotes ? `<div class="note"><strong>Additional notes:</strong> ${docNotes}</div>` : ''}` : '';

    const finHTML = filteredFinancial.length > 0 || recurringBills ? `
      <h2>3. Financial Overview</h2>
      <p class="disclaimer">Note: This is a high-level map of what exists, not a financial document. No account numbers or balances are included.</p>
      ${filteredFinancial.length > 0 ? `<table>
        <thead><tr><th>Account</th><th>Type</th><th>Institution</th><th>Notes</th></tr></thead>
        <tbody>${filteredFinancial.map(f => `<tr><td>${f.name}</td><td>${finTypeLabel(f.type)}</td><td>${f.institution || '—'}</td><td>${f.notes || '—'}</td></tr>`).join('')}</tbody>
      </table>` : ''}
      ${recurringBills ? `<div class="note"><strong>Recurring bills / auto-pay:</strong> ${recurringBills}</div>` : ''}` : '';

    const msgsHTML = filteredMessages.length > 0 ? `
      <h2>4. Personal Messages</h2>
      ${filteredMessages.map(m => `
        <div class="letter">
          <h3>To: ${m.recipientName}</h3>
          <p class="relationship">${m.relationship}</p>
          <div class="letter-body">${m.draft.replace(/\n/g, '<br>')}</div>
          ${m.translatedDraft ? `<div style="margin-top:16px;padding-top:16px;border-top:1px dashed #e7e5e4"><p style="font-size:0.8em;color:#a8a29e;margin-bottom:8px">Translation (${m.translatedLang})</p><div class="letter-body">${m.translatedDraft.replace(/\n/g, '<br>')}</div></div>` : ''}
        </div>
      `).join('')}` : '';

    const wishesItems = [];
    if (emergencyContacts.length > 0) {
      wishesItems.push(`<h3>Emergency Contacts</h3><table><thead><tr><th>Name</th><th>Phone</th><th>Relationship</th></tr></thead><tbody>${emergencyContacts.map(ec => `<tr><td>${ec.name}</td><td>${ec.phone}</td><td>${ec.relationship}</td></tr>`).join('')}</tbody></table>`);
    }
    if (pets.length > 0) {
      wishesItems.push(`<h3>Pets</h3>` + pets.map(p => `<div class="note"><strong>${p.name || 'Pet'}</strong> (${p.type || 'type not specified'})<br>Guardian: ${p.guardian || '—'}<br>Care notes: ${p.careNotes || '—'}<br>Vet: ${p.vetInfo || '—'}</div>`).join(''));
    }
    if (homeNotes) wishesItems.push(`<h3>Home & Property</h3><div class="note">${homeNotes}</div>`);
    if (deviceNotes) wishesItems.push(`<h3>Devices</h3><div class="note">${deviceNotes}</div>`);
    if (memorialWishes) wishesItems.push(`<h3>Memorial Preferences</h3><div class="note">${memorialWishes}</div>`);
    if (specialRequests) wishesItems.push(`<h3>Special Requests</h3><div class="note">${specialRequests}</div>`);
    const wishesHTML = wishesItems.length > 0 ? `<h2>5. Practical Wishes & Instructions</h2>${wishesItems.join('')}` : '';

    const otherPeople = trustedPeople.filter(p => p.role !== 'primary' && p.name.trim());
    const otherPeopleHTML = otherPeople.length > 0 ? `<p class="meta" style="margin-top:8px">Additional trusted people: ${otherPeople.map(p => p.name).join(', ')}</p>` : '';

    return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FinalWish — Prepared for ${filterName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:ital,wght@0,400;0,600;1,400&family=DM+Sans:wght@400;500;700&display=swap');
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'DM Sans', sans-serif; color: #1c1917; line-height: 1.7; padding: 40px; max-width: 800px; margin: 0 auto; }
  .cover { text-align: center; padding: 80px 20px; page-break-after: always; }
  .cover h1 { font-family: 'Crimson Pro', serif; font-size: 2.8em; font-weight: 600; color: #292524; margin-bottom: 8px; }
  .cover .sub { font-size: 1.1em; color: #78716c; margin-bottom: 40px; }
  .cover .meta { font-size: 0.95em; color: #a8a29e; }
  .intro { background: #fef3c7; border: 1px solid #fde68a; border-radius: 12px; padding: 24px; margin: 30px 0; font-style: italic; color: #92400e; }
  h2 { font-family: 'Crimson Pro', serif; font-size: 1.8em; color: #292524; margin: 40px 0 16px; padding-bottom: 8px; border-bottom: 2px solid #e7e5e4; page-break-before: always; }
  h2:first-of-type { page-break-before: avoid; }
  h3 { font-size: 1.1em; color: #44403c; margin: 20px 0 8px; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 0.9em; }
  th { background: #f5f5f4; text-align: left; padding: 10px 12px; border: 1px solid #e7e5e4; font-weight: 600; }
  td { padding: 10px 12px; border: 1px solid #e7e5e4; vertical-align: top; }
  .count { font-size: 0.85em; color: #78716c; margin-bottom: 12px; }
  .disclaimer { font-size: 0.85em; color: #78716c; font-style: italic; margin-bottom: 12px; }
  .note { background: #fafaf9; border: 1px solid #e7e5e4; border-radius: 8px; padding: 16px; margin: 12px 0; font-size: 0.95em; }
  .letter { background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 28px; margin: 20px 0; page-break-inside: avoid; }
  .letter h3 { font-family: 'Crimson Pro', serif; font-size: 1.4em; color: #92400e; margin: 0 0 4px; }
  .letter .relationship { font-size: 0.85em; color: #a8a29e; margin-bottom: 16px; }
  .letter-body { font-family: 'Crimson Pro', serif; font-size: 1.1em; line-height: 1.8; color: #1c1917; white-space: pre-wrap; }
  .footer { text-align: center; margin-top: 60px; padding-top: 20px; border-top: 1px solid #e7e5e4; font-size: 0.85em; color: #a8a29e; }
  @media print { body { padding: 20px; } .cover { padding: 120px 20px; } h2 { page-break-before: always; } .letter { page-break-inside: avoid; } }
</style></head><body>
  <div class="cover">
    <h1>📜 FinalWish</h1>
    <p class="sub">A Digital Legacy Document</p>
    <p class="meta">Prepared by <strong>${un}</strong> for <strong>${filterName}</strong></p>
    <p class="meta">${date}</p>
    ${otherPeopleHTML}
  </div>
  <div class="intro">Dear ${filterName} — if you're reading this, here's everything I organized to make things easier for you. Start with whichever section is most urgent and take it one step at a time. I tried to be thorough. — ${un}</div>
  ${accountsHTML}${docsHTML}${finHTML}${msgsHTML}${wishesHTML}
  <div class="footer">
    <p>Prepared on ${date} using FinalWish</p>
    <p>This document does not constitute a legal will or binding directive. Consult an attorney for legal estate planning.</p>
    <p style="margin-top:8px">💡 Consider reviewing and updating this document annually or after major life changes.</p>
  </div>
  ${BRANDING_HTML}
</body></html>`;
  }, [accounts, documents, docNotes, financialAccounts, recurringBills, messages, pets, homeNotes, deviceNotes, memorialWishes, specialRequests, trustedPerson, trustedPeople, userName, emergencyContacts, isVisibleTo]);

  // ══════════════════════════════════════════
  // v3 FEATURE 1: ENCRYPTED DOWNLOAD
  // ══════════════════════════════════════════
  const downloadEncryptedDocument = useCallback(async (filterPerson = 'all') => {
    if (!passphrase || passphrase.length < 4) { addToast('Passphrase must be at least 4 characters', 'error'); return; }
    const html = generateExportHTML(filterPerson);
    try {
      const encrypted = await encryptText(html, passphrase);
      const hint = passphraseHint || '';
      // Self-contained HTML with decryption page
      const decryptorHTML = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FinalWish — Protected Document</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background:#1c1917; color:#e7e5e4; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:20px; }
  .box { max-width:420px; width:100%; background:#292524; border-radius:20px; padding:40px; text-align:center; box-shadow:0 25px 50px rgba(0,0,0,0.5); }
  h1 { font-size:1.8em; margin-bottom:8px; }
  .sub { color:#a8a29e; font-size:0.9em; margin-bottom:32px; }
  .hint { background:#44403c; border-radius:8px; padding:12px; margin-bottom:20px; font-size:0.85em; color:#d6d3d1; }
  input { width:100%; padding:14px 16px; border:2px solid #44403c; border-radius:12px; background:#1c1917; color:#e7e5e4; font-size:1em; outline:none; margin-bottom:12px; transition:border-color 0.2s; }
  input:focus { border-color:#f59e0b; }
  button { width:100%; padding:14px; border:none; border-radius:12px; background:#f59e0b; color:#1c1917; font-weight:700; font-size:1em; cursor:pointer; transition:background 0.2s; }
  button:hover { background:#fbbf24; }
  .err { color:#ef4444; font-size:0.85em; margin-top:8px; display:none; }
  .branding { margin-top:24px; font-size:0.75em; color:#78716c; }
</style></head><body>
<div class="box">
  <h1>🔐 FinalWish</h1>
  <p class="sub">This document is passphrase-protected</p>
  ${hint ? `<div class="hint">💡 Hint: ${hint}</div>` : ''}
  <input type="password" id="pw" placeholder="Enter passphrase" onkeydown="if(event.key==='Enter')decrypt()">
  <button onclick="decrypt()">Unlock Document</button>
  <p class="err" id="err">Incorrect passphrase. Please try again.</p>
  <p class="branding">Generated by DeftBrain · deftbrain.com</p>
</div>
<script>
const DATA='${encrypted}';
async function deriveKey(p,s){const e=new TextEncoder();const k=await crypto.subtle.importKey('raw',e.encode(p),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:s,iterations:100000,hash:'SHA-256'},k,{name:'AES-GCM',length:256},false,['decrypt']);}
async function decrypt(){
  const pw=document.getElementById('pw').value;
  if(!pw){document.getElementById('err').style.display='block';return;}
  try{
    const d=Uint8Array.from(atob(DATA),c=>c.charCodeAt(0));
    const s=d.slice(0,16),iv=d.slice(16,28),enc=d.slice(28);
    const k=await deriveKey(pw,s);
    const dec=await crypto.subtle.decrypt({name:'AES-GCM',iv},k,enc);
    const html=new TextDecoder().decode(dec);
    document.open();document.write(html);document.close();
  }catch(e){document.getElementById('err').style.display='block';}
}
</script></body></html>`;

      const blob = new Blob([decryptorHTML], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const filterName = filterPerson === 'all' ? (trustedPerson || 'trusted-person') : (trustedPeople.find(p => p.id === filterPerson)?.name || 'person');
      a.href = url; a.download = `FinalWish-ENCRYPTED-for-${filterName.replace(/[^a-zA-Z0-9]/g, '-')}-${new Date().toISOString().split('T')[0]}.html`;
      document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
      addToast('Encrypted document downloaded — share the passphrase separately!', 'success');
    } catch (e) { addToast('Encryption failed: ' + (e.message || 'unknown error'), 'error'); }
  }, [passphrase, passphraseHint, generateExportHTML, trustedPerson, trustedPeople, addToast]);

  // ── Plain download ──
  const downloadDocument = useCallback((filterPerson = 'all') => {
    const html = generateExportHTML(filterPerson);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const filterName = filterPerson === 'all' ? (trustedPerson || 'trusted-person') : (trustedPeople.find(p => p.id === filterPerson)?.name || 'person');
    a.href = url; a.download = `FinalWish-for-${filterName.replace(/[^a-zA-Z0-9]/g, '-')}-${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
    addToast('Document downloaded', 'success');
  }, [generateExportHTML, trustedPerson, trustedPeople, addToast]);

  const printDocument = useCallback((filterPerson = 'all') => {
    const html = generateExportHTML(filterPerson);
    const w = window.open('', '_blank');
    if (w) { w.document.write(html); w.document.close(); w.onload = () => w.print(); }
  }, [generateExportHTML]);

  // ══════════════════════════════════════════
  // v3 FEATURE 6: QR ACCESS CARD
  // ══════════════════════════════════════════
  const generateQRCard = useCallback(() => {
    const tp = trustedPerson || 'your trusted person';
    const un = userName || 'Me';
    const loc = DELIVERY_LOCATIONS.find(l => l.id === deliveryLocation);
    const locLabel = loc ? `${loc.icon} ${loc.label}` : deliveryLocation || 'Location not specified';
    const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    const contacts = emergencyContacts.length > 0
      ? emergencyContacts.map(ec => `<tr><td>${ec.name}</td><td>${ec.phone}</td><td>${ec.relationship}</td></tr>`).join('')
      : '<tr><td colspan="3" style="color:#a8a29e">No emergency contacts listed</td></tr>';

    const cardHTML = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FinalWish Access Card</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; padding:20px; background:#fafaf9; }
  .card { max-width:400px; margin:0 auto; background:white; border:2px solid #e7e5e4; border-radius:16px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.08); }
  .header { background:#292524; color:white; padding:24px; text-align:center; }
  .header h1 { font-size:1.3em; margin-bottom:4px; }
  .header p { font-size:0.85em; color:#a8a29e; }
  .body { padding:20px; }
  .row { display:flex; align-items:flex-start; gap:12px; margin-bottom:16px; padding-bottom:16px; border-bottom:1px solid #f5f5f4; }
  .row:last-child { border-bottom:none; margin-bottom:0; padding-bottom:0; }
  .icon { font-size:1.3em; flex-shrink:0; width:28px; text-align:center; }
  .label { font-size:0.75em; text-transform:uppercase; letter-spacing:0.05em; color:#a8a29e; font-weight:600; }
  .value { font-size:0.9em; color:#1c1917; margin-top:2px; }
  table { width:100%; border-collapse:collapse; font-size:0.85em; }
  th { text-align:left; padding:6px 8px; background:#f5f5f4; }
  td { padding:6px 8px; border-bottom:1px solid #f5f5f4; }
  .footer { text-align:center; padding:16px; background:#f5f5f4; font-size:0.75em; color:#78716c; }
  ${encryptionEnabled ? `.passphrase { background:#fef3c7; border:1px solid #fde68a; border-radius:8px; padding:12px; margin-top:12px; font-size:0.85em; color:#92400e; }` : ''}
  @media print { body { padding:0; background:white; } .card { border:1px solid #ccc; box-shadow:none; } }
</style></head><body>
<div class="card">
  <div class="header">
    <h1>📜 FinalWish Access Card</h1>
    <p>If you're reading this, please follow these instructions</p>
  </div>
  <div class="body">
    <div class="row">
      <span class="icon">👤</span>
      <div><div class="label">Prepared by</div><div class="value">${un}</div></div>
    </div>
    <div class="row">
      <span class="icon">📅</span>
      <div><div class="label">Last updated</div><div class="value">${date}</div></div>
    </div>
    <div class="row">
      <span class="icon">📍</span>
      <div><div class="label">Full document location</div><div class="value">${locLabel}</div>${deliveryNotes ? `<div class="value" style="font-size:0.85em;color:#78716c;margin-top:4px">${deliveryNotes}</div>` : ''}</div>
    </div>
    ${encryptionEnabled && passphraseHint ? `<div class="passphrase">🔐 The document is passphrase-protected.<br>Hint: ${passphraseHint}</div>` : ''}
    <div class="row" style="margin-top:8px">
      <span class="icon">📞</span>
      <div style="flex:1"><div class="label">Emergency Contacts</div>
        <table style="margin-top:8px">${contacts}</table>
      </div>
    </div>
  </div>
  <div class="footer">Generated by DeftBrain · deftbrain.com</div>
</div>
</body></html>`;

    const w = window.open('', '_blank');
    if (w) { w.document.write(cardHTML); w.document.close(); w.onload = () => w.print(); }
    addToast('Access card ready to print — put it in your wallet or on the fridge', 'success');
  }, [trustedPerson, userName, deliveryLocation, deliveryNotes, emergencyContacts, encryptionEnabled, passphraseHint, addToast]);

  // ══════════════════════════════════════════
  // JSON EXPORT / IMPORT (Annual Review)
  // ══════════════════════════════════════════
  const exportJSON = useCallback(() => {
    const data = { ...buildSaveData(), exportedAt: new Date().toISOString(), version: 3 };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `FinalWish-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
    addToast('Backup exported', 'success');
  }, [buildSaveData, addToast]);

  const importJSON = useCallback((e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        if (!data.accounts && !data.messages && !data.trustedPeople) { addToast('Invalid backup file', 'error'); return; }
        setImportedData(data); setScreen('diff');
        addToast('Previous version loaded — review changes', 'success');
      } catch { addToast('Could not read file', 'error'); }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, [addToast]);

  const importAndReplace = useCallback(() => {
    if (!importedData) return;
    loadSavedData(importedData); setImportedData(null); setScreen('chapter'); setCurrentChapter(0);
    addToast('Data restored from backup', 'success');
  }, [importedData, loadSavedData, addToast]);

  const computeDiff = useMemo(() => {
    if (!importedData) return null;
    const prev = importedData; const curr = buildSaveData();
    const diff = (prevArr, currArr, key = 'name') => {
      const pSet = new Set((prevArr || []).map(x => x[key]));
      const cSet = new Set((currArr || []).map(x => x[key]));
      return { added: [...cSet].filter(n => !pSet.has(n)), removed: [...pSet].filter(n => !cSet.has(n)) };
    };
    const accDiff = diff(prev.accounts, curr.accounts);
    const finDiff = diff(prev.financialAccounts, curr.financialAccounts);
    const msgDiff = diff((prev.messages || []).filter(m => m.hasDraft), (curr.messages || []).filter(m => m.hasDraft), 'recipientName');
    const changes = [];
    if (accDiff.added.length) changes.push({ type: 'added', section: 'Accounts', items: accDiff.added });
    if (accDiff.removed.length) changes.push({ type: 'removed', section: 'Accounts', items: accDiff.removed });
    if (finDiff.added.length) changes.push({ type: 'added', section: 'Financial', items: finDiff.added });
    if (finDiff.removed.length) changes.push({ type: 'removed', section: 'Financial', items: finDiff.removed });
    if (msgDiff.added.length) changes.push({ type: 'added', section: 'Messages', items: msgDiff.added });
    if (msgDiff.removed.length) changes.push({ type: 'removed', section: 'Messages', items: msgDiff.removed });
    const textChanges = [];
    ['recurringBills', 'homeNotes', 'deviceNotes', 'memorialWishes', 'specialRequests'].forEach(k => {
      if ((prev[k] || '') !== (curr[k] || '')) textChanges.push(`${k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase())} updated`);
    });
    return { changes, textChanges, prevDate: prev.lastSaved || prev.exportedAt, hasChanges: changes.length > 0 || textChanges.length > 0 };
  }, [importedData, buildSaveData]);

  // ══════════════════════════════════════════
  // COMPLETENESS
  // ══════════════════════════════════════════
  const getChapterStatus = useCallback((idx) => {
    switch (idx) {
      case 0: return accounts.length > 0 ? 'done' : 'empty';
      case 1: return Object.values(documents).some(v => v.checked) || docNotes ? 'done' : 'empty';
      case 2: return financialAccounts.length > 0 || recurringBills ? 'done' : 'empty';
      case 3: return messages.some(m => m.hasDraft) ? 'done' : 'empty';
      case 4: return pets.length > 0 || homeNotes || deviceNotes || specialRequests ? 'done' : 'empty';
      case 5: return 'empty';
      default: return 'empty';
    }
  }, [accounts, documents, docNotes, financialAccounts, recurringBills, messages, pets, homeNotes, deviceNotes, specialRequests]);

  // ══════════════════════════════════════════
  // RENDER HELPERS
  // ══════════════════════════════════════════
  const renderToasts = () => toasts.length > 0 ? (
    <div className="fixed top-4 right-4 z-50 space-y-2" style={{ maxWidth: '320px' }}>
      {toasts.map(t => (
        <div key={t.id} className={`px-4 py-3 rounded-xl shadow-lg text-sm font-medium ${t.type === 'success' ? (c.d ? 'bg-emerald-800 text-emerald-100' : 'bg-emerald-600 text-white') : t.type === 'error' ? (c.d ? 'bg-red-800 text-red-100' : 'bg-red-600 text-white') : (c.d ? 'bg-zinc-700 text-zinc-100' : 'bg-stone-700 text-white')}`}>
          {t.type === 'success' ? '✅ ' : t.type === 'error' ? '⚠️ ' : ''}{t.msg}
        </div>
      ))}
    </div>
  ) : null;

  const renderProgressBar = () => (
    <div className="mb-8">
      <div className="flex items-center gap-1 mb-3 overflow-x-auto pb-2">
        {CHAPTERS.map((ch, i) => {
          const status = getChapterStatus(i);
          const isCurrent = i === currentChapter;
          return (
            <button key={ch.id} onClick={() => goToChapter(i)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all
                ${isCurrent ? `${c.btn} shadow-md` : status === 'done' ? `${c.successBg} border` : `${c.bgInset} ${c.textMut} ${c.bgHover}`}`}>
              {status === 'done' && !isCurrent && <span>✅</span>}
              <span>{ch.icon}</span>
              <span className="hidden sm:inline">{ch.short}</span>
            </button>
          );
        })}
      </div>
      <div className="flex gap-1">
        {CHAPTERS.map((_, i) => <div key={i} className={`h-1 flex-1 rounded-full transition-all ${i <= currentChapter ? c.progressDone : c.progressPending}`} />)}
      </div>
      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center gap-3">
          <span className={`text-xs ${c.textMut}`}>Auto-saved</span>
          <button onClick={() => { setScreen('interview'); if (!currentInterviewQ) askNextQuestion(); }}
            className={`text-xs font-semibold ${c.accent}`}>🧠 AI Interview</button>
        </div>
        <button onClick={clearAllAndRestart} className={`text-xs ${c.textMut} hover:text-red-500 transition-colors`}>🗑️ Start Over</button>
      </div>
    </div>
  );

  const renderNavButtons = (skipLabel) => (
    <div className="flex items-center justify-between mt-8 pt-6 border-t" style={{ borderColor: c.d ? '#3f3f46' : '#e7e5e4' }}>
      {currentChapter > 0 ? (
        <button onClick={prevChapter} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold ${c.btnSec}`}>← Previous</button>
      ) : <div />}
      <button onClick={nextChapter} className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold ${c.btn}`}>
        {currentChapter === CHAPTERS.length - 2 ? 'Review & Export' : (skipLabel || 'Continue')} →
      </button>
    </div>
  );

  const renderError = () => aiError ? (
    <div className={`mt-4 p-4 ${c.errBg} border rounded-xl flex items-start gap-3`}>
      <span className="flex-shrink-0 mt-0.5">⚠️</span>
      <p className={`text-sm ${c.errText}`}>{aiError}</p>
    </div>
  ) : null;

  const renderLoading = (msg) => (
    <div className="flex items-center gap-3 py-6 justify-center">
      <span className="animate-spin inline-block">⏳</span>
      <span className={`text-sm ${c.textSec} animate-pulse`}>{msg || 'Thinking...'}</span>
    </div>
  );

  const renderVisibilityTag = (item, updateFn, id) => {
    if (allPeopleNames.length < 2) return null;
    return (
      <select value={item.visibleTo || 'all'} onChange={e => updateFn(id, 'visibleTo', e.target.value)}
        className={`px-2 py-0.5 rounded text-xs ${c.input} outline-none`} title="Visible to">
        {getVisibilityOptions().map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    );
  };

  // ══════════════════════════════════════════
  // SCREEN: WELCOME
  // ══════════════════════════════════════════
  const renderWelcome = () => (
    <div className={c.text}>
      {renderToasts()}
      <div className="flex items-center gap-3 mb-6">
        <h2 className={`text-2xl font-bold ${c.text}`}>FinalWish 📜</h2>
      </div>
      <p className={`text-sm ${c.textMut} mb-1`}>Organize what matters. Say what needs to be said.</p>

      {resumePrompt && (
        <div className={`my-4 p-5 rounded-2xl border-2 ${c.d ? 'border-emerald-700 bg-emerald-900/20' : 'border-emerald-300 bg-emerald-50'}`}>
          <p className={`text-sm font-semibold ${c.d ? 'text-emerald-300' : 'text-emerald-800'} mb-3`}>📝 You have an unfinished draft. Pick up where you left off?</p>
          <div className="flex gap-2">
            <button onClick={resumeDraft} className={`px-5 py-2.5 rounded-xl text-sm font-bold ${c.btn}`}>Resume Draft</button>
            <button onClick={clearDraft} className={`px-4 py-2.5 rounded-xl text-sm font-semibold ${c.btnSec}`}>Start Fresh</button>
          </div>
        </div>
      )}

      <div className={`my-6 p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm}`}>
        <p className={`text-sm leading-relaxed ${c.textWarm}`}>
          This isn't about dying — it's about caring. Most of us have a tangle of accounts, photos, subscriptions, and unspoken gratitude that would be nearly impossible for someone else to navigate. FinalWish helps you organize it all into a single document you can hand to someone you trust. Takes about 15–30 minutes. Your progress auto-saves. Documents can be passphrase-encrypted.
        </p>
      </div>

      <div className="space-y-4 mb-6">
        <div>
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>Your Name</label>
          <input type="text" value={userName} onChange={e => setUserName(e.target.value)} placeholder="How you'd sign a letter"
            className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none transition-colors`} />
        </div>
        <div>
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>Primary Trusted Person</label>
          <input type="text" value={primaryPerson?.name || ''} onChange={e => updateTrustedPerson(primaryPerson?.id, 'name', e.target.value)}
            placeholder='e.g. "My partner Alex", "My sister Maria"'
            className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none transition-colors`} />
          <p className={`text-xs ${c.textMut} mt-1.5`}>This name will be woven throughout the document.</p>
        </div>
        {trustedPeople.filter(p => p.role !== 'primary').map(tp => (
          <div key={tp.id} className="flex gap-2">
            <input type="text" value={tp.name} onChange={e => updateTrustedPerson(tp.id, 'name', e.target.value)}
              placeholder="Additional trusted person" className={`flex-1 px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} />
            <button onClick={() => removeTrustedPerson(tp.id)} className={`px-3 rounded-xl ${c.btnSec} text-sm`}>✕</button>
          </div>
        ))}
        <button onClick={addTrustedPerson} className={`flex items-center gap-1.5 text-xs font-semibold ${c.accent}`}>➕ Add another trusted person</button>
        {trustedPeople.length > 1 && <p className={`text-xs ${c.textMut}`}>With multiple people, you control which sections each sees.</p>}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        <button onClick={() => { setScreen('chapter'); setCurrentChapter(0); }} disabled={!trustedPerson.trim()}
          className={`group p-5 rounded-2xl border-2 text-left transition-all ${trustedPerson.trim() ? `${c.border} ${c.bgHover} hover:border-amber-400` : `${c.border} opacity-50 cursor-not-allowed`}`}>
          <div className="flex items-center gap-2 mb-2"><span>📖</span><span className={`text-sm font-bold ${c.text}`}>Guide Me Through It</span></div>
          <p className={`text-xs ${c.textMut}`}>Step-by-step with AI assistance. ~15–30 min.</p>
        </button>
        <button onClick={() => { setScreen('interview'); askNextQuestion(); }} disabled={!trustedPerson.trim()}
          className={`group p-5 rounded-2xl border-2 text-left transition-all ${trustedPerson.trim() ? `${c.border} ${c.bgHover} hover:border-amber-400` : `${c.border} opacity-50 cursor-not-allowed`}`}>
          <div className="flex items-center gap-2 mb-2"><span>🧠</span><span className={`text-sm font-bold ${c.text}`}>AI Interview</span></div>
          <p className={`text-xs ${c.textMut}`}>Answer questions — AI fills everything in. ~20 min.</p>
        </button>
        <button onClick={() => { setScreen('chapter'); setCurrentChapter(0); }} disabled={!trustedPerson.trim()}
          className={`group p-5 rounded-2xl border-2 text-left transition-all ${trustedPerson.trim() ? `${c.border} ${c.bgHover} hover:border-amber-400` : `${c.border} opacity-50 cursor-not-allowed`}`}>
          <div className="flex items-center gap-2 mb-2"><span>✏️</span><span className={`text-sm font-bold ${c.text}`}>I Know What I Need</span></div>
          <p className={`text-xs ${c.textMut}`}>Jump to any section. Fill what you want.</p>
        </button>
        <button onClick={() => setScreen('emergency')} disabled={!trustedPerson.trim()}
          className={`group p-5 rounded-2xl border-2 text-left transition-all ${trustedPerson.trim() ? `border-red-300 ${c.d ? 'border-red-700 hover:border-red-500' : 'hover:border-red-400'}` : `${c.border} opacity-50 cursor-not-allowed`}`}>
          <div className="flex items-center gap-2 mb-2"><span>🚨</span><span className={`text-sm font-bold ${c.text}`}>Emergency — 5 Min</span></div>
          <p className={`text-xs ${c.textMut}`}>Pre-surgery, travel, or time-sensitive.</p>
        </button>
      </div>

      <div className={`mt-4 p-4 rounded-xl border ${c.border} ${c.bgCard}`}>
        <div className="flex items-center justify-between">
          <div><p className={`text-sm font-semibold ${c.text}`}>📅 Annual Review</p><p className={`text-xs ${c.textMut}`}>Import a previous backup to see what's changed</p></div>
          <label className={`px-4 py-2 rounded-xl text-xs font-bold ${c.btnSec} cursor-pointer`}>Import Backup
            <input ref={fileInputRef} type="file" accept=".json" onChange={importJSON} className="hidden" />
          </label>
        </div>
      </div>

      <div className={`mt-4 p-4 rounded-xl ${c.bgInset}`}>
        <p className={`text-xs ${c.textMut} mb-2`}>Related tools:</p>
        <div className="flex flex-wrap gap-2">
          <a href="/GratitudeDebtClearer" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent} ${c.bgHover} px-2 py-1 rounded-lg`}>❤️ Gratitude Debt Clearer</a>
          <a href="/BrainDumpStructurer" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent} ${c.bgHover} px-2 py-1 rounded-lg`}>🧠 Brain Dump Structurer</a>
          <a href="/DecisionCoach" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent} ${c.bgHover} px-2 py-1 rounded-lg`}>🤔 Decision Coach</a>
        </div>
      </div>
      <p className={`text-xs ${c.textMut} mt-6 text-center`}>⚠️ This is not a legal document. Consult an attorney for legal estate planning.</p>
    </div>
  );

  // ══════════════════════════════════════════
  // v3 FEATURE 3: AI INTERVIEW SCREEN
  // ══════════════════════════════════════════
  const renderInterviewScreen = () => (
    <div className={c.text}>
      {renderToasts()}
      <div className="flex items-center justify-between mb-6">
        <h2 className={`text-xl font-bold ${c.text}`}>🧠 AI Legacy Interview</h2>
        <div className="flex gap-2">
          <button onClick={() => { setScreen('chapter'); setCurrentChapter(0); }} className={`text-sm font-semibold ${c.btnGhost}`}>Switch to Manual →</button>
          <button onClick={() => setScreen('welcome')} className={`text-sm font-semibold ${c.btnGhost}`}>← Back</button>
        </div>
      </div>
      <p className={`text-sm ${c.textSec} mb-5`}>I'll ask questions to help you build your document. Just answer naturally — I'll organize everything.</p>

      {/* Interview progress */}
      <div className={`flex items-center gap-3 mb-5 p-3 rounded-xl ${c.bgInset}`}>
        <span className={`text-xs font-bold ${c.textSec}`}>{interviewHistory.length} questions answered</span>
        <span className={`text-xs ${c.textMut}`}>·</span>
        <span className={`text-xs ${c.textMut}`}>{accounts.length} accounts · {financialAccounts.length} financial · {messages.filter(m => m.hasDraft).length} messages</span>
      </div>

      {/* History */}
      {interviewHistory.length > 0 && (
        <div className="space-y-3 mb-5">
          {interviewHistory.slice(-5).map((h, i) => (
            <div key={i} className={`p-4 rounded-xl border ${c.border} ${c.bgCard}`}>
              <p className={`text-xs font-bold ${c.accent} mb-1`}>Q: {h.question}</p>
              <p className={`text-sm ${c.text}`}>{h.answer}</p>
            </div>
          ))}
        </div>
      )}

      {/* Current question */}
      {loading && !currentInterviewQ && renderLoading('Thinking of the next question...')}
      {currentInterviewQ && (
        <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm} mb-5`}>
          <p className={`text-sm font-semibold ${c.textWarm} mb-1`}>{currentInterviewQ.question}</p>
          {currentInterviewQ.reasoning && <p className={`text-xs ${c.textMut} mb-3`}>{currentInterviewQ.reasoning}</p>}
          <textarea value={interviewAnswer} onChange={e => setInterviewAnswer(e.target.value)}
            placeholder="Your answer..." rows={3}
            className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
          <div className="flex gap-2">
            <button onClick={submitInterviewAnswer} disabled={loading || !interviewAnswer.trim()}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold ${interviewAnswer.trim() && !loading ? c.btn : c.btnDis}`}>
              {loading ? <span><span className="animate-spin inline-block">⏳</span> Processing...</span> : 'Answer & Continue'}
            </button>
            <button onClick={() => { setCurrentInterviewQ(null); askNextQuestion(); }}
              className={`px-4 py-2.5 rounded-xl text-sm font-semibold ${c.btnGhost}`}>Skip</button>
          </div>
        </div>
      )}

      {renderError()}

      {!loading && !currentInterviewQ && interviewHistory.length > 0 && (
        <div className="space-y-3">
          <button onClick={askNextQuestion} className={`w-full px-6 py-3 rounded-2xl text-sm font-bold ${c.btn}`}>Ask Another Question</button>
          <button onClick={() => { setScreen('chapter'); setCurrentChapter(5); }}
            className={`w-full px-6 py-3 rounded-2xl text-sm font-semibold ${c.btnSec}`}>Done — Review & Export →</button>
        </div>
      )}
    </div>
  );

  // ══════════════════════════════════════════
  // EMERGENCY SCREEN
  // ══════════════════════════════════════════
  const renderEmergency = () => {
    const tp = trustedPerson || 'your trusted person';
    return (
      <div className={c.text}>
        {renderToasts()}
        <div className="flex items-center justify-between mb-6">
          <h2 className={`text-xl font-bold ${c.text}`}>🚨 Emergency Quick Plan</h2>
          <button onClick={() => setScreen('welcome')} className={`text-sm font-semibold ${c.btnGhost}`}>← Back</button>
        </div>
        <p className={`text-sm ${c.textSec} mb-5`}>Just the essentials for {tp}. Under 5 minutes.</p>

        <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm} mb-5`}>
          <h3 className={`text-sm font-bold ${c.textWarm} mb-2`}>🔑 Top Critical Accounts</h3>
          <textarea value={emergencyDump} onChange={e => setEmergencyDump(e.target.value)}
            placeholder="e.g. Chase bank — 800-935-9935. Gmail john@gmail.com — password manager on phone. Life insurance with MetLife..."
            rows={5} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
          <button onClick={async () => {
            if (!emergencyDump.trim()) return;
            const res = await callAI('parse-accounts', { text: emergencyDump, trustedPerson });
            if (res?.accounts) {
              const newAccounts = res.accounts.map((a, i) => ({ id: `acc_${Date.now()}_${i}`, name: a.name || 'Unknown', category: a.category || 'other', priority: 'critical', accessNotes: a.accessNotes || '', isSocialMedia: false, socialWish: 'decide', socialCustom: '', visibleTo: 'all' }));
              setAccounts(prev => [...prev, ...newAccounts]); setEmergencyDump(''); addToast(`${newAccounts.length} accounts added`, 'success');
            }
          }} disabled={loading || !emergencyDump.trim()}
            className={`px-5 py-2.5 rounded-xl text-sm font-bold ${emergencyDump.trim() && !loading ? c.btn : c.btnDis}`}>
            {loading ? <span><span className="animate-spin inline-block">⏳</span> Processing...</span> : '✨ Extract Accounts'}
          </button>
          {accounts.length > 0 && (
            <div className="mt-3 space-y-1">
              {accounts.map(a => (
                <div key={a.id} className={`flex items-center justify-between px-3 py-2 rounded-lg ${c.bgCard} border ${c.border}`}>
                  <span className={`text-sm ${c.text}`}>{a.name}</span><span className={`text-xs ${c.textMut}`}>{a.accessNotes}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className={`p-5 rounded-2xl border ${c.border} ${c.bgCard} mb-5`}>
          <div className="flex items-center justify-between mb-3"><h3 className={`text-sm font-bold ${c.text}`}>📞 Emergency Contacts</h3>
            <button onClick={addEmergencyContact} className={`text-xs font-semibold ${c.accent}`}>➕ Add</button></div>
          {emergencyContacts.length === 0 && <p className={`text-xs ${c.textMut}`}>Add key contacts.</p>}
          {emergencyContacts.map(ec => (
            <div key={ec.id} className="flex gap-2 mb-2">
              <input type="text" value={ec.name} onChange={e => updateEmergencyContact(ec.id, 'name', e.target.value)} placeholder="Name" className={`flex-1 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
              <input type="text" value={ec.phone} onChange={e => updateEmergencyContact(ec.id, 'phone', e.target.value)} placeholder="Phone" className={`flex-1 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
              <button onClick={() => removeEmergencyContact(ec.id)} className={`px-2 ${c.textMut} hover:text-red-500`}>✕</button>
            </div>
          ))}
        </div>

        <div className={`p-5 rounded-2xl border ${c.border} ${c.bgCard} mb-5`}>
          <h3 className={`text-sm font-bold ${c.text} mb-2`}>💌 Quick Message for {tp}</h3>
          <textarea value={emergencyMessage} onChange={e => setEmergencyMessage(e.target.value)}
            placeholder={`Dear ${tp}, if something happens...`} rows={4}
            className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`}
            style={{ fontFamily: "'Georgia', serif", lineHeight: '1.8' }} />
        </div>

        {renderError()}

        <div className="space-y-3">
          <button onClick={() => {
            if (emergencyMessage.trim() && !messages.some(m => m.recipientName === tp)) {
              setMessages(prev => [...prev, { recipientName: tp, relationship: 'primary trusted person', whatToKnow: '', memories: '', tone: 'warm', draft: emergencyMessage, hasDraft: true, visibleTo: 'all', translatedDraft: '', translatedLang: '' }]);
            }
            downloadDocument('all');
          }} className={`w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold ${c.btn} shadow-lg`}>
            📥 Download Emergency Document
          </button>
          <button onClick={() => { setScreen('chapter'); setCurrentChapter(0); }}
            className={`w-full flex items-center justify-center gap-3 px-6 py-3 rounded-2xl text-sm font-semibold ${c.btnSec}`}>Switch to Full Version →</button>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER 1: ACCOUNTS
  // ══════════════════════════════════════════
  const renderChapterAccounts = () => {
    const tp = trustedPerson || 'your trusted person';
    return (
      <div>
        <h3 className={`text-lg font-bold ${c.text} mb-1`}>🔑 Digital Accounts & Access</h3>
        <p className={`text-sm ${c.textSec} mb-5`}>What accounts would {tp} need to know about?</p>
        {accounts.length === 0 && !showFollowUps && (
          <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm} mb-5`}>
            <p className={`text-sm ${c.textWarm} mb-3`}>What are the 3–5 accounts {tp} would need first?</p>
            <textarea value={accountDump} onChange={e => setAccountDump(e.target.value)}
              placeholder="e.g. My Gmail (john@gmail.com), Chase bank, Netflix, Instagram — password is in phone notes..."
              rows={4} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
            <button onClick={parseAccountDump} disabled={loading || !accountDump.trim()}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold ${accountDump.trim() && !loading ? c.btn : c.btnDis}`}>
              {loading ? <span><span className="animate-spin inline-block">⏳</span> Extracting...</span> : '✨ Extract Accounts'}
            </button>
          </div>
        )}
        {loading && accounts.length === 0 && renderLoading('Extracting your accounts...')}
        {accounts.length > 0 && (
          <div className="mb-5">
            <div className="flex items-center justify-between mb-3">
              <span className={`text-xs font-bold ${c.textSec} uppercase`}>{accounts.length} accounts</span>
              <button onClick={addManualAccount} className={`flex items-center gap-1.5 text-xs font-semibold ${c.accent}`}>➕ Add manually</button>
            </div>
            <div className="space-y-3">
              {accounts.map(acc => (
                <div key={acc.id} className={`p-4 rounded-xl border ${c.border} ${c.bgCard}`}>
                  <div className="flex items-start gap-3">
                    <div className="flex-1 space-y-2">
                      <input type="text" value={acc.name} onChange={e => updateAccount(acc.id, 'name', e.target.value)} placeholder="Service name" className={`w-full px-3 py-1.5 rounded-lg border text-sm font-semibold ${c.input} outline-none`} />
                      <div className="flex flex-wrap gap-2">
                        <select value={acc.category} onChange={e => updateAccount(acc.id, 'category', e.target.value)} className={`px-2 py-1 rounded-lg border text-xs ${c.input} outline-none`}>
                          {ACCOUNT_CATEGORIES.map(cat => <option key={cat.id} value={cat.id}>{cat.icon} {cat.label}</option>)}
                        </select>
                        <select value={acc.priority} onChange={e => updateAccount(acc.id, 'priority', e.target.value)} className={`px-2 py-1 rounded-lg border text-xs ${c.input} outline-none`}>
                          <option value="critical">🔴 Critical</option><option value="important">🟡 Important</option><option value="nice-to-have">🟢 Nice-to-have</option>
                        </select>
                        {renderVisibilityTag(acc, updateAccount, acc.id)}
                      </div>
                      <input type="text" value={acc.accessNotes} onChange={e => updateAccount(acc.id, 'accessNotes', e.target.value)} placeholder="Access notes (NOT actual passwords)" className={`w-full px-3 py-1.5 rounded-lg border text-xs ${c.input} outline-none`} />
                      {acc.isSocialMedia && (
                        <div className="flex flex-wrap gap-2 mt-1">
                          {SOCIAL_MEDIA_OPTIONS.map(opt => (
                            <button key={opt.value} onClick={() => updateAccount(acc.id, 'socialWish', opt.value)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${acc.socialWish === opt.value ? (c.d ? 'border-amber-500 bg-amber-900/30 text-amber-300' : 'border-amber-400 bg-amber-50 text-amber-700') : `${c.border} ${c.textMut}`}`}>
                              {opt.label}
                            </button>
                          ))}
                          {acc.socialWish === 'custom' && <input type="text" value={acc.socialCustom || ''} onChange={e => updateAccount(acc.id, 'socialCustom', e.target.value)} placeholder="Custom instructions..." className={`flex-1 min-w-[150px] px-2.5 py-1 rounded-lg border text-xs ${c.input} outline-none`} />}
                        </div>
                      )}
                    </div>
                    <button onClick={() => removeAccount(acc.id)} className={`p-1.5 rounded-lg ${c.bgHover} ${c.textMut} hover:text-red-500`}>✕</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {showFollowUps && accountFollowUpIndex < FOLLOW_UP_PROMPTS.length && !loading && (
          <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm} mb-5`}>
            <p className={`text-sm font-semibold ${c.textWarm} mb-3`}>{FOLLOW_UP_PROMPTS[accountFollowUpIndex]}</p>
            <textarea value={followUpAnswer} onChange={e => setFollowUpAnswer(e.target.value)} placeholder="Type here, or leave blank to skip..." rows={2} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
            <div className="flex gap-2">
              <button onClick={parseFollowUpAnswer} className={`px-4 py-2 rounded-xl text-sm font-bold ${c.btn}`}>{followUpAnswer.trim() ? 'Add & Continue' : 'Skip'}</button>
              <button onClick={() => setShowFollowUps(false)} className={`px-4 py-2 rounded-xl text-sm font-semibold ${c.btnGhost}`}>Done with accounts</button>
            </div>
          </div>
        )}
        {loading && accounts.length > 0 && renderLoading('Processing...')}
        {showFollowUps && accountFollowUpIndex >= FOLLOW_UP_PROMPTS.length && (
          <div className={`p-4 rounded-xl ${c.successBg} border mb-5`}><p className="text-sm font-semibold flex items-center gap-2">✅ All follow-up questions covered!</p></div>
        )}
        {renderError()}
        {renderNavButtons(accounts.length === 0 ? 'Skip for now' : undefined)}
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER 2: DOCUMENTS
  // ══════════════════════════════════════════
  const renderChapterDocuments = () => {
    const tp = trustedPerson || 'your trusted person';
    return (
      <div>
        <h3 className={`text-lg font-bold ${c.text} mb-1`}>📄 Important Documents & Files</h3>
        <p className={`text-sm ${c.textSec} mb-5`}>Where would {tp} find the things that matter?</p>
        <div className="space-y-3 mb-6">
          {DOC_CHECKLIST.map(doc => {
            const checked = documents[doc.id]?.checked || false;
            const location = documents[doc.id]?.location || '';
            return (
              <div key={doc.id} className={`p-4 rounded-xl border transition-all ${checked ? (c.d ? 'border-amber-700/40 bg-amber-900/10' : 'border-amber-200 bg-amber-50/50') : c.border}`}>
                <div className="flex items-start gap-3">
                  <button onClick={() => setDocuments(prev => ({ ...prev, [doc.id]: { ...prev[doc.id], checked: !checked } }))}
                    className={`flex-shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center mt-0.5 transition-all ${checked ? 'bg-amber-500 border-amber-500 text-white' : c.border}`}>
                    {checked && <span className="text-xs">✓</span>}
                  </button>
                  <div className="flex-1">
                    <span className={`text-sm font-medium ${checked ? c.text : c.textSec}`}>{doc.icon} {doc.label}</span>
                    {checked && <input type="text" value={location} onChange={e => setDocuments(prev => ({ ...prev, [doc.id]: { ...prev[doc.id], location: e.target.value } }))} placeholder="Where is it?" className={`w-full mt-2 px-3 py-2 rounded-lg border text-xs ${c.input} outline-none`} />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div>
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>Anything else {tp} would need to find?</label>
          <textarea value={docNotes} onChange={e => setDocNotes(e.target.value)} placeholder="Keys, safe combinations, storage units..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} />
        </div>
        {renderNavButtons()}
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER 3: FINANCIAL
  // ══════════════════════════════════════════
  const renderChapterFinancial = () => {
    const tp = trustedPerson || 'your trusted person';
    return (
      <div>
        <h3 className={`text-lg font-bold ${c.text} mb-1`}>💰 Financial Snapshot</h3>
        <p className={`text-sm ${c.textSec} mb-2`}>A high-level map — not dollar amounts, just what exists and where.</p>
        <p className={`text-xs ${c.textMut} mb-5`}>Just enough for {tp} to know what accounts exist.</p>
        {financialAccounts.length === 0 && (
          <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm} mb-5`}>
            <p className={`text-sm ${c.textWarm} mb-3`}>Describe your financial accounts in any format.</p>
            <textarea value={financialDump} onChange={e => setFinancialDump(e.target.value)} placeholder="e.g. Chase checking, Fidelity 401k, mortgage with Wells Fargo, State Farm auto insurance..." rows={4} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
            <button onClick={parseFinancialDump} disabled={loading || !financialDump.trim()}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold ${financialDump.trim() && !loading ? c.btn : c.btnDis}`}>
              {loading ? <span><span className="animate-spin inline-block">⏳</span> Organizing...</span> : '✨ Extract Accounts'}
            </button>
          </div>
        )}
        {loading && financialAccounts.length === 0 && renderLoading('Organizing...')}
        {financialAccounts.length > 0 && (
          <div className="mb-5">
            <div className="flex items-center justify-between mb-3">
              <span className={`text-xs font-bold ${c.textSec} uppercase`}>{financialAccounts.length} items</span>
              <button onClick={addManualFinancial} className={`flex items-center gap-1.5 text-xs font-semibold ${c.accent}`}>➕ Add manually</button>
            </div>
            <div className="space-y-3">
              {financialAccounts.map(fin => (
                <div key={fin.id} className={`p-4 rounded-xl border ${c.border} ${c.bgCard}`}>
                  <div className="flex items-start gap-3">
                    <div className="flex-1 space-y-2">
                      <input type="text" value={fin.name} onChange={e => updateFinancial(fin.id, 'name', e.target.value)} placeholder="Account name" className={`w-full px-3 py-1.5 rounded-lg border text-sm font-semibold ${c.input} outline-none`} />
                      <div className="flex flex-wrap gap-2">
                        <select value={fin.type} onChange={e => updateFinancial(fin.id, 'type', e.target.value)} className={`px-2 py-1 rounded-lg border text-xs ${c.input} outline-none`}>
                          <option value="bank">Bank Account</option><option value="investment">Investment / Retirement</option><option value="debt">Debt / Loan</option><option value="income">Income Source</option><option value="insurance">Insurance</option>
                        </select>
                        <input type="text" value={fin.institution} onChange={e => updateFinancial(fin.id, 'institution', e.target.value)} placeholder="Institution" className={`flex-1 min-w-[120px] px-2 py-1 rounded-lg border text-xs ${c.input} outline-none`} />
                        {renderVisibilityTag(fin, updateFinancial, fin.id)}
                      </div>
                      <input type="text" value={fin.notes} onChange={e => updateFinancial(fin.id, 'notes', e.target.value)} placeholder="Notes (how to access)" className={`w-full px-3 py-1.5 rounded-lg border text-xs ${c.input} outline-none`} />
                    </div>
                    <button onClick={() => removeFinancial(fin.id)} className={`p-1.5 rounded-lg ${c.bgHover} ${c.textMut} hover:text-red-500`}>✕</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="mt-4">
          <label className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2 block`}>Recurring Bills / Auto-Pay</label>
          <textarea value={recurringBills} onChange={e => setRecurringBills(e.target.value)} placeholder="Auto-pay items that would need cancellation or transfer..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} />
        </div>
        {renderError()}
        {renderNavButtons(financialAccounts.length === 0 ? 'Skip for now' : undefined)}
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER 4: MESSAGES (with translate)
  // ══════════════════════════════════════════
  const renderChapterMessages = () => {
    const tp = trustedPerson || 'your trusted person';

    const buildMessageText = (msg) => `To: ${msg.recipientName}\n${msg.relationship ? `(${msg.relationship})\n` : ''}\n${msg.draft}${msg.translatedDraft ? `\n\n--- ${msg.translatedLang} ---\n${msg.translatedDraft}` : ''}${BRANDING}`;
    const buildMessageHTML = (msg) => `<div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px;">
        <h2 style="color:#92400e;">To: ${msg.recipientName}</h2>
        ${msg.relationship ? `<p style="color:#a8a29e;font-size:0.9em;">${msg.relationship}</p>` : ''}
        <div style="line-height:1.8;white-space:pre-wrap;margin-top:20px;">${msg.draft.replace(/\n/g, '<br>')}</div>
        ${msg.translatedDraft ? `<hr style="border:none;border-top:1px dashed #e7e5e4;margin:24px 0"><p style="color:#a8a29e;font-size:0.85em">${msg.translatedLang}</p><div style="line-height:1.8;white-space:pre-wrap;">${msg.translatedDraft.replace(/\n/g, '<br>')}</div>` : ''}
        ${BRANDING_HTML}</div>`;

    const renderMessageList = () => (
      <div>
        <p className={`text-sm ${c.textSec} mb-5`}>Who would you want to receive a personal message from you?</p>
        {messages.length > 0 && (
          <div className="space-y-3 mb-5">
            {messages.map((msg, i) => (
              <button key={i} onClick={() => { setActiveMessageIndex(i); setMessageStep(msg.hasDraft ? 4 : 1); setEditingDraft(false); }}
                className={`w-full p-4 rounded-xl border-2 text-left transition-all ${c.envelopeBg} ${c.bgHover}`}>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{msg.hasDraft ? '✉️' : '📝'}</span>
                  <div className="flex-1"><span className={`text-sm font-bold ${c.text}`}>{msg.recipientName}</span>
                    {msg.relationship && <span className={`block text-xs ${c.textMut}`}>{msg.relationship}</span>}
                    {msg.translatedLang && <span className={`block text-xs ${c.accent}`}>🌍 {msg.translatedLang}</span>}
                  </div>
                  {msg.hasDraft && <span className="text-emerald-500">✅</span>}
                  <span className={c.textMut}>→</span>
                </div>
              </button>
            ))}
          </div>
        )}
        <div className={`p-4 rounded-xl border-2 border-dashed ${c.border}`}>
          <div className="flex gap-2">
            <input type="text" value={messageRecipient} onChange={e => setMessageRecipient(e.target.value)} placeholder="Recipient's name" onKeyDown={e => e.key === 'Enter' && startNewMessage()}
              className={`flex-1 px-3 py-2 rounded-lg border text-sm ${c.input} outline-none`} />
            <button onClick={startNewMessage} disabled={!messageRecipient.trim()} className={`px-4 py-2 rounded-lg text-sm font-bold ${messageRecipient.trim() ? c.btn : c.btnDis}`}>➕</button>
          </div>
        </div>
        {messages.length > 0 && (
          <div className={`mt-4 p-3 rounded-lg ${c.bgInset}`}>
            <p className={`text-xs ${c.textMut}`}>Need help expressing something? <a href="/GratitudeDebtClearer" target="_blank" rel="noopener" className={`font-semibold ${c.accent}`}>Gratitude Debt Clearer</a> can help.</p>
          </div>
        )}
      </div>
    );

    const renderMessageInterview = () => {
      const idx = activeMessageIndex;
      const msg = messages[idx];
      if (!msg) return null;

      if (messageStep === 1) return (
        <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm}`}>
          <p className={`text-sm font-semibold ${c.textWarm} mb-3`}>What's your relationship with {msg.recipientName}?</p>
          <input type="text" value={msg.relationship} onChange={e => updateMessageField(idx, 'relationship', e.target.value)} placeholder='"my daughter", "best friend since college"' className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
          <button onClick={() => setMessageStep(2)} disabled={!msg.relationship.trim()} className={`px-5 py-2.5 rounded-xl text-sm font-bold ${msg.relationship.trim() ? c.btn : c.btnDis}`}>Continue →</button>
        </div>
      );

      if (messageStep === 2) return (
        <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm}`}>
          <p className={`text-sm font-semibold ${c.textWarm} mb-3`}>What would you most want {msg.recipientName} to know?</p>
          <textarea value={msg.whatToKnow} onChange={e => updateMessageField(idx, 'whatToKnow', e.target.value)} placeholder="Just say what comes to mind..." rows={4} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-3`} />
          <button onClick={() => setMessageStep(3)} disabled={!msg.whatToKnow.trim()} className={`px-5 py-2.5 rounded-xl text-sm font-bold ${msg.whatToKnow.trim() ? c.btn : c.btnDis}`}>Continue →</button>
        </div>
      );

      if (messageStep === 3) return (
        <div className={`p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm}`}>
          <p className={`text-sm font-semibold ${c.textWarm} mb-3`}>Shared memories, advice, inside jokes? <span className={`font-normal ${c.textMut}`}>(optional)</span></p>
          <textarea value={msg.memories} onChange={e => updateMessageField(idx, 'memories', e.target.value)} placeholder="e.g. that road trip, how they make everyone laugh..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none mb-4`} />
          <p className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2`}>Tone</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {['warm', 'funny', 'heartfelt', 'direct', 'pep talk'].map(t => (
              <button key={t} onClick={() => updateMessageField(idx, 'tone', t)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all capitalize ${msg.tone === t ? (c.d ? 'border-amber-500 bg-amber-900/30 text-amber-300' : 'border-amber-400 bg-amber-50 text-amber-700') : `${c.border} ${c.textMut}`}`}>{t}</button>
            ))}
          </div>
          {allPeopleNames.length > 1 && (
            <div className="mb-4">
              <p className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2`}>Visible To</p>
              <select value={msg.visibleTo || 'all'} onChange={e => updateMessageField(idx, 'visibleTo', e.target.value)} className={`px-3 py-1.5 rounded-lg border text-xs ${c.input} outline-none`}>
                {getVisibilityOptions().map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={() => generateMessageDraft(idx)} disabled={loading} className={`px-5 py-2.5 rounded-xl text-sm font-bold ${!loading ? c.btn : c.btnDis}`}>
              {loading ? <span><span className="animate-spin inline-block">⏳</span> Drafting...</span> : '✨ Draft My Message'}
            </button>
            <button onClick={() => { updateMessageField(idx, 'draft', ''); updateMessageField(idx, 'hasDraft', true); setMessageStep(4); setEditingDraft(true); }} className={`px-4 py-2.5 rounded-xl text-sm font-semibold ${c.btnGhost}`}>I'll write it myself</button>
          </div>
        </div>
      );

      if (messageStep === 4 && msg.hasDraft) return (
        <div>
          <div className={`p-6 rounded-2xl border-2 ${c.letterBg} mb-4`}>
            <div className="flex items-center justify-between mb-4">
              <div><h4 className={`text-lg font-bold ${c.text}`} style={{ fontFamily: "'Georgia',serif" }}>To: {msg.recipientName}</h4><p className={`text-xs ${c.textMut}`}>{msg.relationship}</p></div>
              <button onClick={() => setEditingDraft(!editingDraft)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>✏️ {editingDraft ? 'Preview' : 'Edit'}</button>
            </div>
            {editingDraft ? (
              <textarea value={msg.draft} onChange={e => updateMessageField(idx, 'draft', e.target.value)} rows={8} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} style={{ fontFamily: "'Georgia',serif", lineHeight: '1.8' }} />
            ) : (
              <div className={`text-sm leading-relaxed ${c.letterText} whitespace-pre-wrap`} style={{ fontFamily: "'Georgia',serif", lineHeight: '1.8' }}>{msg.draft}</div>
            )}
            {/* Translated version */}
            {msg.translatedDraft && !editingDraft && (
              <div className="mt-4 pt-4" style={{ borderTop: '1px dashed #e7e5e4' }}>
                <p className={`text-xs ${c.textMut} mb-2`}>🌍 {msg.translatedLang}</p>
                <div className={`text-sm leading-relaxed ${c.letterText} whitespace-pre-wrap`} style={{ fontFamily: "'Georgia',serif", lineHeight: '1.8' }}>{msg.translatedDraft}</div>
              </div>
            )}
          </div>
          {!editingDraft && msg.draft && (
            <div className="flex flex-wrap gap-2 mb-4">
              <CopyBtn content={buildMessageText(msg)} label="Copy Message" />
              <PrintBtn content={buildMessageHTML(msg)} title={`Letter to ${msg.recipientName}`} label="Print Message" />
              <button onClick={() => adjustMessage(idx, 'Make it shorter')} disabled={loading} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>Shorter</button>
              <button onClick={() => adjustMessage(idx, 'Make it longer with more warmth')} disabled={loading} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>Longer</button>
              <button onClick={() => adjustMessage(idx, 'Less formal, more casual')} disabled={loading} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>Less formal</button>
              <button onClick={() => adjustMessage(idx, 'More heartfelt')} disabled={loading} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>More heartfelt</button>
              <button onClick={() => generateMessageDraft(idx)} disabled={loading} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${c.btnSec}`}>🔄 New approach</button>
            </div>
          )}
          {/* v3: TRANSLATE */}
          {!editingDraft && msg.draft && (
            <div className={`flex items-center gap-2 mb-4 p-3 rounded-xl ${c.bgInset}`}>
              <span className="text-xs">🌍</span>
              <select onChange={e => { if (e.target.value) translateMessage(idx, e.target.value); e.target.value = ''; }}
                defaultValue="" disabled={translatingIdx === idx}
                className={`flex-1 px-2 py-1 rounded-lg border text-xs ${c.input} outline-none`}>
                <option value="">Translate to...</option>
                {LANGUAGES.filter(l => l.code !== 'en').map(l => <option key={l.code} value={l.code}>{l.name}</option>)}
              </select>
              {translatingIdx === idx && <span className="animate-spin inline-block text-xs">⏳</span>}
            </div>
          )}
          {loading && renderLoading('Adjusting...')}
          <button onClick={() => removeMessage(idx)} className="flex items-center gap-1.5 text-xs font-semibold text-red-500 hover:text-red-400 mt-2">🗑️ Delete</button>
        </div>
      );
      return null;
    };

    return (
      <div>
        <h3 className={`text-lg font-bold ${c.text} mb-1`}>💌 Messages That Matter</h3>
        {activeMessageIndex !== null ? (
          <div>
            <button onClick={() => { setActiveMessageIndex(null); setMessageStep(0); }} className={`flex items-center gap-2 mb-5 text-sm font-semibold ${c.btnGhost}`}>← Back to messages</button>
            {renderMessageInterview()}
            {renderError()}
          </div>
        ) : (
          <div>{renderMessageList()}{renderNavButtons(messages.length === 0 ? 'Skip for now' : undefined)}</div>
        )}
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER 5: WISHES
  // ══════════════════════════════════════════
  const renderChapterWishes = () => (
    <div>
      <h3 className={`text-lg font-bold ${c.text} mb-1`}>🏠 Practical Wishes & Instructions</h3>
      <p className={`text-sm ${c.textSec} mb-5`}>Anything else that would help.</p>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-3"><span className={`text-sm font-bold ${c.text} flex items-center gap-2`}>📞 Emergency Contacts</span>
          <button onClick={addEmergencyContact} className={`flex items-center gap-1.5 text-xs font-semibold ${c.accent}`}>➕ Add</button></div>
        {emergencyContacts.length === 0 && <p className={`text-xs ${c.textMut} mb-3`}>Key people to call — family, lawyer, financial advisor.</p>}
        {emergencyContacts.map(ec => (
          <div key={ec.id} className="flex gap-2 mb-2">
            <input type="text" value={ec.name} onChange={e => updateEmergencyContact(ec.id, 'name', e.target.value)} placeholder="Name" className={`flex-1 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
            <input type="text" value={ec.phone} onChange={e => updateEmergencyContact(ec.id, 'phone', e.target.value)} placeholder="Phone" className={`flex-1 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
            <input type="text" value={ec.relationship} onChange={e => updateEmergencyContact(ec.id, 'relationship', e.target.value)} placeholder="Role" className={`w-24 sm:w-32 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
            <button onClick={() => removeEmergencyContact(ec.id)} className={`px-2 ${c.textMut} hover:text-red-500`}>✕</button>
          </div>
        ))}
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-3"><span className={`text-sm font-bold ${c.text}`}>🐾 Pets</span>
          <button onClick={addPet} className={`flex items-center gap-1.5 text-xs font-semibold ${c.accent}`}>➕ Add pet</button></div>
        {pets.length === 0 && <p className={`text-xs ${c.textMut} mb-3`}>No pets added.</p>}
        {pets.map(pet => (
          <div key={pet.id} className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-3`}>
            <div className="flex items-start gap-3">
              <div className="flex-1 grid grid-cols-2 gap-2">
                <input type="text" value={pet.name} onChange={e => updatePet(pet.id, 'name', e.target.value)} placeholder="Pet name" className={`px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
                <input type="text" value={pet.type} onChange={e => updatePet(pet.id, 'type', e.target.value)} placeholder="Type" className={`px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
                <input type="text" value={pet.guardian} onChange={e => updatePet(pet.id, 'guardian', e.target.value)} placeholder="Who should take them?" className={`col-span-2 px-3 py-1.5 rounded-lg border text-sm ${c.input} outline-none`} />
                <input type="text" value={pet.careNotes} onChange={e => updatePet(pet.id, 'careNotes', e.target.value)} placeholder="Care notes" className={`col-span-2 px-3 py-1.5 rounded-lg border text-xs ${c.input} outline-none`} />
                <input type="text" value={pet.vetInfo} onChange={e => updatePet(pet.id, 'vetInfo', e.target.value)} placeholder="Vet info" className={`col-span-2 px-3 py-1.5 rounded-lg border text-xs ${c.input} outline-none`} />
              </div>
              <button onClick={() => removePet(pet.id)} className={`p-1.5 rounded-lg ${c.bgHover} ${c.textMut} hover:text-red-500`}>✕</button>
            </div>
          </div>
        ))}
      </div>

      <div className="mb-6"><label className={`text-sm font-bold ${c.text} mb-2 block`}>🏠 Home & Property</label>
        <textarea value={homeNotes} onChange={e => setHomeNotes(e.target.value)} placeholder="Keys, security codes, storage units..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} /></div>
      <div className="mb-6"><label className={`text-sm font-bold ${c.text} mb-2 block`}>📱 Devices</label>
        <textarea value={deviceNotes} onChange={e => setDeviceNotes(e.target.value)} placeholder="Phone unlock, laptop password, what to do with hardware..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} /></div>
      <div className="mb-6">
        <button onClick={() => setShowMemorial(!showMemorial)} className={`flex items-center gap-2 text-sm font-semibold ${c.textSec} ${c.bgHover} px-3 py-2 rounded-lg`}>
          {showMemorial ? '▲' : '▼'} 🎵 Memorial Preferences <span className={`text-xs ${c.textMut}`}>(optional)</span>
        </button>
        {showMemorial && <textarea value={memorialWishes} onChange={e => setMemorialWishes(e.target.value)} placeholder="Songs, readings, vibes? Or 'no strong preferences'" rows={3} className={`w-full mt-3 px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} />}
      </div>
      <div className="mb-4"><label className={`text-sm font-bold ${c.text} mb-2 block`}>⭐ Special Requests</label>
        <p className={`text-xs ${c.textMut} mb-2`}>"Donate my books," "delete my browser history without looking," etc.</p>
        <textarea value={specialRequests} onChange={e => setSpecialRequests(e.target.value)} placeholder="Whatever matters..." rows={3} className={`w-full px-4 py-3 rounded-xl border text-sm ${c.input} outline-none`} /></div>
      {renderNavButtons()}
    </div>
  );

  // ══════════════════════════════════════════
  // CHAPTER 6: REVIEW & EXPORT
  // ══════════════════════════════════════════
  const renderChapterReview = () => {
    const tp = trustedPerson || 'your trusted person';
    const sections = [
      { label: 'Digital Accounts', count: accounts.length, unit: 'accounts', chapter: 0 },
      { label: 'Documents & Files', count: Object.values(documents).filter(v => v.checked).length, unit: 'items', chapter: 1 },
      { label: 'Financial', count: financialAccounts.length, unit: 'accounts', chapter: 2 },
      { label: 'Personal Messages', count: messages.filter(m => m.hasDraft).length, unit: 'messages', chapter: 3 },
      { label: 'Practical Wishes', count: (emergencyContacts.length > 0 ? 1 : 0) + (pets.length > 0 ? 1 : 0) + (homeNotes ? 1 : 0) + (deviceNotes ? 1 : 0) + (specialRequests ? 1 : 0), unit: 'sections', chapter: 4 },
    ];
    const totalFilled = sections.filter(s => s.count > 0).length;

    const buildFullDocText = () => {
      let text = `FINALWISH — Digital Legacy Document\nPrepared by ${userName || 'Me'} for ${tp}\n${new Date().toLocaleDateString()}\n\n`;
      if (accounts.length) { text += '═══ DIGITAL ACCOUNTS ═══\n'; accounts.forEach(a => { text += `• ${a.name} (${a.category}, ${a.priority})${a.accessNotes ? ' — ' + a.accessNotes : ''}\n`; }); text += '\n'; }
      if (financialAccounts.length) { text += '═══ FINANCIAL ═══\n'; financialAccounts.forEach(f => { text += `• ${f.name} (${f.type})${f.institution ? ' at ' + f.institution : ''}${f.notes ? ' — ' + f.notes : ''}\n`; }); text += '\n'; }
      if (messages.filter(m => m.draft).length) { text += '═══ MESSAGES ═══\n'; messages.filter(m => m.draft).forEach(m => { text += `To ${m.recipientName}:\n${m.draft}\n\n`; }); }
      text += BRANDING; return text;
    };

    return (
      <div>
        <h3 className={`text-lg font-bold ${c.text} mb-1`}>📋 Review & Export</h3>
        <p className={`text-sm ${c.textSec} mb-5`}>Your document for {tp} is ready.</p>

        {/* Completeness */}
        <div className={`p-5 rounded-2xl border ${c.border} ${c.bgCard} mb-5`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold ${totalFilled >= 4 ? c.successBg : c.bgInset}`}>{totalFilled}/5</div>
            <div><p className={`text-sm font-bold ${c.text}`}>{totalFilled >= 4 ? 'Looking thorough!' : totalFilled >= 2 ? 'Good progress' : 'Just getting started'}</p><p className={`text-xs ${c.textMut}`}>Sections completed</p></div>
          </div>
          <div className="space-y-2">
            {sections.map((s, i) => (
              <div key={i} className="flex items-center justify-between">
                <span className={`text-sm ${s.count > 0 ? c.text : c.textMut}`}>{s.count > 0 ? '✅ ' : '  '}{s.label}</span>
                <div className="flex items-center gap-2"><span className={`text-xs ${c.textMut}`}>{s.count > 0 ? `${s.count} ${s.unit}` : 'skipped'}</span>
                  <button onClick={() => goToChapter(s.chapter)} className={`text-xs font-semibold ${c.accent}`}>{s.count > 0 ? 'Edit' : 'Add'}</button></div>
              </div>
            ))}
          </div>
        </div>

        {/* v3: SMART GAPS */}
        <div className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-5`}>
          <div className="flex items-center justify-between mb-2">
            <div><p className={`text-sm font-semibold ${c.text}`}>🧠 AI Gap Analysis</p><p className={`text-xs ${c.textMut}`}>Find what you might have missed</p></div>
            <button onClick={runSmartGaps} disabled={gapsLoading} className={`px-4 py-2 rounded-xl text-xs font-bold ${!gapsLoading ? c.btn : c.btnDis}`}>
              {gapsLoading ? <span><span className="animate-spin inline-block">⏳</span></span> : 'Scan Document'}
            </button>
          </div>
          {smartGaps && (
            <div className="mt-3 space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <span className={`text-sm font-bold ${c.text}`}>Score: {smartGaps.overallScore}/10</span>
                <span className={`text-xs ${c.textMut}`}>{smartGaps.summary}</span>
              </div>
              {smartGaps.gaps?.map((gap, i) => (
                <div key={i} className={`p-3 rounded-lg border ${gap.severity === 'critical' ? c.errBg : gap.severity === 'important' ? c.diffChg : c.bgInset}`}>
                  <div className="flex items-start gap-2">
                    <span className="text-sm flex-shrink-0">{gap.severity === 'critical' ? '🔴' : gap.severity === 'important' ? '🟡' : '🟢'}</span>
                    <div><p className={`text-sm ${c.text}`}>{gap.finding}</p><p className={`text-xs ${c.textMut} mt-1`}>💡 {gap.suggestion}</p>
                      <button onClick={() => goToChapter(CHAPTERS.findIndex(ch => ch.id === gap.section) >= 0 ? CHAPTERS.findIndex(ch => ch.id === gap.section) : 0)}
                        className={`text-xs font-semibold ${c.accent} mt-1`}>Fix this →</button></div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Filter for multiple people */}
        {allPeopleNames.length > 1 && (
          <div className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-4`}>
            <p className={`text-xs font-bold ${c.textSec} uppercase tracking-wide mb-2`}>Export for specific person</p>
            <select value={exportFilter} onChange={e => setExportFilter(e.target.value)} className={`w-full px-3 py-2 rounded-lg border text-sm ${c.input} outline-none`}>
              {getVisibilityOptions().map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        )}

        {/* v3: ENCRYPTION */}
        <div className={`p-4 rounded-xl border ${encryptionEnabled ? c.lockBg : c.border} ${c.bgCard} mb-4`}>
          <div className="flex items-center gap-3 mb-2">
            <button onClick={() => setEncryptionEnabled(!encryptionEnabled)}
              className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all flex-shrink-0 ${encryptionEnabled ? 'bg-indigo-500 border-indigo-500 text-white' : c.border}`}>
              {encryptionEnabled && <span className="text-xs">✓</span>}
            </button>
            <div><p className={`text-sm font-semibold ${c.text}`}>🔐 Passphrase Protection</p><p className={`text-xs ${c.textMut}`}>AES-256 encryption — recipient enters passphrase to view</p></div>
          </div>
          {encryptionEnabled && (
            <div className="mt-3 space-y-2">
              <div className="relative">
                <input type={showPassphrase ? 'text' : 'password'} value={passphrase} onChange={e => setPassphrase(e.target.value)} placeholder="Choose a passphrase (4+ characters)"
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm ${c.input} outline-none pr-12`} />
                <button onClick={() => setShowPassphrase(!showPassphrase)} className={`absolute right-3 top-1/2 -translate-y-1/2 text-xs ${c.textMut}`}>{showPassphrase ? '🙈' : '👁️'}</button>
              </div>
              <input type="text" value={passphraseHint} onChange={e => setPassphraseHint(e.target.value)} placeholder="Hint for the recipient (optional)"
                className={`w-full px-4 py-2.5 rounded-xl border text-sm ${c.input} outline-none`} />
              <p className={`text-xs ${c.textMut}`}>Share the passphrase separately — by phone, in person, or in a sealed envelope.</p>
            </div>
          )}
        </div>

        {/* Export Actions */}
        <div className="space-y-3 mb-4">
          {encryptionEnabled ? (
            <button onClick={() => downloadEncryptedDocument(exportFilter)} disabled={!passphrase || passphrase.length < 4}
              className={`w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold ${passphrase && passphrase.length >= 4 ? c.btn : c.btnDis} shadow-lg`}>
              🔐 Download Encrypted Document
            </button>
          ) : (
            <button onClick={() => downloadDocument(exportFilter)}
              className={`w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold ${c.btn} shadow-lg`}>
              📥 Download as HTML
            </button>
          )}
          <div className="flex gap-3">
            <button onClick={() => printDocument(exportFilter)} className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm font-semibold ${c.btnSec}`}>🖨️ Print</button>
            <CopyBtn content={buildFullDocText()} label="📋 Copy All" />
          </div>
        </div>

        {/* v3: DELIVERY INSTRUCTIONS */}
        <div className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-4`}>
          <p className={`text-sm font-semibold ${c.text} mb-1`}>📧 Where Will This Live?</p>
          <p className={`text-xs ${c.textMut} mb-3`}>Where should {tp} look for this document?</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
            {DELIVERY_LOCATIONS.map(loc => (
              <button key={loc.id} onClick={() => setDeliveryLocation(loc.id)}
                className={`p-2.5 rounded-lg border text-xs font-medium text-left transition-all ${deliveryLocation === loc.id ? (c.d ? 'border-amber-500 bg-amber-900/30 text-amber-300' : 'border-amber-400 bg-amber-50 text-amber-700') : `${c.border} ${c.textMut}`}`}>
                {loc.icon} {loc.label}
              </button>
            ))}
          </div>
          <textarea value={deliveryNotes} onChange={e => setDeliveryNotes(e.target.value)} placeholder="Additional details — which safe, which drawer, shared drive URL..." rows={2} className={`w-full px-3 py-2 rounded-lg border text-xs ${c.input} outline-none`} />
        </div>

        {/* v3: QR ACCESS CARD */}
        <div className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-4`}>
          <div className="flex items-center justify-between">
            <div><p className={`text-sm font-semibold ${c.text}`}>📱 Print Access Card</p><p className={`text-xs ${c.textMut}`}>Wallet-sized card with location, contacts, and passphrase hint</p></div>
            <button onClick={generateQRCard} className={`px-4 py-2 rounded-xl text-xs font-bold ${c.btnSec}`}>🖨️ Print Card</button>
          </div>
        </div>

        {/* JSON backup */}
        <div className={`p-4 rounded-xl border ${c.border} ${c.bgCard} mb-6`}>
          <p className={`text-sm font-semibold ${c.text} mb-1`}>📅 Save for Annual Review</p>
          <p className={`text-xs ${c.textMut} mb-3`}>Export a backup. Next year, import it to see what's changed.</p>
          <div className="flex gap-2">
            <button onClick={exportJSON} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold ${c.btnSec}`}>📥 Export Backup</button>
            <label className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold ${c.btnSec} cursor-pointer`}>📤 Import Previous
              <input type="file" accept=".json" onChange={importJSON} className="hidden" /></label>
          </div>
        </div>

        <div className={`mt-4 p-5 rounded-2xl border-2 ${c.borderWarm} ${c.bgWarm}`}>
          <p className={`text-sm ${c.textWarm} leading-relaxed`}>
            You just did something most people never get around to. {tp} will be grateful. Review this every year or after major life changes.
          </p>
        </div>

        <div className={`mt-4 p-4 rounded-xl ${c.bgInset}`}>
          <p className={`text-xs ${c.textMut} mb-2`}>Finished? You might also want:</p>
          <div className="flex flex-wrap gap-2">
            <a href="/GratitudeDebtClearer" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent}`}>❤️ Clear gratitude debts</a>
            <span className={`text-xs ${c.textMut}`}>·</span>
            <a href="/DifficultTalkCoach" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent}`}>💬 Prepare a difficult conversation</a>
            <span className={`text-xs ${c.textMut}`}>·</span>
            <a href="/BrainDumpStructurer" target="_blank" rel="noopener" className={`text-xs font-semibold ${c.accent}`}>🧠 Organize your thoughts</a>
          </div>
        </div>

        <div className="flex items-center justify-between mt-8 pt-6 border-t" style={{ borderColor: c.d ? '#3f3f46' : '#e7e5e4' }}>
          <button onClick={prevChapter} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold ${c.btnSec}`}>← Previous</button>
          <div />
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════
  // DIFF SCREEN (Annual Review)
  // ══════════════════════════════════════════
  const renderDiffScreen = () => {
    if (!computeDiff) return null;
    const diff = computeDiff;
    return (
      <div className={c.text}>
        {renderToasts()}
        <div className="flex items-center justify-between mb-6">
          <h2 className={`text-xl font-bold ${c.text}`}>📅 Annual Review — What's Changed</h2>
          <button onClick={() => { setImportedData(null); setScreen('welcome'); }} className={`text-sm font-semibold ${c.btnGhost}`}>✕ Close</button>
        </div>
        {diff.prevDate && <p className={`text-sm ${c.textSec} mb-5`}>Comparing to backup from <strong>{new Date(diff.prevDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</strong></p>}
        {!diff.hasChanges ? (
          <div className={`p-5 rounded-2xl ${c.successBg} border mb-6`}><p className="text-sm font-semibold">✅ No changes detected — document is up to date.</p></div>
        ) : (
          <div className="space-y-4 mb-6">
            {diff.changes.map((ch, i) => (
              <div key={i} className={`p-4 rounded-xl border ${ch.type === 'added' ? c.diffAdd : c.diffRem}`}>
                <p className="text-sm font-bold mb-2">{ch.type === 'added' ? '➕' : '➖'} {ch.section}: {ch.items.length} {ch.type}</p>
                <div className="flex flex-wrap gap-2">{ch.items.map((item, j) => <span key={j} className={`px-2 py-1 rounded text-xs font-medium ${c.tag}`}>{item}</span>)}</div>
              </div>
            ))}
            {diff.textChanges.length > 0 && (
              <div className={`p-4 rounded-xl border ${c.diffChg}`}>
                <p className="text-sm font-bold mb-2">✏️ Text Fields Updated</p>
                {diff.textChanges.map((ch, i) => <p key={i} className={`text-sm ${c.textSec}`}>• {ch}</p>)}
              </div>
            )}
          </div>
        )}
        <div className="space-y-3">
          <button onClick={() => { setImportedData(null); setScreen('chapter'); setCurrentChapter(0); }} className={`w-full px-6 py-3 rounded-2xl text-sm font-bold ${c.btn}`}>Continue Editing Current</button>
          <button onClick={importAndReplace} className={`w-full px-6 py-3 rounded-2xl text-sm font-semibold ${c.btnSec}`}>Restore Previous Version</button>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════
  // CHAPTER ROUTER
  // ══════════════════════════════════════════
  const renderCurrentChapter = () => {
    switch (currentChapter) {
      case 0: return renderChapterAccounts();
      case 1: return renderChapterDocuments();
      case 2: return renderChapterFinancial();
      case 3: return renderChapterMessages();
      case 4: return renderChapterWishes();
      case 5: return renderChapterReview();
      default: return null;
    }
  };

  // ══════════════════════════════════════════
  // MAIN RENDER
  // ══════════════════════════════════════════
  if (screen === 'welcome') return renderWelcome();
  if (screen === 'emergency') return renderEmergency();
  if (screen === 'diff') return renderDiffScreen();
  if (screen === 'interview') return renderInterviewScreen();

  return (
    <div className={c.text}>
      {renderToasts()}
      {renderProgressBar()}
      {renderCurrentChapter()}
    </div>
  );
};

FinalWish.displayName = 'FinalWish';
export default FinalWish;
