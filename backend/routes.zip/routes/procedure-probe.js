const express = require('express');
const router = express.Router();
const { callClaudeWithRetry, withLanguage, withLocaleContext } = require('../lib/claude');
const { rateLimit, DEFAULT_LIMITS } = require('../lib/rateLimiter');

// ════════════════════════════════════════════════════════════
// POST /procedure-probe — Procedure Probe
// ════════════════════════════════════════════════════════════
router.post('/procedure-probe', rateLimit(DEFAULT_LIMITS), async (req, res) => {
  try {
    const { procedure, quote, provider, insurance, concerns, urgency, userLanguage, userLocale, userCurrency, userRegion } = req.body;

    if (!procedure?.trim()) {
      return res.status(400).json({ error: 'Tell us what procedure or treatment was recommended.' });
    }

    const systemPrompt = `You are a patient advocate and healthcare literacy coach. When someone has been recommended a medical or dental procedure, you help them understand what they're agreeing to — without replacing their doctor's advice.`;

    const userPrompt = `PROCEDURE/TREATMENT RECOMMENDED: ${procedure}
${quote ? `QUOTED PRICE: ${quote}` : ''}
${provider ? `PROVIDER TYPE: ${provider}` : ''}
${insurance ? `INSURANCE SITUATION: ${insurance}` : ''}
${concerns ? `MY CONCERNS: ${concerns}` : ''}
${urgency ? `URGENCY LEVEL: ${urgency}` : ''}

Help me be an informed patient. Return ONLY valid JSON:
{
  "procedure_name": "Clean name of the procedure — 3-6 words",
  "plain_english": "2-3 sentences explaining what this procedure actually involves, in language anyone can understand.",

  "is_this_standard": {
    "verdict": "Standard | Common but alternatives exist | Worth questioning | Get a second opinion",
    "explanation": "2-3 sentences on whether this is the typical recommendation for this situation.",
    "alternatives": ["1-3 alternative approaches that exist, if any, with brief explanation of each"]
  },

  "questions_to_ask": [
    {
      "question": "The exact question to ask your provider — one sentence",
      "why_it_matters": "Why this question is important — what the answer reveals — one sentence"
    }
  ],

  "cost_picture": {
    "typical_range": "Typical cost range for this procedure (e.g., '$500-$2,000') — one sentence",
    "insurance_typically": "What insurance usually covers for this — one sentence",
    "out_of_pocket_estimate": "Realistic out-of-pocket estimate — one sentence",
    "money_saving_tip": "One way to reduce the cost that most patients don't know about — one sentence"
  },

  "second_opinion": {
    "recommended": true,
    "reason": "One sentence on whether a second opinion is warranted and why."
  },

  "red_flags": [
    "2-3 signs that should make you pause or seek another opinion for this specific procedure"
  ],

  "what_to_expect": {
    "procedure_duration": "How long the procedure typically takes (number)",
    "recovery_time": "Realistic recovery timeline — one sentence",
    "pain_level": "Honest pain/discomfort assessment — one sentence",
    "lifestyle_impact": "How it affects daily life during recovery — one sentence",
    "follow_up": "What follow-up care looks like — one sentence"
  },

  "urgency_check": {
    "time_sensitive": true,
    "explanation": "Is delaying this procedure risky? Be clear about urgency. — 1-2 sentences"
  },

  "empowerment_note": "One reassuring sentence that empowers them to advocate for themselves. — one sentence"
}

Generate 6-8 questions to ask.`;

    const parsed = await callClaudeWithRetry({
      model: 'claude-sonnet-4-6',
      max_tokens: 2500,
      system: withLanguage(systemPrompt, userLanguage) + withLocaleContext(userLocale, userCurrency, userRegion),
      messages: [{ role: 'user', content: userPrompt }],
    }, { label: 'procedure-probe' });
    if (!parsed.plain_english) {
      return res.status(500).json({ error: 'Could not analyze this procedure. Please try again.' });
    }
    return res.json(parsed);

  } catch (error) {
    console.error('ProcedureProbe error:', error);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

module.exports = router;
