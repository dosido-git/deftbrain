const express = require('express');
const router = express.Router();
const { anthropic, callClaudeWithRetry, withLanguage } = require('../lib/claude');
const { rateLimit, DEFAULT_LIMITS } = require('../lib/rateLimiter');

const PERSONALITY = `Decision contrast analyst. Help people understand what they're actually choosing between by making both paths vivid and specific.

Don't recommend. Illuminate. Show the texture of each path — the unexpected good parts, the hidden costs, the second-order effects nobody thinks about until they're living them. Be emotionally honest without being manipulative.`;

// ════════════════════════════════════════════
// HELPER: Build user prompt (shared by both routes)
// ════════════════════════════════════════════
function buildPrompt({ pathA, pathB, aboutYou, timeframe }) {
  const tf = timeframe || '2 years';
  return `THE CONTRAST REPORT

THE DECISION:
Path A: "${pathA.trim()}"
Path B: "${pathB.trim()}"
${aboutYou?.trim() ? `\nABOUT THIS PERSON:\n"${aboutYou.trim()}"` : ''}

TIMEFRAME: ${tf} from now

Write two vivid "day in the life" narratives — one for each path, set ${tf} from now. Each should be a single ordinary day (a Tuesday, not a milestone), written in second person present tense, 200-300 words. Make each future feel real enough that the reader's body reacts.

Then surface what you noticed — not advice, just honest observation.

Return ONLY valid JSON:

{
  "decision_framed": "Restate the core decision in one clean sentence — one sentence",
  "path_a": {
    "label": "Short label for this path (3-5 words)",
    "narrative": "200-300 word day-in-the-life narrative. Second person, present tense. A plausible Tuesday, ${tf} from now. Specific, sensory, honest — including both the good and the cost. End mid-moment.",
    "the_good_moment": "The single best moment in this day — the one that would make someone choose this path. One sentence.",
    "the_honest_cost": "The single hardest moment — the price of this path that nobody warns you about. One sentence."
  },
  "path_b": {
    "label": "Short label for this path (3-5 words)",
    "narrative": "200-300 word day-in-the-life narrative. Same rules. Different life. Equally vivid and honest.",
    "the_good_moment": "The single best moment in this day. — one sentence",
    "the_honest_cost": "The single hardest moment. (number)"
  },
  "what_i_noticed": {
    "the_pull": "Which path seemed to carry more energy or aliveness when you wrote it — not which is 'better,' just which one wanted to be written more. Be honest. 1-2 sentences.",
    "what_youre_trading": "Name the specific thing that exists in one path and is absent in the other. The thing this person will grieve no matter which they choose. 1-2 sentences.",
    "the_question_underneath": "The real question this decision is asking — often not what it appears. Usually something about identity, not logistics. One sentence."
  }
}`;
}

// ════════════════════════════════════════════
// ROUTE: Standard (non-streaming) — fallback
// ════════════════════════════════════════════
router.post('/contrast-report', rateLimit(DEFAULT_LIMITS), async (req, res) => {
  try {
    const { pathA, pathB, aboutYou, timeframe, userLanguage } = req.body;

    if (!pathA?.trim() || !pathB?.trim()) {
      return res.status(400).json({ error: "Describe both paths you're considering." });
    }

    const parsed = await callClaudeWithRetry(
      buildPrompt({ pathA, pathB, aboutYou, timeframe }),
      {
        label: 'contrast-report',
        model: 'claude-sonnet-4-6',
        max_tokens: 2000,
        system: withLanguage(PERSONALITY, userLanguage),
      }
    );

    if (!parsed.path_a || !parsed.path_b) {
      return res.status(500).json({ error: 'Could not generate the contrast report. Please try again.' });
    }
    res.json(parsed);

  } catch (error) {
    console.error('ContrastReport error:', error);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// ════════════════════════════════════════════
// ROUTE: Streaming — SSE endpoint
// NOTE: Uses raw anthropic.messages.stream — streaming requires raw SSE API;
// callClaudeWithRetry does not support streaming. This is the documented exception.
// ════════════════════════════════════════════
router.post('/contrast-report/stream', rateLimit(DEFAULT_LIMITS), async (req, res) => {
  const { pathA, pathB, aboutYou, timeframe, userLanguage } = req.body;

  if (!pathA?.trim() || !pathB?.trim()) {
    return res.status(400).json({ error: "Describe both paths you're considering." });
  }

  // SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const sendEvent = (data) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    const stream = anthropic.messages.stream({
      model: 'claude-sonnet-4-6',
      max_tokens: 4000,
      system: withLanguage(PERSONALITY, userLanguage),
      messages: [{ role: 'user', content: buildPrompt({ pathA, pathB, aboutYou, timeframe }) }],
    });

    stream.on('text', (chunk) => {
      sendEvent({ chunk });
    });

    stream.on('error', (err) => {
      console.error('ContrastReport stream error:', err);
      sendEvent({ error: err.message || 'Stream failed' });
      res.end();
    });

    stream.finalMessage()
      .then(() => {
        sendEvent({ done: true });
        res.end();
      })
      .catch((err) => {
        if (err?.name === 'APIUserAbortError') return;
        console.error('ContrastReport finalMessage error:', err);
        sendEvent({ error: err.message || 'Stream failed' });
        res.end();
      });

  } catch (error) {
    console.error('ContrastReport stream setup error:', error);
    sendEvent({ error: error.message || 'Failed to start stream' });
    res.end();
  }
});

module.exports = router;
