const express = require('express');
const router = express.Router();
const { callClaudeWithRetry, withLanguage } = require('../lib/claude');
const { rateLimit, DEFAULT_LIMITS } = require('../lib/rateLimiter');

// ════════════════════════════════════════════════════════════
// POST /context-collapse — How Will Different People Read This?
// ════════════════════════════════════════════════════════════
router.post('/context-collapse', rateLimit(DEFAULT_LIMITS), async (req, res) => {
  try {
    const {
      message,
      platform,
      audiences,
      intent,
      concerns,
      userLanguage,
    } = req.body;

    if (!message?.trim()) {
      return res.status(400).json({ error: "Paste the message you're about to send" });
    }
    if (!audiences?.length || !audiences.some(a => a.label?.trim())) {
      return res.status(400).json({ error: 'Add at least one audience — who will see this?' });
    }

    const validAudiences = audiences.filter(a => a.label?.trim());

    const systemPrompt = withLanguage(
      `You are a communication analyst specializing in "context collapse" — the phenomenon where a single message is interpreted completely differently by different audiences.

You help people preview how their message will land BEFORE they send it. You think like a therapist (understanding emotional subtext), a PR strategist (understanding public perception), and a linguist (understanding how words carry different weight in different relationships).

KEY PRINCIPLES:
1. Be specific and vivid about HOW each audience reads the message — not vague. "Your boss reads this as..." not "some people might think..."
2. Identify the EMOTIONAL interpretation, not just the literal one. The same sentence can feel supportive to one person and passive-aggressive to another.
3. Pay attention to: tone markers (!, ..., capitalization, emoji), implicit assumptions, what's NOT said, and cultural/generational differences in communication style.
4. The gap between intent and interpretation is where problems happen. Make this gap visible.
5. When suggesting rewrites, preserve their voice — don't make them sound like a corporate PR department.
6. Be honest about risks. If a message is genuinely problematic for an audience, say so clearly.

Return only valid JSON.`,
      userLanguage
    );

    const audienceList = validAudiences.map((a, i) =>
      `Audience ${i + 1}: "${a.label}"${a.relationship ? ` (relationship: ${a.relationship})` : ''}${a.context ? ` — context: ${a.context}` : ''}`
    ).join('\n');

    const userPrompt = `MESSAGE THEY'RE ABOUT TO SEND:
"${message}"

PLATFORM: ${platform || 'not specified'}
${intent ? `THEIR INTENT: ${intent}` : ''}
${concerns ? `THEIR CONCERN: ${concerns}` : ''}

AUDIENCES WHO WILL SEE THIS:
${audienceList}

Analyze how each audience will interpret this. Return ONLY valid JSON:

{
  "message_analysis": {
    "tone_detected": "What tone does this message actually convey? Be specific — not just 'friendly' but 'casually assertive with an undercurrent of frustration' — one sentence",
    "subtext": "What does this message communicate between the lines that the sender might not realize? — one sentence",
    "ambiguous_elements": ["Specific words, phrases, or stylistic choices that different audiences will read differently"]
  },

  "readings": [
    {
      "audience": "Audience label — one sentence",
      "reads_as": "How this audience interprets the message — be vivid and specific. Write as: 'They read this as...' or 'To them, this says...' — one sentence",
      "emotional_impact": "How this makes them FEEL — not just what they think — one sentence",
      "risk_level": "safe | mild_risk | risky | dangerous",
      "key_trigger": "The specific word, phrase, or absence that drives their interpretation — one sentence",
      "what_they_might_do": "How they might respond or react — one sentence"
    }
  ],

  "intent_vs_reality": {
    "gap_analysis": "Where does the intended message diverge from how it actually reads? Be specific. — 1-2 sentences",
    "biggest_risk": "The single most problematic interpretation across all audiences — one sentence"
  },

  "verdict": {
    "safe_to_send": true,
    "verdict_label": "SEND AS IS | MINOR TWEAKS | REWRITE NEEDED | DON'T SEND",
    "summary": "1-2 sentences: overall assessment"
  },

  "rewrites": [
    {
      "label": "What this rewrite optimizes for (e.g., 'Safer for boss, same vibe for friends') — one sentence",
      "message": "The rewritten message — preserve their voice, fix the gaps — 2-4 sentences",
      "tradeoff": "What you gain and what you lose with this version — one sentence"
    }
  ],

  "platform_note": "Any platform-specific considerations — group chat dynamics, social media permanence, email forwarding risk, screenshot risk. null if not relevant. — one sentence",

  "nuclear_scenarios": [
    {
      "scenario": "The worst-case interpretation someone could have — one sentence",
      "likelihood": "unlikely | possible | likely",
      "mitigation": "How to prevent this reading or recover if it happens — one sentence"
    }
  ]
}

Generate 1-2 rewrites that meaningfully improve the message for the most at-risk audiences while preserving the sender's intent and voice.`;

    const parsed = await callClaudeWithRetry({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 4000,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    }, { label: 'context-collapse' });

    if (!parsed.message_analysis && !parsed.rewrites) {
      return res.status(500).json({ error: 'Could not analyze the message. Please try again.' });
    }
    res.json(parsed);
  } catch (error) {
    console.error('Context Collapse error:', error);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

module.exports = router;
