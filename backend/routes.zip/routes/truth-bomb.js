const express = require('express');
const router = express.Router();
const { cleanJsonResponse, withLanguage, callClaudeWithRetry } = require('../lib/claude');
const { rateLimit, DEFAULT_LIMITS } = require('../lib/rateLimiter');

const PERSONALITY = `Truth-telling strategist. Help people decide whether to say the hard thing — and if yes, exactly how to say it.

Analyze: what would actually change if they said it, what they risk by saying it vs staying silent, whether this is avoidance or wisdom, and the precise words that are honest without being cruel. Give the conversation they could have, not an abstract framework.`;

router.post('/truth-bomb', rateLimit(DEFAULT_LIMITS), async (req, res) => {
  try {
    const { theUnsaidThing, whoItsAbout, whyNotSaying, relationshipContext, userLanguage } = req.body;
  if (!theUnsaidThing?.trim()) {
    return res.status(400).json({ error: 'What\'s the thing you\'re not saying?' });
  }

    const userPrompt = `TRUTH BOMB — THE UNSAID THING, HANDLED

THE THING THEY'RE NOT SAYING:
"${theUnsaidThing.trim()}"
${whoItsAbout?.trim() ? `WHO IT'S ABOUT / TO: ${whoItsAbout.trim()}` : ''}
${whyNotSaying?.trim() ? `WHY THEY HAVEN'T SAID IT: ${whyNotSaying.trim()}` : ''}
${relationshipContext?.trim() ? `RELATIONSHIP CONTEXT: ${relationshipContext.trim()}` : ''}

Explore it. Name the cost. Show the three ways to say it.

Return ONLY valid JSON:
{
  "the_thing_examined": {
    "what_its_really_about": "The deeper truth underneath the surface statement — what they're really grappling with — one sentence",
    "why_its_hard_to_say": "The specific fear or cost driving the silence — not generic, not 'it's complicated' — one sentence",
    "what_hiding_it_costs": "The specific, concrete cost of continued silence — what it's eroding right now in their life or relationship — one sentence"
  },

  "what_would_actually_happen": {
    "most_likely_scenario": "The realistic outcome if they said it — not catastrophic, not rosy. What would probably actually happen. — one sentence",
    "the_fear_vs_reality_gap": "Where the feared outcome diverges from the likely outcome — what they're overestimating — one sentence",
    "what_it_would_change": "What would actually shift if this truth was in the open — in them, in the relationship, in the situation — one sentence",
    "what_wouldnt_change": "What would stay the same — for better or worse — one sentence"
  },

  "three_ways_to_say_it": [
    {
      "version": "The Gentle Opening — one sentence",
      "directness": 1,
      "when_to_use": "When you want to open the door without walking all the way through it — one sentence",
      "the_words": "The actual thing to say — written as a real sentence or two they could use verbatim — one sentence",
      "what_it_accomplishes": "What this version does and doesn't resolve — one sentence"
    },
    {
      "version": "The Direct Statement — one sentence",
      "directness": 2,
      "when_to_use": "When you want to say it clearly without softening it to meaninglessness — one sentence",
      "the_words": "The actual thing to say — written as a real sentence or two they could use verbatim — one sentence",
      "what_it_accomplishes": "What this version does and doesn't resolve — one sentence"
    },
    {
      "version": "The Full Truth — one sentence",
      "directness": 3,
      "when_to_use": "When you're done managing their reaction and just need it said — one sentence",
      "the_words": "The actual thing to say — the unfiltered version. No softening. — one sentence",
      "what_it_accomplishes": "What this version does and doesn't resolve — one sentence"
    }
  ],

  "the_timing": {
    "when_to_say_it": "The optimal conditions for saying this — not a date, but the right moment and context — one sentence",
    "what_to_avoid": "The conditions that make this conversation go worse — one sentence",
    "if_they_dont_respond_well": "How to handle the likely difficult immediate reaction — what to say next — one sentence"
  },

  "permission_to_not_say_it": {
    "is_silence_legitimate": true,
    "when_silence_is_okay": "The conditions under which not saying this is a legitimate choice, not just avoidance — one sentence",
    "the_honest_cost": "If they choose silence, the honest cost they're accepting — no judgment, just clarity (number)"
  }
}`;

    const parsed = await callClaudeWithRetry({
model: 'claude-sonnet-4-6',
      max_tokens: 2200,
      system: withLanguage(PERSONALITY, userLanguage),
      messages: [{ role: 'user', content: userPrompt }],
    }, { label: 'truth-bomb' });
    if (!parsed.the_thing_examined) {
      return res.status(500).json({ error: 'Could not analyze this. Please try again.' });
    }
    res.json(parsed);

  } catch (error) {
    console.error('TruthBomb error:', error);
    res.status(500).json({ error: 'Something went wrong. Please try again.'});
  }
});

module.exports = router;
